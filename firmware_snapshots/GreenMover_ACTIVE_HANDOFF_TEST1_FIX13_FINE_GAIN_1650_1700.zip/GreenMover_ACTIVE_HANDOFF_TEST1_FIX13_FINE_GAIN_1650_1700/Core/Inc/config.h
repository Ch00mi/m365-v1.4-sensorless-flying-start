/*
 * Green Mover / Xiaomi M365 experimental sensorless test configuration
 *
 * Hardware base: Xiaomi M365 SCO_DRV V1.4, STM32F103C8T6
 * Motor: 36 V / 250 W Green Mover direct-drive hub, no Hall sensors
 *
 * TEST STAGES
 *   0 = SAFE boot/dashboard test. PWM can never be armed from throttle.
 *   1 = OBSERVER TEST. Throttle only starts zero-current acquisition.
 *       NO torque command is ever applied. This is the current build.
 *   2 = LOW-TORQUE test. Do not use until TEST1 observer data look correct.
 */
#ifndef CONFIG_H_
#define CONFIG_H_

#include "stdint.h"

/* ------------------------------------------------------------------------- */
/* M365 board ADC calibration inherited from the proven M365 hardware port. */
#define CAL_BAT_V 14       /* ADC count * 14 = battery voltage in mV */
#define CAL_I     38       /* ADC current count * 38 = phase current in mA */

/* Original M365 dashboard throttle/brake byte calibration. */
#define THROTTLEOFFSET 45
#define THROTTLEMAX    175
#define BRAKEOFFSET    50
#define BRAKEMAX       190

/* ------------------------------------------------------------------------- */
#define SENSORLESS_EXPERIMENTAL 1
#define SENSORLESS_PARAMS_READY 1
#define SENSORLESS_TEST_STAGE   1

/*
 * PHASE_VOLTAGE_TEST0
 * -------------------
 * Passive flying-start/BEMF hardware validation.
 * TIM1 power outputs are NEVER started; MOSFET bridge remains disabled.
 * ADC1 regular scan measures:
 *   PA6 / ADC6 = phase A voltage
 *   PA7 / ADC7 = phase B voltage
 *   PB1 / ADC9 = phase C voltage
 * according to SCO_DRV V1.4 schematic and the existing M365 GPIO map.
 */
#define PHASE_VOLTAGE_TEST0                 1

/* TIM3 regular-ADC trigger: 64 MHz timer clock / (7813 + 1). */
#define PV_ADC_TRIGGER_HZ                8190UL
#define PV_PROCESS_DECIMATION               4U
#define PV_PROCESS_HZ          (PV_ADC_TRIGGER_HZ / PV_PROCESS_DECIMATION)

/*
 * FIX2 speed estimator: unwrap every valid processed angle step, then average
 * 32 consecutive steps. Unlike the old endpoint-only 16-sample window this
 * does not alias merely because the accumulated window exceeds +/-180 deg.
 */
#define PV_SPEED_ACCUM_SAMPLES             32U

/* Reject an individual BEMF-angle jump larger than 90 electrical degrees.
 * At our intended flying-start speeds a real step is only a few degrees. */
#define PV_ANGLE_STEP_MAX_Q31       1073741824LL /* 90 deg = 2^30 */

/* If the BEMF vector is invalid for this many processed samples, publish zero
 * speed instead of leaving a stale last-speed value in Live Expressions. */
#define PV_SPEED_INVALID_ZERO_SAMPLES       16U

/* One latched diagnostics window is approximately one second. */
#define PV_DIAG_WINDOW_SAMPLES    ((uint32_t)PV_PROCESS_HZ)

/*
 * V1.4 phase-voltage divider:
 * phase -> 22 kOhm -> ADC node -> 6 kOhm -> GND
 * Vphase = Vadc * (22+6)/6 = Vadc * 14/3.
 * Nominal 3.300 V ADC reference gives 15.400 V phase-terminal full scale.
 */
#define PV_PHASE_FULL_SCALE_MV          15400UL
#define PV_ADC_FULL_SCALE_COUNTS         4095UL

/* Vector must be above this before angle/speed is considered meaningful. */
#define PV_BEMF_VALID_MIN_MV              350U

/*
 * PASSIVE_PLL_TEST1
 * -----------------
 * Second-order alpha/beta PLL operating ONLY on the passive BEMF angle.
 * This stage does not start TIM1, MOE, SVPWM, injected ADCs, or any FOC loop.
 *
 * Discrete type-II PLL:
 *   phase[k+1] = phase[k] + omega[k] + Kp * phase_error
 *   omega[k+1] = omega[k] + Ki * phase_error
 *
 * Kp=0.080 and Ki=0.0025 at ~2.047 kHz give a deliberately moderate
 * tracking bandwidth: fast enough for pedal acceleration, but much smoother
 * than feeding the raw atan2 angle directly to a future FOC handoff.
 */
#define PV_PASSIVE_PLL_TEST1                 1U
#define PV_PLL_KP_Q15                     2621L  /* 0.0800 */
#define PV_PLL_KI_Q15                       82L  /* 0.00250 */

/* Search/acquisition criteria. Sparse valid BEMF samples are allowed. */
#define PV_PLL_ACQUIRE_DELTAS               12U
#define PV_PLL_ACQUIRE_MIN_ERPM             120U /* 6 mechanical rpm @ 20 pole pairs */
#define PV_PLL_ACQUIRE_COHERENCE_PERMILLE   800U
#define PV_PLL_ACQUIRE_MAX_GAP_SAMPLES       32U
#define PV_PLL_ACQUIRE_RESET_GAP_SAMPLES     96U
#define PV_PLL_MAX_ERPM                   12000U

/* Lock/holdover diagnostics and conservative loss-of-lock rules. */
#define PV_PLL_GOOD_ERR_DEG_X100           3000U /* 30 electrical deg */
#define PV_PLL_BAD_ERR_DEG_X100            6000U /* 60 electrical deg */
#define PV_PLL_BAD_STREAK_LIMIT               8U
#define PV_PLL_INVALID_LOSS_SAMPLES          256U /* ~125 ms @ PV_PROCESS_HZ */
#define PV_PLL_CONF_LOCK_INIT                650U
#define PV_PLL_CONF_GOOD_INC                   6U
#define PV_PLL_CONF_WEAK_INC                   1U
#define PV_PLL_CONF_INVALID_DEC                2U
#define PV_PLL_CONF_BAD_DEC                   80U
#define PV_PLL_CONF_LOSS                      150U

/*
 * FOC_ANGLE_MAPPING_TEST1
 * -----------------------
 * Still 100% passive. Uses the locked passive PLL angle to construct the
 * rotor-flux/d-axis candidate expected by the existing CMSIS Clarke/Park FOC.
 * No TIM1 PWM channel is started and no duty value is written to the bridge.
 *
 * For the standard PMSM convention used by arm_clarke_q31()/arm_park_q31():
 *   theta_flux = theta_BEMF - sign(omega) * 90 electrical degrees.
 * The test rotates measured passive BEMF into that candidate dq frame and
 * verifies that Ed ~= 0 while Eq has the same sign as electrical speed.
 * Mapping diagnostics are decimated to keep ISR overhead modest.
 */
#define PV_FOC_ANGLE_MAPPING_TEST1            1U
#define PV_MAP_DIAG_DECIMATION                8U

/*
 * FOC_HANDOFF_PREP_TEST1
 * ----------------------
 * 100% shadow calculation only.  The measured passive BEMF vector is converted
 * into the controller voltage coordinates that the existing inverse-Park +
 * svpwm() path would need in order to reproduce the same terminal voltage.
 * TIM1 remains stopped, MOE remains clear, and no shadow duty is ever written
 * to a timer register or to the live PI regulators.
 *
 * This test deliberately uses the MEASURED phase-voltage BEMF instead of the
 * motor Kv/flux constants for the proposed zero-current preload.  It therefore
 * also checks the board-specific alpha/beta voltage scaling before any active
 * flying-start handoff is attempted.
 */
#define PV_FOC_HANDOFF_PREP_TEST1              1U

/* Conservative readiness envelope for the later first active handoff. */
#define PV_HO_MIN_ERPM                         600U  /* 30 mechanical rpm */
#define PV_HO_MAX_ERPM                        4000U  /* 200 mechanical rpm */
#define PV_HO_MIN_PLL_CONFIDENCE               950U
#define PV_HO_MAX_QUAD_ERR_DEG_X100           1000U  /* 10 electrical deg */
#define PV_HO_MAX_U_ABS                        550U  /* margin below SENSORLESS_TEST1_U_MAX=600 */
#define PV_HO_DUTY_MARGIN_COUNTS                40U
#define PV_HO_PI_SHIFT                           10U  /* matches PI_id/PI_iq.shift in motor_init */

/* Reject-mask bits published in pv_ho_reject_mask. */
#define PV_HO_REJ_PLL_STATE                  (1UL << 0)
#define PV_HO_REJ_CONFIDENCE                 (1UL << 1)
#define PV_HO_REJ_SIGNAL_MAP                 (1UL << 2)
#define PV_HO_REJ_SPEED                      (1UL << 3)
#define PV_HO_REJ_VBUS                       (1UL << 4)
#define PV_HO_REJ_HIGH_CLIP                  (1UL << 5)
#define PV_HO_REJ_ANGLE_MAP                  (1UL << 6)
#define PV_HO_REJ_VOLTAGE_CMD                (1UL << 7)
#define PV_HO_REJ_DUTY_MARGIN                (1UL << 8)
#define PV_HO_REJ_ADC_ERROR                  (1UL << 9)

/*
 * ACTIVE_HANDOFF_TEST1
 * --------------------
 * First deliberately ACTIVE flying-start experiment. This is NOT a rideable
 * controller mode. It is a one-shot, manually armed zero-current takeover
 * intended only for a wheel lifted clear of the ground.
 *
 * Safety model:
 *   - passive BEMF/PLL/mapping/shadow handoff must already be qualified,
 *   - only forward rotation in a narrow 45..65 mechanical-rpm window,
 *   - user must explicitly write pv_act_arm=1 in Live Expressions,
 *   - TIM1 MOE is enabled for only a few milliseconds,
 *   - Id=Iq=0 throughout, PI states are preloaded from the passive BEMF,
 *   - electrical angle free-runs from the last passive PLL speed while PWM is on
 *     (phase-voltage BEMF sensing is intentionally not trusted under PWM),
 *   - hard phase-current and voltage-command trips immediately clear MOE,
 *   - test cannot repeat until pv_act_reset=1 is written manually.
 */
#define PV_ACTIVE_HANDOFF_TEST1                1U
#define PV_ACT_MIN_ERPM                       900U  /* 45 mech rpm @ 20 pole pairs */
#define PV_ACT_MAX_ERPM                      1300U  /* 65 mech rpm */
#define PV_ACT_REQUIRED_DIR                      1  /* forward only for first pulse */
#define PV_ACT_MIN_PLL_CONFIDENCE             990U
#define PV_ACT_MAX_MATCH_ERR_PERMILLE           25U
#define PV_ACT_MAX_QUAD_ERR_DEG_X100           600U  /* 6 electrical deg */
#define PV_ACT_MAX_PHASE_CURRENT_MA           1200U
#define PV_ACT_MAX_IDLE_CURRENT_MA              450U  /* measured FIX8 bridge-off envelope + margin */
#define PV_ACT_IDLE_DIAG_WINDOW_SAMPLES         256U
#define PV_ACT_IDLE_REQUIRED_GOOD_WINDOWS         8U  /* consecutive clean windows before ARM-ready */
#define PV_ACT_TRIP_TRACE_SAMPLES                 16U  /* circular pre-trip active-current history */
#define PV_ACT_MAX_U_ABS                       300U
#define PV_ACT_DURATION_US                     350U  /* FIX10: short scale-identification pulse */
#define PV_ACT_REQUIRED_READY_PERMILLE         1000U

/* FIX13 fine physical-voltage gain calibration. FIX12 showed that 1600
 * permille still leaves a positive q-axis current ramp while remaining well
 * inside the existing 1.2 A current and Uabs=300 safety limits. Continue only
 * in small steps: 1650 first, then 1700 only after reviewing the 1650 pulse.
 * Requests are hard-clamped to 1300..1700 permille before every ARM. */
#define PV_ACT_SCALE_MIN_PERMILLE               1300U
#define PV_ACT_SCALE_MAX_PERMILLE               1700U
/* FIX13 keeps the voltage-vector angle correction locked to 0.00 electrical degree.
 * Keep the runtime variable for diagnostics, but any nonzero write is clamped
 * back to zero so the gain sweep changes amplitude only. */
#define PV_ACT_ANGLE_MIN_DEG_X100                   0
#define PV_ACT_ANGLE_MAX_DEG_X100                   0

/* pv_act_abort_reason bits. Timeout completion is success, not an abort bit. */
#define PV_ACT_ABORT_OVERCURRENT             (1UL << 0)
#define PV_ACT_ABORT_VOLTAGE_CMD             (1UL << 1)
#define PV_ACT_ABORT_ADC_ERROR               (1UL << 2)
#define PV_ACT_ABORT_HW_STATE                (1UL << 3)
#define PV_ACT_ABORT_INTERNAL                (1UL << 4)

/* pv_act_arm_reject_mask bits: reasons a manual arm request was refused. */
#define PV_ACT_ARM_REJ_HO_NOT_READY          (1UL << 0)
#define PV_ACT_ARM_REJ_SPEED                 (1UL << 1)
#define PV_ACT_ARM_REJ_DIRECTION             (1UL << 2)
#define PV_ACT_ARM_REJ_CONFIDENCE            (1UL << 3)
#define PV_ACT_ARM_REJ_MAPPING               (1UL << 4)
#define PV_ACT_ARM_REJ_MATCH_ERROR           (1UL << 5)
#define PV_ACT_ARM_REJ_ADC_ERROR             (1UL << 6)
#define PV_ACT_ARM_REJ_READY_HISTORY         (1UL << 7)
#define PV_ACT_ARM_REJ_HW_NOT_READY          (1UL << 8)
#define PV_ACT_ARM_REJ_IDLE_CURRENT           (1UL << 9)
#define PV_ACT_ARM_REJ_SCALE_VOLTAGE          (1UL << 10)

/* Diagnostic clipping thresholds only. */
#define PV_ADC_CLIP_LOW_COUNTS               4U
#define PV_ADC_CLIP_HIGH_COUNTS           4090U

/* ------------------------------------------------------------------------- */
/* Measured Green Mover motor data. */
#define MOTOR_POLE_PAIRS                    20U
#define MOTOR_LINE_RESISTANCE_MOHM         200U   /* 0.20 ohm line-line */
#define MOTOR_LINE_INDUCTANCE_UH           1210U  /* 1.21 mH line-line, mean */
#define MOTOR_LINE_INDUCTANCE_MIN_UH       1090U
#define MOTOR_LINE_INDUCTANCE_MAX_UH       1350U
#define MOTOR_BEMF_LL_RMS_UV_PER_RPM      90000UL /* 0.090 V RMS line-line / rpm */
#define MOTOR_FLUX_LINKAGE_UWB             35000UL /* ~0.035 Wb = 35,000 uWb */
#define MOTOR_KV_MRPM_PER_V                 7900UL /* 7.9 rpm/V, stored x1000 */

/*
 * Balanced terminal-equivalent phase parameters for the alpha/beta PMSM model.
 * For a balanced star or an equivalent balanced delta terminal model, the
 * phase-equivalent R and L used by the Clarke model are half the measured
 * line-line values.
 */
#define MOTOR_EQ_PHASE_RESISTANCE_MOHM  (MOTOR_LINE_RESISTANCE_MOHM / 2U) /* 100 mOhm */
#define MOTOR_EQ_PHASE_INDUCTANCE_UH     (MOTOR_LINE_INDUCTANCE_UH / 2U)   /* 605 uH */

/* ------------------------------------------------------------------------- */
/* Physical-unit nonlinear flux observer. */
#define SL_FAST_LOOP_HZ                 15779UL
#define SL_DT_US_Q16                    ((uint32_t)(((1000000ULL << 16) + (SL_FAST_LOOP_HZ / 2U)) / SL_FAST_LOOP_HZ))

/*
 * M365 SVPWM command -> physical alpha/beta phase-voltage scaling.
 * Reconstructed from svpwm(): alpha uses _SQRT3 = 28/16 and beta uses the
 * ideal Clarke geometry. Q20 multipliers avoid 64-bit division in the ISR.
 * Roughly: V_alpha = u_alpha * Vbus / 3511,
 *          V_beta  = -u_beta * Vbus / 3547.
 */
#define SL_U_ALPHA_TO_V_Q20               299LL
#define SL_U_BETA_TO_V_Q20                296LL

/* Radial flux correction bandwidth. Start conservatively. */
#define SL_OBSERVER_GAMMA_PER_SEC          50UL
#define SL_GAMMA_DT_Q16                 ((uint32_t)((((uint64_t)SL_OBSERVER_GAMMA_PER_SEC << 16) + (SL_FAST_LOOP_HZ / 2U)) / SL_FAST_LOOP_HZ))

/* Electrical-angle offset. Leave at zero for observer-only TEST1. */
#define SL_ANGLE_OFFSET_Q31                 0L

/* Observer lock qualification. */
/* TEST1D qualifies rotor motion over 32-fast-loop (~2.03 ms) angle windows.
 * This rejects single-PWM-sample angle ripple without loosening flux/current safety. */
#define SL_QUAL_WINDOW_SAMPLES               32U
#define SL_LOCK_GOOD_SAMPLES                  6U   /* 6 good windows after direction confirmation ~= 12 ms */
#define SL_LOST_BAD_SAMPLES                16U   /* TEST1E: ~32 ms grace after lock */
#define SL_ACQUIRE_TIMEOUT_MS             300U   /* TEST1B: shorter worst-case braking pulse */
#define SL_MIN_ELECTRICAL_RPM             600U   /* 30 mechanical rpm with 20 pole pairs */
#define SL_MAX_ELECTRICAL_RPM            9000U   /* 450 mechanical rpm */
#define SL_LOCK_FLUX_MIN_PERCENT           55U
#define SL_LOCK_FLUX_MAX_PERCENT          145U
#define SL_HOLD_FLUX_MIN_PERCENT           40U   /* post-lock hysteresis only; acquisition still needs >=55% */
#define SL_HOLD_FLUX_MAX_PERCENT          155U   /* post-lock hysteresis only; acquisition still needs <=145% */
#define SL_ACQUIRE_BAD_SAMPLE_PENALTY       1U   /* one bad ~2 ms window only removes one score point */
#define SL_DIRECTION_CONFIRM_WINDOWS          3U   /* ~6 ms stable net rotation before direction is trusted */

/*
 * TEST_VESC1: flying-start layer adapted from mature VESC concepts.
 *
 * We keep the M365 hardware/ADC/SVPWM implementation, but separate:
 *   raw flux-observer angle -> PLL/tracker -> control angle.
 * The tracker is only armed after a few already-qualified observer windows.
 */
#define SL_TRACK_START_GOOD_SAMPLES          2U   /* start tracker before final lock */
#define SL_PLL_LOCK_WINDOWS                  4U   /* ~8 ms of coherent observer/tracker agreement */
#define SL_PLL_LOCK_ERROR_DEG                25U
#define SL_PLL_HOLD_ERROR_DEG                45U   /* locked-state safety hysteresis */
#define SL_PLL_PHASE_CORR_SHIFT               4U   /* proportional phase correction per fast sample */
#define SL_PLL_SPEED_CORR_SHIFT              15U   /* integral/speed correction per fast sample */

/*
 * BEMF feed-forward, analogous to VESC current-controller decoupling.
 * TEST_VESC1 intentionally starts at 50% compensation to verify sign safely.
 * Once verified this can be raised toward 100%.
 */
#define SL_BEMF_FF_PERCENT                   50U
/*
 * TEST_VESC2A: two ultra-short zero-vector probes for flying-start seeding.
 * Each probe lasts only two current samples (~127 us total).
 * The probes are separated by ~10 ms of true high-impedance coast.
 */
#define SL_SEED_PROBE_SAMPLES                 3U   /* first-to-third sample slope = 2 fast periods */
#define SL_SEED_GAP_US                     8000U   /* ISR-timed coast; not dependent on 20 ms slow loop */
#define SL_SEED_GAP_FAST_SAMPLES         ((uint32_t)(((uint64_t)SL_FAST_LOOP_HZ * SL_SEED_GAP_US + 999999ULL) / 1000000ULL))
#define SL_SEED_MIN_ERPM                    400U
#define SL_SEED_MAX_ERPM                   3000U   /* 8 ms gap => <144 electrical deg at max */
#define SL_SEED_MIN_BEMF_MV                 400U
#define SL_SEED_MAX_BEMF_MV               20000U
#define SL_SEED_SPEED_TOL_PERCENT           35U   /* two consecutive speed estimates must agree */
#define SL_UQ_TO_PHASE_MV_DENOM            3529L  /* ~average of alpha/beta M365 scaling denominators */

/* ------------------------------------------------------------------------- */
/* Current-loop tuning for this measured ~0.10 ohm / 0.605 mH phase-equivalent
 * motor. Approximate current-loop bandwidth is ~200-250 Hz around 36-42 V.
 * TEST1 commands zero current, so these gains only try to cancel BEMF current.
 */
#define SL_PI_P_IQ                        1800
#define SL_PI_I_IQ                          18
#define SL_PI_P_ID                        1800
#define SL_PI_I_ID                          18

/* TEST1 independent over-current trip. */
#define SENSORLESS_HARD_PHASE_CURRENT_MA  4000

/* TEST1 voltage-vector cap (~30% of the normal software modulation limit). */
#define SENSORLESS_TEST1_U_MAX              600  /* acquisition ceiling */
#define SENSORLESS_TEST1_LOCKED_U_MAX       900  /* TEST_VESC1: tracker/locked zero-current headroom */

/* Future TEST2 torque limits. TEST1 never uses them for torque. */
#define PH_CURRENT_MAX_ECO                 500
#define PH_CURRENT_MAX_NORMAL              800
#define PH_CURRENT_MAX_SPORT              1200
#define BATTERYCURRENT_MAX                1500

/* No regenerative braking during early sensorless tests. */
#define REGEN_CURRENT                        0
#define REGEN_CURRENT_MAX                    0

/* No field weakening during early tests. */
#define FIELD_WEAKNING_CURRENT_MAX           0

/* Speed values are only dashboard/mode bookkeeping at this stage. */
#define SPEEDLIMIT_ECO                      10
#define SPEEDLIMIT_NORMAL                   20
#define SPEEDLIMIT_SPORT                    25

/* Battery protection. */
#define BATTERYVOLTAGE_MIN               30000
#define BATTERYVOLTAGE_MAX               42500

/* Require throttle release after boot/fault before another acquisition. */
#define SENSORLESS_REQUIRE_THROTTLE_RELEASE 1

/* TEST1 sanity checks. */
#if SENSORLESS_PARAMS_READY
  #if (MOTOR_POLE_PAIRS == 0U)
    #error "Set MOTOR_POLE_PAIRS"
  #endif
  #if (MOTOR_LINE_RESISTANCE_MOHM == 0U) || (MOTOR_LINE_INDUCTANCE_UH == 0U) || (MOTOR_FLUX_LINKAGE_UWB == 0U)
    #error "Motor R/L/flux parameters must be non-zero"
  #endif
#endif

#if (SENSORLESS_TEST_STAGE < 0) || (SENSORLESS_TEST_STAGE > 2)
  #error "SENSORLESS_TEST_STAGE must be 0, 1, or 2"
#endif

#endif /* CONFIG_H_ */
