#include <stdlib.h>
#include <arm_math.h>
#include "main.h"
#include "motor.h"
#include "print.h"
#include "eeprom.h"
#include "config.h"
#include "sensorless.h"
#include "button_processing.h"

#define TRIGGER_OFFSET_ADC 50
#define TRIGGER_DEFAULT 2020
#define _T 2028

#define iabs(x) (((x) >= 0)?(x):-(x))
#define sign(x) (((x) >= 0)?(1):(-1))

#define _U_MAX	2000L

// Square Root of 3
#define _SQRT3	28  //1.73205081*16

#define JSQR_PHASE_A 0b00011000000000000000 //3
#define JSQR_PHASE_B 0b00100000000000000000 //4
#define JSQR_PHASE_C 0b00101000000000000000 //5

typedef struct {
	q31_t i_d;
	q31_t i_q;
	q31_t i_q_setpoint;
	q31_t i_d_setpoint;
	q31_t i_setpoint_abs;
	int32_t i_q_setpoint_temp;
	int32_t i_d_setpoint_temp;
	q31_t u_d;
	q31_t u_q;
	q31_t u_abs;
	q31_t Battery_Current;
	uint8_t char_dyn_adc_state;
	int8_t system_state;
	int8_t error_state;
	int16_t phase_current_limit;
  int16_t spec_angle;
  bool brake_active;
  enum angle_estimation angle_estimation;
	int16_t KV_detect_flag;
  bool hall_angle_detect_flag;
} MotorState_t;

typedef struct
{
	int16_t gain_p;
	int16_t gain_i;
	int16_t limit_i;
	int16_t limit_output;
	int16_t recent_value;
	int32_t setpoint;
	int32_t integral_part;
	int16_t max_step;
	int32_t out;
	int8_t shift;
} PI_control_t;

// EEPROM number of variables to use
uint16_t VirtAddVarTab[NB_OF_VAR] = {
  0x01,
  0x02,
  0x03
};

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hdma_adc1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;  // HAL timebase handle owned by stm32f1xx_hal_timebase_tim.c

uint16_t adcData1[6 * sizeof(uint32_t)]; // point to buffer for ADC1 inputs

MotorState_t MS;

int16_t i16_ph1_current = 0;
int16_t i16_ph2_current = 0;
int16_t i16_ph2_current_filter = 0;
uint8_t ui8_adc_inj_flag = 0;
q31_t raw_inj1;
q31_t raw_inj2;
uint8_t ui8_hall_state = 0;
uint8_t ui8_hall_state_old = 0;
uint8_t ui8_hall_case = 0;
bool ui8_BC_limit_flag = false;
uint16_t ui16_halls_tim2tics; // timertics between two hall events for 60° interpolation
uint16_t ui16_halls_tim2tics_filtered = 5000;
bool ui8_6step_flag = false;
q31_t q31_rotorposition_absolute;
q31_t q31_rotorposition_hall;
q31_t q31_rotorposition_motor_specific = SPEC_ANGLE;
q31_t q31_rotorposition_PLL = 0;
q31_t q31_angle_per_tic = 0;
q31_t q31_PLL_error = 0;
int8_t i8_recent_rotor_direction = 1;
int16_t i16_hall_order = 1;

// rotor angle scaled from degree to q31 for arm_math. -180°-->-2^31, 0°-->0, +180°-->+2^31 read in from EEPROM
q31_t Hall_13 = 0;
q31_t Hall_32 = 0;
q31_t Hall_26 = 0;
q31_t Hall_64 = 0;
q31_t Hall_51 = 0;
q31_t Hall_45 = 0;

const q31_t deg_30 = 357913941;

q31_t switchtime[3];
bool ui8_overflow_flag = false;
char char_dyn_adc_state_old = 1;
q31_t q31_tics_filtered = 128000;
q31_t q31_t_Battery_Current_accumulated = 0;
int8_t i8_direction = REVERSE;
int8_t i8_reverse_flag = 1; //for temporaribly reverse direction
q31_t q31_u_d_temp = 0;
q31_t q31_u_q_temp = 0;
int16_t i16_sinus = 0;
int16_t i16_cosinus = 0;
uint16_t uint16_half_rotation_counter = 0;
uint16_t uint16_full_rotation_counter = 0;

static q31_t tics_lower_limit;
static q31_t tics_higher_limit;

//Rotor angle scaled from degree to q31 for arm_math. -180°-->-2^31, 0°-->0, +180°-->+2^31
const q31_t DEG_0 = 0;
const q31_t DEG_plus60 = 715827883;
const q31_t DEG_plus120 = 1431655765;
const q31_t DEG_plus180 = 2147483647;
const q31_t DEG_minus60 = -715827883;
const q31_t DEG_minus120 = -1431655765;

uint16_t ui16_reg_adc_value;
uint32_t ui32_reg_adc_value_filter;
uint8_t ui8_adc_regular_flag = 0;
uint16_t ui16_ph1_offset = 0;
uint16_t ui16_ph2_offset = 0;
uint16_t ui16_ph3_offset = 0;

uint16_t ui16_KV_detect_counter = 0; // for getting timing of the KV detect
static int16_t ui32_KV = 0;

uint32_t uint32_SPEEDx100_cumulated = 0;

/* Global public-state pointer is needed by passive ADC callbacks below. */
MotorStatePublic_t* p_MotorStatePublic;


#if PHASE_VOLTAGE_TEST0
/*
 * PHASE_VOLTAGE_TEST0 / PASSIVE_PLL_TEST1 / FOC_ANGLE_MAPPING_TEST1
 * --------------------------
 * Passive rotor/BEMF diagnostics only. TIM1 power PWM is never started.
 *
 * ADC regular-scan layout:
 *   0 ADC2 = battery
 *   1 ADC6 = phase A voltage
 *   2 ADC0 = temperature
 *   3 ADC7 = phase B voltage
 *   4 ADC9 = phase C voltage
 *   5 ADC3 = current-A raw diagnostic
 */
#define PV_ADC_IDX_BATTERY   0U
#define PV_ADC_IDX_PHASE_A   1U
#define PV_ADC_IDX_TEMP      2U
#define PV_ADC_IDX_PHASE_B   3U
#define PV_ADC_IDX_PHASE_C   4U
#define PV_ADC_IDX_CURRENT_A 5U

/* Live, continuously changing values. */
volatile uint32_t pv_dbg_adc_a = 0;
volatile uint32_t pv_dbg_adc_b = 0;
volatile uint32_t pv_dbg_adc_c = 0;
volatile uint32_t pv_dbg_current_a_raw = 0;
volatile uint32_t pv_dbg_va_mv = 0;
volatile uint32_t pv_dbg_vb_mv = 0;
volatile uint32_t pv_dbg_vc_mv = 0;
volatile int32_t  pv_dbg_common_mv = 0;
volatile int32_t  pv_dbg_a_center_mv = 0;
volatile int32_t  pv_dbg_b_center_mv = 0;
volatile int32_t  pv_dbg_c_center_mv = 0;
volatile int32_t  pv_dbg_alpha_mv = 0;
volatile int32_t  pv_dbg_beta_mv = 0;
volatile uint32_t pv_dbg_bemf_mag_mv = 0;
volatile int32_t  pv_dbg_bemf_angle_q31 = 0;
volatile int32_t  pv_dbg_angle_step_q31 = 0;
volatile int32_t  pv_dbg_angle_step_deg_x100 = 0;
volatile int32_t  pv_dbg_erpm_instant = 0;
volatile int32_t  pv_dbg_erpm_signed = 0;
volatile uint32_t pv_dbg_erpm_abs = 0;
volatile uint32_t pv_dbg_mrpm = 0;
volatile int32_t  pv_dbg_dir = 0;
volatile uint32_t pv_dbg_vector_valid = 0;
volatile uint32_t pv_dbg_expected_mag_mv = 0;
volatile uint32_t pv_dbg_mag_percent = 0;
volatile uint32_t pv_dbg_clip_low_mask = 0;
volatile uint32_t pv_dbg_clip_high_mask = 0;
volatile uint32_t pv_dbg_sample_counter = 0;       /* raw ADC/DMA callbacks */
volatile uint32_t pv_dbg_process_counter = 0;      /* decimated vector samples */
volatile uint32_t pv_dbg_speed_update_counter = 0;
volatile uint32_t pv_dbg_invalid_counter_total = 0;
volatile uint32_t pv_dbg_angle_jump_count_total = 0;
volatile uint32_t pv_dbg_battery_adc = 0;
volatile uint32_t pv_dbg_battery_mv = 0;
volatile uint32_t pv_dbg_phase_span_mv = 0;
volatile uint32_t pv_dbg_pwm_enabled = 0;
volatile uint32_t pv_dbg_pwm_violation_count = 0;
volatile uint32_t pv_dbg_tim1_moe = 0;
volatile uint32_t pv_dbg_tim1_cen = 0;
volatile uint32_t pv_dbg_tim1_ccer = 0;

/* Callback execution-time diagnostics. DWT runs at the core clock. */
volatile uint32_t pv_dbg_isr_cycles_last = 0;
volatile uint32_t pv_dbg_isr_cycles_max_boot = 0;
volatile uint32_t pv_dbg_isr_period_cycles = 0;
volatile uint32_t pv_dbg_isr_load_permille_max_boot = 0;
volatile uint32_t pv_dbg_adc_error_count = 0;
volatile uint32_t pv_dbg_adc_error_code = 0;
static volatile uint32_t pv_isr_cycles_window_max_accum = 0;

/*
 * Coherent one-shot capture.
 * In Live Expressions set pv_snap_request=1. Firmware captures ALL pv_snap_*
 * fields from one processed ADC vector, increments pv_snap_id, then clears
 * pv_snap_request back to 0. The captured values remain frozen afterwards.
 */
volatile uint32_t pv_snap_request = 1;
volatile uint32_t pv_snap_id = 0;
volatile uint32_t pv_snap_tick_ms = 0;
volatile uint32_t pv_snap_sample_counter = 0;
volatile uint32_t pv_snap_adc_a = 0;
volatile uint32_t pv_snap_adc_b = 0;
volatile uint32_t pv_snap_adc_c = 0;
volatile uint32_t pv_snap_current_a_raw = 0;
volatile uint32_t pv_snap_va_mv = 0;
volatile uint32_t pv_snap_vb_mv = 0;
volatile uint32_t pv_snap_vc_mv = 0;
volatile int32_t  pv_snap_common_mv = 0;
volatile int32_t  pv_snap_a_center_mv = 0;
volatile int32_t  pv_snap_b_center_mv = 0;
volatile int32_t  pv_snap_c_center_mv = 0;
volatile int32_t  pv_snap_alpha_mv = 0;
volatile int32_t  pv_snap_beta_mv = 0;
volatile uint32_t pv_snap_bemf_mag_mv = 0;
volatile int32_t  pv_snap_bemf_angle_q31 = 0;
volatile int32_t  pv_snap_angle_step_deg_x100 = 0;
volatile int32_t  pv_snap_erpm_signed = 0;
volatile uint32_t pv_snap_mrpm = 0;
volatile int32_t  pv_snap_dir = 0;
volatile uint32_t pv_snap_vector_valid = 0;
volatile uint32_t pv_snap_clip_low_mask = 0;
volatile uint32_t pv_snap_clip_high_mask = 0;
volatile uint32_t pv_snap_phase_span_mv = 0;
volatile uint32_t pv_snap_battery_mv = 0;
#if PV_PASSIVE_PLL_TEST1
volatile uint32_t pv_snap_pll_state = 0;
volatile uint32_t pv_snap_pll_confidence = 0;
volatile int32_t  pv_snap_pll_angle_q31 = 0;
volatile int32_t  pv_snap_pll_phase_error_deg_x100 = 0;
volatile int32_t  pv_snap_pll_erpm = 0;
volatile uint32_t pv_snap_pll_valid_age_samples = 0;
#if PV_FOC_ANGLE_MAPPING_TEST1
volatile uint32_t pv_snap_map_valid = 0;
volatile int32_t  pv_snap_map_flux_angle_q31 = 0;
volatile int32_t  pv_snap_map_bemf_minus_flux_deg_x100 = 0;
volatile int32_t  pv_snap_map_quadrature_error_deg_x100 = 0;
volatile int32_t  pv_snap_map_bemf_d_mv = 0;
volatile int32_t  pv_snap_map_bemf_q_mv = 0;
volatile uint32_t pv_snap_map_ed_abs_permille = 0;
volatile uint32_t pv_snap_map_eq_sign_ok = 0;
#if PV_FOC_HANDOFF_PREP_TEST1
volatile uint32_t pv_snap_ho_valid = 0;
volatile uint32_t pv_snap_ho_ready = 0;
volatile uint32_t pv_snap_ho_reject_mask = 0;
volatile int32_t  pv_snap_ho_preload_ud = 0;
volatile int32_t  pv_snap_ho_preload_uq = 0;
volatile int32_t  pv_snap_ho_pred_alpha_mv = 0;
volatile int32_t  pv_snap_ho_pred_beta_mv = 0;
volatile uint32_t pv_snap_ho_match_error_mv = 0;
volatile uint32_t pv_snap_ho_match_error_permille = 0;
volatile uint32_t pv_snap_ho_u_abs = 0;
volatile int32_t  pv_snap_ho_duty_a_counts = 0;
volatile int32_t  pv_snap_ho_duty_b_counts = 0;
volatile int32_t  pv_snap_ho_duty_c_counts = 0;
volatile uint32_t pv_snap_ho_duty_span_permille = 0;
#endif
#endif
#endif

/* Automatically latched ~1-second statistics. */
volatile uint32_t pv_stat_window_id = 0;
volatile uint32_t pv_stat_adc_samples = 0;
volatile uint32_t pv_stat_processed_samples = 0;
volatile uint32_t pv_stat_valid_samples = 0;
volatile uint32_t pv_stat_invalid_samples = 0;
volatile uint32_t pv_stat_valid_permille = 0;
volatile uint32_t pv_stat_low_a_count = 0;
volatile uint32_t pv_stat_low_b_count = 0;
volatile uint32_t pv_stat_low_c_count = 0;
volatile uint32_t pv_stat_high_a_count = 0;
volatile uint32_t pv_stat_high_b_count = 0;
volatile uint32_t pv_stat_high_c_count = 0;
volatile uint32_t pv_stat_low_a_permille = 0;
volatile uint32_t pv_stat_low_b_permille = 0;
volatile uint32_t pv_stat_low_c_permille = 0;
volatile uint32_t pv_stat_high_a_permille = 0;
volatile uint32_t pv_stat_high_b_permille = 0;
volatile uint32_t pv_stat_high_c_permille = 0;
volatile uint32_t pv_stat_bemf_min_mv = 0;
volatile uint32_t pv_stat_bemf_max_mv = 0;
volatile uint32_t pv_stat_bemf_avg_mv = 0;
volatile uint32_t pv_stat_span_min_mv = 0;
volatile uint32_t pv_stat_span_max_mv = 0;
volatile uint32_t pv_stat_span_avg_mv = 0;
volatile uint32_t pv_stat_current_a_raw_min = 0;
volatile uint32_t pv_stat_current_a_raw_max = 0;
volatile uint32_t pv_stat_current_a_raw_avg = 0;
volatile uint32_t pv_stat_step_samples = 0;
volatile uint32_t pv_stat_step_abs_min_deg_x100 = 0;
volatile uint32_t pv_stat_step_abs_max_deg_x100 = 0;
volatile uint32_t pv_stat_step_abs_avg_deg_x100 = 0;
volatile uint32_t pv_stat_angle_jump_count = 0;
volatile uint32_t pv_stat_speed_samples = 0;
volatile int32_t  pv_stat_erpm_min = 0;
volatile int32_t  pv_stat_erpm_max = 0;
volatile int32_t  pv_stat_erpm_avg = 0;
volatile uint32_t pv_stat_mrpm_abs_avg = 0;
volatile uint32_t pv_stat_dir_flip_count = 0;
volatile uint32_t pv_stat_isr_cycles_max = 0;
volatile uint32_t pv_stat_isr_load_permille = 0;

#if PV_PASSIVE_PLL_TEST1
/*
 * Passive PLL Live Expressions.
 * State: 0=SEARCH, 1=ACQUIRE, 2=LOCKED/correcting, 3=LOCKED/holdover.
 * All of these are diagnostics only; no value here can enable the bridge.
 */
volatile uint32_t pv_pll_reset_request = 0;
volatile uint32_t pv_pll_state = 0;
volatile uint32_t pv_pll_locked = 0;
volatile uint32_t pv_pll_confidence = 0;
volatile int32_t  pv_pll_raw_angle_q31 = 0;
volatile int32_t  pv_pll_angle_q31 = 0;
volatile int32_t  pv_pll_omega_q31_per_sample = 0;
volatile int32_t  pv_pll_phase_error_q31 = 0;
volatile int32_t  pv_pll_phase_error_deg_x100 = 0;
volatile uint32_t pv_pll_phase_error_abs_deg_x100 = 0;
volatile int32_t  pv_pll_erpm = 0;
volatile uint32_t pv_pll_mrpm = 0;
volatile int32_t  pv_pll_dir = 0;
volatile uint32_t pv_pll_valid_age_samples = 0;
volatile uint32_t pv_pll_valid_age_ms = 0;
volatile uint32_t pv_pll_lock_count = 0;
volatile uint32_t pv_pll_loss_count = 0;
volatile uint32_t pv_pll_good_corrections_total = 0;
volatile uint32_t pv_pll_weak_corrections_total = 0;
volatile uint32_t pv_pll_bad_corrections_total = 0;
volatile uint32_t pv_pll_holdover_samples_total = 0;
volatile uint32_t pv_pll_acq_deltas = 0;
volatile uint32_t pv_pll_acq_gap_samples = 0;
volatile int32_t  pv_pll_acq_erpm_est = 0;
volatile uint32_t pv_pll_acq_coherence_permille = 0;

/* Independent ~1 s PLL statistics. */
volatile uint32_t pv_pll_stat_window_id = 0;
volatile uint32_t pv_pll_stat_locked_permille = 0;
volatile uint32_t pv_pll_stat_holdover_permille = 0;
volatile uint32_t pv_pll_stat_error_samples = 0;
volatile uint32_t pv_pll_stat_phase_err_abs_min_deg_x100 = 0;
volatile uint32_t pv_pll_stat_phase_err_abs_avg_deg_x100 = 0;
volatile uint32_t pv_pll_stat_phase_err_abs_max_deg_x100 = 0;
volatile int32_t  pv_pll_stat_erpm_min = 0;
volatile int32_t  pv_pll_stat_erpm_avg = 0;
volatile int32_t  pv_pll_stat_erpm_max = 0;
volatile uint32_t pv_pll_stat_conf_min = 0;
volatile uint32_t pv_pll_stat_conf_avg = 0;
volatile uint32_t pv_pll_stat_conf_max = 0;

#if PV_FOC_ANGLE_MAPPING_TEST1
/*
 * Passive FOC angle/mapping diagnostics.
 * Runtime values are derived only from the passive phase-voltage vector and
 * PLL; they have no path to TIM1, MOE, SVPWM, PI regulators, or current setpoints.
 */
volatile uint32_t pv_map_valid = 0;
volatile int32_t  pv_map_flux_angle_q31 = 0;
volatile int32_t  pv_map_flux_angle_deg_x100 = 0;
volatile int32_t  pv_map_bemf_minus_flux_deg_x100 = 0;
volatile int32_t  pv_map_expected_bemf_minus_flux_deg_x100 = 0;
volatile int32_t  pv_map_quadrature_error_deg_x100 = 0;
volatile uint32_t pv_map_quadrature_error_abs_deg_x100 = 0;
volatile int32_t  pv_map_bemf_d_mv = 0;
volatile int32_t  pv_map_bemf_q_mv = 0;
volatile uint32_t pv_map_ed_abs_permille = 0;
volatile uint32_t pv_map_eq_abs_permille = 0;
volatile uint32_t pv_map_eq_sign_ok = 0;

/* Static chain audit from SCO_DRV V1.4 schematic + this firmware mapping. */
volatile uint32_t pv_map_voltage_a_adc = 6U;
volatile uint32_t pv_map_voltage_b_adc = 7U;
volatile uint32_t pv_map_voltage_c_adc = 9U;
volatile uint32_t pv_map_current_a_adc = 3U;
volatile uint32_t pv_map_current_b_adc = 4U;
volatile uint32_t pv_map_current_c_adc = 5U;
volatile uint32_t pv_map_pwm_a_tim_ch = 1U;
volatile uint32_t pv_map_pwm_b_tim_ch = 2U;
volatile uint32_t pv_map_pwm_c_tim_ch = 3U;
volatile uint32_t pv_map_static_chain_ok = 1U;

/* Independent ~1 s mapping statistics. */
volatile uint32_t pv_map_stat_window_id = 0;
volatile uint32_t pv_map_stat_samples = 0;
volatile uint32_t pv_map_stat_valid_permille = 0;
volatile uint32_t pv_map_stat_eq_sign_ok_permille = 0;
volatile uint32_t pv_map_stat_quadrature_err_abs_avg_deg_x100 = 0;
volatile uint32_t pv_map_stat_quadrature_err_abs_max_deg_x100 = 0;
volatile uint32_t pv_map_stat_ed_abs_avg_mv = 0;
volatile uint32_t pv_map_stat_ed_abs_max_mv = 0;
volatile uint32_t pv_map_stat_eq_abs_avg_mv = 0;
volatile uint32_t pv_map_stat_ed_abs_permille_avg = 0;
volatile uint32_t pv_map_stat_ed_abs_permille_max = 0;

#if PV_FOC_HANDOFF_PREP_TEST1
/*
 * Passive handoff-preparation diagnostics.  All values below are SHADOW
 * calculations only.  They never touch TIM1 CCR registers, MOE, switchtime[],
 * MS.u_d/u_q, or the live PI integrators.
 */
volatile uint32_t pv_ho_valid = 0;
volatile uint32_t pv_ho_ready = 0;
volatile uint32_t pv_ho_reject_mask = 0;
volatile uint32_t pv_ho_vbus_mv = 0;
volatile uint32_t pv_ho_bemf_mag_mv = 0;
volatile int32_t  pv_ho_erpm = 0;
volatile int32_t  pv_ho_flux_angle_q31 = 0;
volatile int32_t  pv_ho_cmd_alpha = 0;
volatile int32_t  pv_ho_cmd_beta = 0;
volatile int32_t  pv_ho_preload_ud = 0;
volatile int32_t  pv_ho_preload_uq = 0;
volatile int32_t  pv_ho_pi_id_integral_candidate = 0;
volatile int32_t  pv_ho_pi_iq_integral_candidate = 0;
volatile int32_t  pv_ho_recon_cmd_alpha = 0;
volatile int32_t  pv_ho_recon_cmd_beta = 0;
volatile int32_t  pv_ho_pred_alpha_mv = 0;
volatile int32_t  pv_ho_pred_beta_mv = 0;
volatile uint32_t pv_ho_match_error_mv = 0;
volatile uint32_t pv_ho_match_error_permille = 0;
volatile uint32_t pv_ho_u_abs = 0;
volatile uint32_t pv_ho_voltage_util_permille = 0;
volatile int32_t  pv_ho_uq_vs_dir = 0;
volatile int32_t  pv_ho_duty_a_counts = 0;
volatile int32_t  pv_ho_duty_b_counts = 0;
volatile int32_t  pv_ho_duty_c_counts = 0;
volatile uint32_t pv_ho_duty_a_permille = 0;
volatile uint32_t pv_ho_duty_b_permille = 0;
volatile uint32_t pv_ho_duty_c_permille = 0;
volatile uint32_t pv_ho_duty_span_permille = 0;

/* Independent ~1 s shadow-handoff statistics. */
volatile uint32_t pv_ho_stat_window_id = 0;
volatile uint32_t pv_ho_stat_samples = 0;
volatile uint32_t pv_ho_stat_valid_permille = 0;
volatile uint32_t pv_ho_stat_ready_permille = 0;
volatile uint32_t pv_ho_stat_reject_or_mask = 0;
volatile int32_t  pv_ho_stat_preload_ud_avg = 0;
volatile int32_t  pv_ho_stat_preload_uq_avg = 0;
volatile uint32_t pv_ho_stat_u_abs_avg = 0;
volatile uint32_t pv_ho_stat_u_abs_max = 0;
volatile uint32_t pv_ho_stat_voltage_util_avg_permille = 0;
volatile uint32_t pv_ho_stat_duty_span_avg_permille = 0;
volatile uint32_t pv_ho_stat_duty_span_max_permille = 0;
volatile uint32_t pv_ho_stat_match_err_avg_mv = 0;
volatile uint32_t pv_ho_stat_match_err_max_mv = 0;
volatile uint32_t pv_ho_stat_match_err_avg_permille = 0;
volatile uint32_t pv_ho_stat_match_err_max_permille = 0;

#if PV_ACTIVE_HANDOFF_TEST1
/*
 * First active one-shot handoff diagnostics.
 * state: 0=IDLE, 1=ACTIVE, 2=DONE, 3=ABORTED.
 * User writes pv_act_arm=1 to request one pulse and pv_act_reset=1 to re-arm
 * after DONE/ABORTED.  No automatic repeat path exists.
 */
volatile uint32_t pv_act_arm = 0;
volatile uint32_t pv_act_reset = 0;
volatile uint32_t pv_act_state = 0;
volatile uint32_t pv_act_hw_ready = 0;
volatile uint32_t pv_act_arm_count = 0;
volatile uint32_t pv_act_run_count = 0;
volatile uint32_t pv_act_success_count = 0;
volatile uint32_t pv_act_abort_count = 0;
volatile uint32_t pv_act_arm_reject_count = 0;
volatile uint32_t pv_act_arm_reject_mask = 0;
volatile uint32_t pv_act_abort_reason = 0;
volatile uint32_t pv_act_elapsed_us = 0;
volatile uint32_t pv_act_injected_callbacks = 0;
volatile uint32_t pv_act_injected_callbacks_total = 0;

/* FIX13 physical-voltage gain calibration. User may edit voltage_scale_permille
 * in Live Expressions before ARM. The request is clamped to 130..170% and the
 * applied value is latched with each one-shot run. Start at 1650 permille;
 * test 1700 only after reviewing the 1650 pulse. */
volatile uint32_t pv_act_voltage_scale_permille = 1650U;
volatile uint32_t pv_act_scale_applied_permille = 0U;
volatile uint32_t pv_act_scale_clamp_count = 0U;
volatile int32_t  pv_act_scaled_ud = 0;
volatile int32_t  pv_act_scaled_uq = 0;
volatile uint32_t pv_act_scaled_u_abs = 0U;

/* FIX13: angle is deliberately locked to 0.00 electrical degree by config.h
 * while voltage gain is calibrated. The variable remains exposed so Live
 * Expressions can confirm both requested and applied values. */
volatile int32_t  pv_act_angle_offset_deg_x100 = 0;
volatile int32_t  pv_act_angle_applied_deg_x100 = 0;
volatile int32_t  pv_act_angle_applied_q31 = 0;
volatile uint32_t pv_act_angle_clamp_count = 0U;

/* Signed active-current tendency during the very short FIX10/FIX11 pulse.  These are
 * diagnostic only; current feedback still does not close the control loop. */
volatile uint32_t pv_act_diag_samples = 0U;
volatile int32_t  pv_act_diag_first_id_inst_ma = 0;
volatile int32_t  pv_act_diag_first_iq_inst_ma = 0;
volatile int32_t  pv_act_diag_last_id_inst_ma = 0;
volatile int32_t  pv_act_diag_last_iq_inst_ma = 0;
volatile int32_t  pv_act_diag_avg_id_inst_ma = 0;
volatile int32_t  pv_act_diag_avg_iq_inst_ma = 0;
volatile uint32_t pv_act_diag_peak_abs_id_inst_ma = 0U;
volatile uint32_t pv_act_diag_peak_abs_iq_inst_ma = 0U;
volatile int32_t  pv_act_diag_iq_delta_ma = 0;
static int64_t pv_act_diag_sum_id_ma = 0;
static int64_t pv_act_diag_sum_iq_ma = 0;

/* Bridge-off current-sense preflight. FIX6 uses TIM1 TRGO (OC4REF source)
 * for injected conversions while JEOC interrupt remains disabled in passive
 * mode. The slow-loop diagnostic consumes the latest offset-corrected A/B
 * results and builds a rolling 256-sample preflight window. */
volatile uint32_t pv_act_idle_current_samples_total = 0;
volatile uint32_t pv_act_idle_current_window_id = 0;
volatile uint32_t pv_act_idle_current_window_samples = 0;
volatile int32_t  pv_act_idle_i_a_ma = 0;
volatile int32_t  pv_act_idle_i_b_ma = 0;
volatile uint32_t pv_act_idle_peak_ma_last = 0;
volatile uint32_t pv_act_idle_avg_abs_ma_last = 0;
volatile uint32_t pv_act_idle_current_ok = 0;

/* FIX9: qualified bridge-off idle-current readiness.  A single good window
 * is not enough to arm: PV_ACT_IDLE_REQUIRED_GOOD_WINDOWS consecutive windows
 * must remain below PV_ACT_MAX_IDLE_CURRENT_MA. Any failing window drops ready
 * immediately and restarts the streak. */
volatile uint32_t pv_act_idle_window_ok_last = 0;
volatile uint32_t pv_act_idle_good_streak = 0;
volatile uint32_t pv_act_idle_good_streak_max = 0;
volatile uint32_t pv_act_idle_pass_windows_total = 0;
volatile uint32_t pv_act_idle_fail_windows_total = 0;
volatile uint32_t pv_act_idle_peak_max_since_boot = 0;

/* FIX7_CURRENT_NOISE_DIAG: per-channel bridge-off noise statistics.
 * Min/max are signed offset-corrected ADC counts (zero current ~= 0 counts).
 * Threshold counters are the number of samples in the last 256-sample window
 * whose absolute current exceeded 300/600/900/1200 mA. Diagnostics only:
 * safety limits and arm conditions are intentionally unchanged. */
volatile uint32_t pv_act_noise_window_id = 0;
volatile uint32_t pv_act_noise_samples_last = 0;
volatile uint32_t pv_act_noise_a_peak_ma_last = 0;
volatile uint32_t pv_act_noise_b_peak_ma_last = 0;
volatile uint32_t pv_act_noise_a_avg_abs_ma_last = 0;
volatile uint32_t pv_act_noise_b_avg_abs_ma_last = 0;
volatile int32_t  pv_act_noise_a_min_counts_last = 0;
volatile int32_t  pv_act_noise_a_max_counts_last = 0;
volatile int32_t  pv_act_noise_b_min_counts_last = 0;
volatile int32_t  pv_act_noise_b_max_counts_last = 0;
volatile uint32_t pv_act_noise_a_over300_last = 0;
volatile uint32_t pv_act_noise_b_over300_last = 0;
volatile uint32_t pv_act_noise_a_over600_last = 0;
volatile uint32_t pv_act_noise_b_over600_last = 0;
volatile uint32_t pv_act_noise_a_over900_last = 0;
volatile uint32_t pv_act_noise_b_over900_last = 0;
volatile uint32_t pv_act_noise_a_over1200_last = 0;
volatile uint32_t pv_act_noise_b_over1200_last = 0;

/* Current-offset calibration diagnostics (ADC counts). */
volatile uint32_t pv_act_offset_a_adc1 = 0;
volatile uint32_t pv_act_offset_b_adc2 = 0;
volatile uint32_t pv_act_offset_c_adc1 = 0;
volatile uint32_t pv_act_offset_c_adc2 = 0;
volatile uint32_t pv_act_offset_spread_counts = 0;
volatile uint32_t pv_act_offset_cal_ok = 0;

/* ACTIVE_HANDOFF_TEST1_FIX1 startup diagnostics.
 * pv_act_init_stage is monotonic during motor_init; if startup falls into the
 * motor error handler it remains at the exact stage that failed. */
volatile uint32_t pv_act_init_stage = 0;
volatile uint32_t pv_act_init_error_count = 0;
volatile uint32_t pv_act_init_error_line = 0;
volatile uint32_t pv_act_init_adc1_state = 0;
volatile uint32_t pv_act_init_adc2_state = 0;
volatile uint32_t pv_act_init_adc1_error = 0;
volatile uint32_t pv_act_init_adc2_error = 0;
volatile uint32_t pv_act_init_adc1_cr1 = 0;
volatile uint32_t pv_act_init_adc1_cr2 = 0;
volatile uint32_t pv_act_init_adc2_cr1 = 0;
volatile uint32_t pv_act_init_adc2_cr2 = 0;
volatile uint32_t pv_act_init_tim1_cr1 = 0;
volatile uint32_t pv_act_init_tim1_bdtr = 0;

/* Coherent values captured at the exact passive->active handoff. */
volatile int32_t  pv_act_start_erpm = 0;
volatile int32_t  pv_act_start_flux_angle_q31 = 0;
volatile int32_t  pv_act_start_ud = 0;
volatile int32_t  pv_act_start_uq = 0;
volatile int32_t  pv_act_start_duty_a = 0;
volatile int32_t  pv_act_start_duty_b = 0;
volatile int32_t  pv_act_start_duty_c = 0;
volatile uint32_t pv_act_start_bemf_mv = 0;
volatile uint32_t pv_act_start_match_error_permille = 0;
volatile uint32_t pv_act_start_vbus_mv = 0;

/* Active-window live/latched diagnostics. */
volatile int32_t  pv_act_angle_q31 = 0;
volatile int32_t  pv_act_i_a_ma = 0;
volatile int32_t  pv_act_i_b_ma = 0;
volatile int32_t  pv_act_i_c_ma = 0;
volatile int32_t  pv_act_id_ma = 0;
volatile int32_t  pv_act_iq_ma = 0;
volatile uint32_t pv_act_peak_phase_ma = 0;
volatile uint32_t pv_act_peak_id_ma = 0;
volatile uint32_t pv_act_peak_iq_ma = 0;
volatile uint32_t pv_act_peak_u_abs = 0;
volatile uint32_t pv_act_last_u_abs = 0;
volatile int32_t  pv_act_last_ud = 0;
volatile int32_t  pv_act_last_uq = 0;
volatile int32_t  pv_act_last_duty_a = 0;
volatile int32_t  pv_act_last_duty_b = 0;
volatile int32_t  pv_act_last_duty_c = 0;
volatile uint32_t pv_act_pwm_was_enabled = 0;
volatile uint32_t pv_act_tim1_cen = 0;
volatile uint32_t pv_act_tim1_ccer = 0;
volatile uint32_t pv_act_tim1_moe = 0;

/* FIX9 active-current trip diagnostics. These values are latched before MOE
 * is cleared, so an over-current abort can be distinguished from an isolated
 * ADC/switching spike. The trace is a circular history of the most recent
 * active injected-current samples, including the sample that caused a trip. */
volatile uint32_t pv_act_trip_valid = 0;
volatile uint32_t pv_act_trip_callback_index = 0;
volatile uint32_t pv_act_trip_elapsed_us = 0;
volatile uint32_t pv_act_trip_dyn_state = 0;
volatile uint32_t pv_act_trip_adc1_channel = 0;
volatile uint32_t pv_act_trip_adc2_channel = 0;
volatile int32_t  pv_act_trip_raw1_counts = 0;
volatile int32_t  pv_act_trip_raw2_counts = 0;
volatile int32_t  pv_act_trip_ia_ma = 0;
volatile int32_t  pv_act_trip_ib_ma = 0;
volatile int32_t  pv_act_trip_ic_ma = 0;
volatile int32_t  pv_act_trip_id_inst_ma = 0;
volatile int32_t  pv_act_trip_iq_inst_ma = 0;
volatile int32_t  pv_act_trip_prev_id_ma = 0;
volatile int32_t  pv_act_trip_prev_iq_ma = 0;
volatile uint32_t pv_act_trip_pmax_ma = 0;
volatile uint32_t pv_act_trip_prev_pmax_ma = 0;
volatile int32_t  pv_act_trip_angle_q31 = 0;
volatile uint32_t pv_act_trip_tim1_cnt = 0;
volatile uint32_t pv_act_trip_ccr1 = 0;
volatile uint32_t pv_act_trip_ccr2 = 0;
volatile uint32_t pv_act_trip_ccr3 = 0;
volatile uint32_t pv_act_trip_ccr4 = 0;
volatile uint32_t pv_act_trip_adc1_smpr2 = 0;
volatile uint32_t pv_act_trip_adc2_smpr2 = 0;

volatile uint32_t pv_act_active_over300_count = 0;
volatile uint32_t pv_act_active_over600_count = 0;
volatile uint32_t pv_act_active_over900_count = 0;
volatile uint32_t pv_act_active_over1200_count = 0;
volatile uint32_t pv_act_active_streak_over600 = 0;
volatile uint32_t pv_act_active_streak_over900 = 0;
volatile uint32_t pv_act_active_max_streak_over600 = 0;
volatile uint32_t pv_act_active_max_streak_over900 = 0;
volatile uint32_t pv_act_active_first_over600_cb = 0;
volatile uint32_t pv_act_active_first_over900_cb = 0;

volatile uint32_t pv_act_trace_write_index = 0;
volatile uint32_t pv_act_trace_count = 0;
volatile uint32_t pv_act_trace_callback[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile uint32_t pv_act_trace_elapsed_us[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile uint32_t pv_act_trace_dyn_state[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile int32_t  pv_act_trace_raw1_counts[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile int32_t  pv_act_trace_raw2_counts[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile int32_t  pv_act_trace_ia_ma[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile int32_t  pv_act_trace_ib_ma[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile int32_t  pv_act_trace_ic_ma[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile uint32_t pv_act_trace_pmax_ma[PV_ACT_TRIP_TRACE_SAMPLES] = {0};
volatile uint32_t pv_act_trace_tim1_cnt[PV_ACT_TRIP_TRACE_SAMPLES] = {0};

static uint32_t pv_act_start_cycles = 0;
static uint32_t pv_act_last_angle_cycles = 0;
static uint32_t pv_act_prev_pmax_ma = 0;
static void pv_act_idle_current_diag_step(void);
static void pv_act_try_arm_from_passive(void);
#endif
#endif
#endif
#endif

/* Same compact atan approximation family already used by observer tests. */
static const uint16_t pv_atan_lut[101] = {
    0,209,417,626,834,1042,1250,1458,1665,1872,2079,2285,2491,2697,2902,3106,
    3310,3513,3715,3917,4118,4318,4517,4716,4914,5110,5306,5501,5695,5888,6080,
    6271,6461,6649,6837,7023,7209,7393,7576,7757,7938,8117,8295,8472,8647,8821,
    8994,9165,9336,9504,9672,9838,10003,10167,10329,10490,10649,10807,10964,11119,
    11274,11426,11578,11728,11876,12024,12170,12314,12458,12600,12740,12880,13018,
    13154,13290,13424,13557,13688,13819,13948,14076,14202,14328,14452,14575,14696,
    14817,14936,15054,15171,15287,15402,15515,15628,15739,15849,15958,16066,16173,
    16279,16383
};

static q31_t pv_atan2_q31(int32_t y, int32_t x, q31_t fallback)
{
  if (x == 0 && y == 0) return fallback;

  int64_t ax = (x < 0) ? -(int64_t)x : (int64_t)x;
  int64_t ay = (y < 0) ? -(int64_t)y : (int64_t)y;
  uint32_t idx;
  uint32_t frac;
  int32_t base;

  if (ax >= ay) {
    idx = (uint32_t)((ay * 100LL) / ax);
    if (idx > 99U) idx = 99U;
    frac = (uint32_t)((ay * 1000LL) / ax) - 10U * idx;
    base = (int32_t)pv_atan_lut[idx] +
           (int32_t)(((int32_t)pv_atan_lut[idx + 1U] -
                      (int32_t)pv_atan_lut[idx]) * (int32_t)frac / 10);
  } else {
    idx = (uint32_t)((ax * 100LL) / ay);
    if (idx > 99U) idx = 99U;
    frac = (uint32_t)((ax * 1000LL) / ay) - 10U * idx;
    base = 32767 - ((int32_t)pv_atan_lut[idx] +
           (int32_t)(((int32_t)pv_atan_lut[idx + 1U] -
                      (int32_t)pv_atan_lut[idx]) * (int32_t)frac / 10));
  }

  int32_t angle16;
  if (x >= 0 && y >= 0) angle16 = base;
  else if (x < 0 && y >= 0) angle16 = 65535 - base;
  else if (x < 0 && y < 0) angle16 = -65535 + base;
  else angle16 = -base;

  return (q31_t)((int64_t)angle16 << 15);
}

static int64_t pv_wrap_q31_delta(q31_t now, q31_t old)
{
  int64_t d = (int64_t)now - (int64_t)old;
  if (d > INT32_MAX) d -= 4294967296LL;
  if (d < INT32_MIN) d += 4294967296LL;
  return d;
}

static uint32_t pv_abs_i32(int32_t x)
{
  return (uint32_t)((x < 0) ? -(int64_t)x : (int64_t)x);
}

static uint32_t pv_abs_i64_to_u32(int64_t x)
{
  uint64_t a = (x < 0) ? (uint64_t)(-x) : (uint64_t)x;
  if (a > 0xFFFFFFFFULL) a = 0xFFFFFFFFULL;
  return (uint32_t)a;
}

static uint32_t pv_vec_mag_approx(int32_t a, int32_t b)
{
  uint32_t aa = pv_abs_i32(a);
  uint32_t bb = pv_abs_i32(b);
  uint32_t hi = aa > bb ? aa : bb;
  uint32_t lo = aa > bb ? bb : aa;
  return hi + ((3U * lo) >> 3);
}

static uint32_t pv_adc_to_phase_mv(uint32_t adc)
{
  return (uint32_t)(((uint64_t)adc * PV_PHASE_FULL_SCALE_MV +
                    (PV_ADC_FULL_SCALE_COUNTS / 2U)) /
                    PV_ADC_FULL_SCALE_COUNTS);
}

#if PV_PASSIVE_PLL_TEST1
static int32_t pv_pll_omega_to_erpm(int32_t omega_q31_per_sample)
{
  int64_t n = (int64_t)omega_q31_per_sample * (int64_t)PV_PROCESS_HZ * 60LL;
  return (int32_t)(n / 4294967296LL);
}

static int32_t pv_pll_erpm_to_omega(int32_t erpm)
{
  int64_t n = (int64_t)erpm * 4294967296LL;
  int64_t d = (int64_t)PV_PROCESS_HZ * 60LL;
  if (d == 0) return 0;
  n /= d;
  if (n > INT32_MAX) n = INT32_MAX;
  if (n < INT32_MIN) n = INT32_MIN;
  return (int32_t)n;
}

static int32_t pv_q31_to_deg_x100(int32_t q)
{
  return (int32_t)(((int64_t)q * 36000LL) / 4294967296LL);
}

static int32_t pv_q31_add_wrap(int32_t a, int32_t b)
{
  return (int32_t)((uint32_t)a + (uint32_t)b);
}

static void pv_passive_pll_step(bool raw_valid, q31_t raw_angle, uint32_t raw_mag_mv)
{
  (void)raw_mag_mv; /* kept for future confidence weighting; thresholding is upstream */

  enum { PLL_SEARCH = 0, PLL_ACQUIRE = 1, PLL_LOCKED = 2, PLL_HOLDOVER = 3 };

  static int32_t phase = 0;
  static int32_t omega = 0;
  static uint32_t confidence = 0;
  static uint32_t bad_streak = 0;
  static uint32_t valid_age = 0;
  static uint32_t sample_index = 0;

  static bool acq_have_last = false;
  static q31_t acq_last_angle = 0;
  static uint32_t acq_last_sample = 0;
  static int64_t acq_delta_sum = 0;
  static uint64_t acq_abs_delta_sum = 0;
  static uint32_t acq_gap_sum = 0;
  static uint32_t acq_deltas = 0;

  /* Independent one-second PLL statistics. */
  static uint32_t st_samples = 0;
  static uint32_t st_locked = 0;
  static uint32_t st_holdover = 0;
  static uint32_t st_err_samples = 0;
  static uint64_t st_err_abs_sum = 0;
  static uint32_t st_err_abs_min = 0xFFFFFFFFU;
  static uint32_t st_err_abs_max = 0;
  static int64_t st_erpm_sum = 0;
  static int32_t st_erpm_min = INT32_MAX;
  static int32_t st_erpm_max = INT32_MIN;
  static uint64_t st_conf_sum = 0;
  static uint32_t st_conf_min = 0xFFFFFFFFU;
  static uint32_t st_conf_max = 0;

  sample_index++;
  pv_pll_raw_angle_q31 = raw_angle;

  if (pv_pll_reset_request != 0U) {
    phase = raw_angle;
    omega = 0;
    confidence = 0;
    bad_streak = 0;
    valid_age = 0;
    acq_have_last = false;
    acq_delta_sum = 0;
    acq_abs_delta_sum = 0;
    acq_gap_sum = 0;
    acq_deltas = 0;
    pv_pll_state = PLL_SEARCH;
    pv_pll_locked = 0U;
    pv_pll_reset_request = 0U;
  }

  const int32_t omega_max = pv_pll_erpm_to_omega((int32_t)PV_PLL_MAX_ERPM);

  if (pv_pll_locked == 0U) {
    pv_pll_state = acq_have_last ? PLL_ACQUIRE : PLL_SEARCH;
    pv_pll_phase_error_q31 = 0;
    pv_pll_phase_error_deg_x100 = 0;
    pv_pll_phase_error_abs_deg_x100 = 0U;
    pv_pll_valid_age_samples = 0U;
    pv_pll_valid_age_ms = 0U;
    confidence = 0U;

    if (raw_valid) {
      if (!acq_have_last) {
        acq_have_last = true;
        acq_last_angle = raw_angle;
        acq_last_sample = sample_index;
        phase = raw_angle;
        acq_delta_sum = 0;
        acq_abs_delta_sum = 0;
        acq_gap_sum = 0;
        acq_deltas = 0;
      } else {
        uint32_t gap = sample_index - acq_last_sample;
        if (gap == 0U) gap = 1U;

        if (gap <= PV_PLL_ACQUIRE_MAX_GAP_SAMPLES) {
          const int64_t delta = pv_wrap_q31_delta(raw_angle, acq_last_angle);
          const uint64_t delta_abs = (delta < 0) ? (uint64_t)(-delta) : (uint64_t)delta;
          const uint64_t max_delta = (uint64_t)pv_abs_i32(omega_max) * (uint64_t)gap;

          if (delta_abs <= max_delta) {
            acq_delta_sum += delta;
            acq_abs_delta_sum += delta_abs;
            acq_gap_sum += gap;
            acq_deltas++;
          } else {
            /* Implausible movement: restart acquisition from this valid sample. */
            acq_delta_sum = 0;
            acq_abs_delta_sum = 0;
            acq_gap_sum = 0;
            acq_deltas = 0;
          }
        } else {
          acq_delta_sum = 0;
          acq_abs_delta_sum = 0;
          acq_gap_sum = 0;
          acq_deltas = 0;
        }

        acq_last_angle = raw_angle;
        acq_last_sample = sample_index;
        phase = raw_angle;

        if (acq_gap_sum > 0U) {
          int64_t avg_omega64 = acq_delta_sum / (int64_t)acq_gap_sum;
          if (avg_omega64 > INT32_MAX) avg_omega64 = INT32_MAX;
          if (avg_omega64 < INT32_MIN) avg_omega64 = INT32_MIN;
          const int32_t avg_omega = (int32_t)avg_omega64;
          pv_pll_acq_erpm_est = pv_pll_omega_to_erpm(avg_omega);

          if (acq_abs_delta_sum > 0ULL) {
            uint64_t abs_sum = (acq_delta_sum < 0) ?
                               (uint64_t)(-acq_delta_sum) : (uint64_t)acq_delta_sum;
            uint64_t coh = (abs_sum * 1000ULL) / acq_abs_delta_sum;
            if (coh > 1000ULL) coh = 1000ULL;
            pv_pll_acq_coherence_permille = (uint32_t)coh;
          } else {
            pv_pll_acq_coherence_permille = 0U;
          }

          if ((acq_deltas >= PV_PLL_ACQUIRE_DELTAS) &&
              (pv_abs_i32(pv_pll_acq_erpm_est) >= PV_PLL_ACQUIRE_MIN_ERPM) &&
              (pv_pll_acq_coherence_permille >= PV_PLL_ACQUIRE_COHERENCE_PERMILLE)) {
            phase = raw_angle;
            omega = avg_omega;
            confidence = PV_PLL_CONF_LOCK_INIT;
            bad_streak = 0U;
            valid_age = 0U;
            pv_pll_locked = 1U;
            pv_pll_state = PLL_LOCKED;
            pv_pll_lock_count++;
          }
        }
      }
    } else if (acq_have_last &&
               ((sample_index - acq_last_sample) > PV_PLL_ACQUIRE_RESET_GAP_SAMPLES)) {
      acq_have_last = false;
      acq_delta_sum = 0;
      acq_abs_delta_sum = 0;
      acq_gap_sum = 0;
      acq_deltas = 0;
      pv_pll_acq_erpm_est = 0;
      pv_pll_acq_coherence_permille = 0U;
    }

    pv_pll_acq_deltas = acq_deltas;
    pv_pll_acq_gap_samples = acq_gap_sum;
  } else {
    /* LOCKED: always predict. Valid BEMF samples then correct phase/frequency. */
    const int32_t predicted = pv_q31_add_wrap(phase, omega);

    if (raw_valid) {
      const int32_t err = (int32_t)pv_wrap_q31_delta(raw_angle, predicted);
      const int32_t err_deg_x100 = pv_q31_to_deg_x100(err);
      const uint32_t err_abs_deg_x100 = pv_abs_i32(err_deg_x100);

      const int32_t phase_corr = (int32_t)(((int64_t)err * PV_PLL_KP_Q15) >> 15);
      const int32_t omega_corr = (int32_t)(((int64_t)err * PV_PLL_KI_Q15) >> 15);
      phase = pv_q31_add_wrap(predicted, phase_corr);

      int64_t omega64 = (int64_t)omega + (int64_t)omega_corr;
      if (omega64 > omega_max) omega64 = omega_max;
      if (omega64 < -(int64_t)omega_max) omega64 = -(int64_t)omega_max;
      omega = (int32_t)omega64;

      pv_pll_phase_error_q31 = err;
      pv_pll_phase_error_deg_x100 = err_deg_x100;
      pv_pll_phase_error_abs_deg_x100 = err_abs_deg_x100;
      valid_age = 0U;

      st_err_abs_sum += err_abs_deg_x100;
      if (err_abs_deg_x100 < st_err_abs_min) st_err_abs_min = err_abs_deg_x100;
      if (err_abs_deg_x100 > st_err_abs_max) st_err_abs_max = err_abs_deg_x100;
      st_err_samples++;

      if (err_abs_deg_x100 <= PV_PLL_GOOD_ERR_DEG_X100) {
        confidence += PV_PLL_CONF_GOOD_INC;
        if (confidence > 1000U) confidence = 1000U;
        bad_streak = 0U;
        pv_pll_good_corrections_total++;
      } else if (err_abs_deg_x100 <= PV_PLL_BAD_ERR_DEG_X100) {
        confidence += PV_PLL_CONF_WEAK_INC;
        if (confidence > 1000U) confidence = 1000U;
        bad_streak = 0U;
        pv_pll_weak_corrections_total++;
      } else {
        confidence = (confidence > PV_PLL_CONF_BAD_DEC) ?
                     (confidence - PV_PLL_CONF_BAD_DEC) : 0U;
        bad_streak++;
        pv_pll_bad_corrections_total++;
      }
      pv_pll_state = PLL_LOCKED;
    } else {
      phase = predicted;
      if (valid_age < 0xFFFFFFFFU) valid_age++;
      confidence = (confidence > PV_PLL_CONF_INVALID_DEC) ?
                   (confidence - PV_PLL_CONF_INVALID_DEC) : 0U;
      pv_pll_phase_error_q31 = 0;
      pv_pll_phase_error_deg_x100 = 0;
      pv_pll_phase_error_abs_deg_x100 = 0U;
      pv_pll_state = PLL_HOLDOVER;
      pv_pll_holdover_samples_total++;
    }

    if ((valid_age > PV_PLL_INVALID_LOSS_SAMPLES) ||
        (bad_streak >= PV_PLL_BAD_STREAK_LIMIT) ||
        (confidence < PV_PLL_CONF_LOSS)) {
      pv_pll_locked = 0U;
      pv_pll_state = PLL_SEARCH;
      pv_pll_loss_count++;
      confidence = 0U;
      bad_streak = 0U;
      valid_age = 0U;
      omega = 0;
      phase = raw_angle;
      acq_have_last = false;
      acq_delta_sum = 0;
      acq_abs_delta_sum = 0;
      acq_gap_sum = 0;
      acq_deltas = 0;
      pv_pll_acq_deltas = 0U;
      pv_pll_acq_gap_samples = 0U;
      pv_pll_acq_erpm_est = 0;
      pv_pll_acq_coherence_permille = 0U;
    }
  }

  pv_pll_confidence = confidence;
  pv_pll_angle_q31 = phase;
  pv_pll_omega_q31_per_sample = omega;
  pv_pll_erpm = pv_pll_omega_to_erpm(omega);
  pv_pll_mrpm = (MOTOR_POLE_PAIRS > 0U) ?
                (pv_abs_i32(pv_pll_erpm) / MOTOR_POLE_PAIRS) : 0U;
  pv_pll_dir = (pv_pll_erpm > 0) ? 1 : ((pv_pll_erpm < 0) ? -1 : 0);
  pv_pll_valid_age_samples = valid_age;
  pv_pll_valid_age_ms = (uint32_t)(((uint64_t)valid_age * 1000ULL) / PV_PROCESS_HZ);

  /* Publish independent PLL stats approximately once per second. */
  st_samples++;
  if (pv_pll_locked != 0U) {
    st_locked++;
    if (pv_pll_state == PLL_HOLDOVER) st_holdover++;

    st_erpm_sum += pv_pll_erpm;
    if (pv_pll_erpm < st_erpm_min) st_erpm_min = pv_pll_erpm;
    if (pv_pll_erpm > st_erpm_max) st_erpm_max = pv_pll_erpm;

    st_conf_sum += confidence;
    if (confidence < st_conf_min) st_conf_min = confidence;
    if (confidence > st_conf_max) st_conf_max = confidence;
  }

  if (st_samples >= PV_DIAG_WINDOW_SAMPLES) {
    pv_pll_stat_window_id++;
    pv_pll_stat_locked_permille = (st_locked * 1000U) / st_samples;
    pv_pll_stat_holdover_permille = (st_holdover * 1000U) / st_samples;
    pv_pll_stat_error_samples = st_err_samples;
    pv_pll_stat_phase_err_abs_min_deg_x100 =
        (st_err_abs_min == 0xFFFFFFFFU) ? 0U : st_err_abs_min;
    pv_pll_stat_phase_err_abs_max_deg_x100 = st_err_abs_max;
    pv_pll_stat_phase_err_abs_avg_deg_x100 = (st_err_samples > 0U) ?
        (uint32_t)(st_err_abs_sum / st_err_samples) : 0U;

    if (st_locked > 0U) {
      pv_pll_stat_erpm_min = st_erpm_min;
      pv_pll_stat_erpm_max = st_erpm_max;
      pv_pll_stat_erpm_avg = (int32_t)(st_erpm_sum / (int64_t)st_locked);
      pv_pll_stat_conf_min = (st_conf_min == 0xFFFFFFFFU) ? 0U : st_conf_min;
      pv_pll_stat_conf_max = st_conf_max;
      pv_pll_stat_conf_avg = (uint32_t)(st_conf_sum / st_locked);
    } else {
      pv_pll_stat_erpm_min = 0;
      pv_pll_stat_erpm_max = 0;
      pv_pll_stat_erpm_avg = 0;
      pv_pll_stat_conf_min = 0U;
      pv_pll_stat_conf_avg = 0U;
      pv_pll_stat_conf_max = 0U;
    }

    st_samples = 0U;
    st_locked = 0U;
    st_holdover = 0U;
    st_err_samples = 0U;
    st_err_abs_sum = 0ULL;
    st_err_abs_min = 0xFFFFFFFFU;
    st_err_abs_max = 0U;
    st_erpm_sum = 0;
    st_erpm_min = INT32_MAX;
    st_erpm_max = INT32_MIN;
    st_conf_sum = 0ULL;
    st_conf_min = 0xFFFFFFFFU;
    st_conf_max = 0U;
  }
}

#if PV_FOC_ANGLE_MAPPING_TEST1
#define PV_MAP_DEG90_Q31 ((int32_t)1073741824L)

static void pv_map_clear_live(void)
{
  pv_map_valid = 0U;
  pv_map_flux_angle_q31 = 0;
  pv_map_flux_angle_deg_x100 = 0;
  pv_map_bemf_minus_flux_deg_x100 = 0;
  pv_map_expected_bemf_minus_flux_deg_x100 = 0;
  pv_map_quadrature_error_deg_x100 = 0;
  pv_map_quadrature_error_abs_deg_x100 = 0U;
  pv_map_bemf_d_mv = 0;
  pv_map_bemf_q_mv = 0;
  pv_map_ed_abs_permille = 0U;
  pv_map_eq_abs_permille = 0U;
  pv_map_eq_sign_ok = 0U;
}

#if PV_FOC_HANDOFF_PREP_TEST1
static uint32_t pv_ho_duty_permille(int32_t duty)
{
  if (duty <= 0) return 0U;
  if (duty >= _T) return 1000U;
  return (uint32_t)(((uint64_t)(uint32_t)duty * 1000ULL) / (uint32_t)_T);
}

static void pv_ho_shadow_svpwm(int32_t u_alpha,
                               int32_t u_beta,
                               int32_t *da,
                               int32_t *db,
                               int32_t *dc)
{
  const int32_t U_alpha = (int32_t)(((int64_t)_SQRT3 * _T * u_alpha) >> 4);
  const int32_t U_beta = (int32_t)(-(int64_t)_T * u_beta);
  const int32_t X = U_beta;
  const int32_t Y = (U_alpha + U_beta) >> 1;
  const int32_t Z = (U_beta - U_alpha) >> 1;

  int32_t a = (_T >> 1);
  int32_t b = (_T >> 1);
  int32_t c = (_T >> 1);

  if ((Y >= 0 && Z < 0 && X > 0) || (Y < 0 && Z >= 0 && X <= 0)) {
    a = ((_T + X - Z) >> 12) + (_T >> 1);
    b = a + (Z >> 11);
    c = b - (X >> 11);
  } else if ((Y >= 0 && Z >= 0) || (Y < 0 && Z < 0)) {
    a = ((_T + Y - Z) >> 12) + (_T >> 1);
    b = a + (Z >> 11);
    c = a - (Y >> 11);
  } else {
    a = ((_T + Y - X) >> 12) + (_T >> 1);
    c = a - (Y >> 11);
    b = c + (X >> 11);
  }

  *da = a;
  *db = b;
  *dc = c;
}

static void pv_ho_publish_zero_candidate(uint32_t reject_mask,
                                         uint32_t vbus_mv,
                                         uint32_t mag_mv)
{
  pv_ho_valid = 0U;
  pv_ho_ready = 0U;
  pv_ho_reject_mask = reject_mask;
  pv_ho_vbus_mv = vbus_mv;
  pv_ho_bemf_mag_mv = mag_mv;
  pv_ho_erpm = pv_pll_erpm;
  pv_ho_flux_angle_q31 = 0;
  pv_ho_cmd_alpha = 0;
  pv_ho_cmd_beta = 0;
  pv_ho_preload_ud = 0;
  pv_ho_preload_uq = 0;
  pv_ho_pi_id_integral_candidate = 0;
  pv_ho_pi_iq_integral_candidate = 0;
  pv_ho_recon_cmd_alpha = 0;
  pv_ho_recon_cmd_beta = 0;
  pv_ho_pred_alpha_mv = 0;
  pv_ho_pred_beta_mv = 0;
  pv_ho_match_error_mv = 0U;
  pv_ho_match_error_permille = 0U;
  pv_ho_u_abs = 0U;
  pv_ho_voltage_util_permille = 0U;
  pv_ho_uq_vs_dir = 0;
  pv_ho_duty_a_counts = 0;
  pv_ho_duty_b_counts = 0;
  pv_ho_duty_c_counts = 0;
  pv_ho_duty_a_permille = 0U;
  pv_ho_duty_b_permille = 0U;
  pv_ho_duty_c_permille = 0U;
  pv_ho_duty_span_permille = 0U;
}

static void pv_handoff_prep_step(bool map_valid,
                                 int32_t alpha_mv,
                                 int32_t beta_mv,
                                 uint32_t mag_mv,
                                 int32_t flux_angle,
                                 q31_t sinevalue,
                                 q31_t cosinevalue,
                                 uint32_t eq_sign_ok,
                                 uint32_t quad_err_abs_deg_x100)
{
  static uint32_t st_samples = 0U;
  static uint32_t st_valid = 0U;
  static uint32_t st_ready = 0U;
  static uint32_t st_reject_or = 0U;
  static int64_t st_ud_sum = 0;
  static int64_t st_uq_sum = 0;
  static uint64_t st_u_abs_sum = 0ULL;
  static uint32_t st_u_abs_max = 0U;
  static uint64_t st_util_sum = 0ULL;
  static uint64_t st_duty_span_sum = 0ULL;
  static uint32_t st_duty_span_max = 0U;
  static uint64_t st_match_mv_sum = 0ULL;
  static uint32_t st_match_mv_max = 0U;
  static uint64_t st_match_permille_sum = 0ULL;
  static uint32_t st_match_permille_max = 0U;

  const uint32_t vbus_mv = pv_dbg_battery_mv;
  const uint32_t erpm_abs = pv_abs_i32(pv_pll_erpm);
  uint32_t reject = 0U;

  if ((pv_pll_locked == 0U) || (pv_pll_state != 2U) ||
      (pv_pll_valid_age_samples != 0U)) {
    reject |= PV_HO_REJ_PLL_STATE;
  }
  if (pv_pll_confidence < PV_HO_MIN_PLL_CONFIDENCE) {
    reject |= PV_HO_REJ_CONFIDENCE;
  }
  if (!map_valid || (mag_mv < PV_BEMF_VALID_MIN_MV) || (eq_sign_ok == 0U) ||
      (pv_map_static_chain_ok == 0U)) {
    reject |= PV_HO_REJ_SIGNAL_MAP;
  }
  if ((erpm_abs < PV_HO_MIN_ERPM) || (erpm_abs > PV_HO_MAX_ERPM)) {
    reject |= PV_HO_REJ_SPEED;
  }
  if ((vbus_mv < BATTERYVOLTAGE_MIN) || (vbus_mv > BATTERYVOLTAGE_MAX)) {
    reject |= PV_HO_REJ_VBUS;
  }
  if (pv_dbg_clip_high_mask != 0U) {
    reject |= PV_HO_REJ_HIGH_CLIP;
  }
  if ((quad_err_abs_deg_x100 > PV_HO_MAX_QUAD_ERR_DEG_X100) ||
      (eq_sign_ok == 0U)) {
    reject |= PV_HO_REJ_ANGLE_MAP;
  }
  if (pv_dbg_adc_error_count != 0U) {
    reject |= PV_HO_REJ_ADC_ERROR;
  }

  bool candidate_valid = map_valid && (vbus_mv > 0U);
  int32_t preload_ud = 0;
  int32_t preload_uq = 0;
  uint32_t u_abs = 0U;
  uint32_t util_permille = 0U;
  uint32_t duty_span_permille = 0U;
  uint32_t match_error_mv = 0U;
  uint32_t match_error_permille = 0U;

  if (candidate_valid) {
    /*
     * Invert the experimentally reconstructed M365 SVPWM voltage scaling:
     *   physical V_alpha = cmd_alpha * Vbus * SL_U_ALPHA_TO_V_Q20 / 2^20
     *   physical V_beta  =-cmd_beta  * Vbus * SL_U_BETA_TO_V_Q20  / 2^20
     * so the shadow command below should recreate the measured passive BEMF.
     */
    const int64_t den_a = (int64_t)vbus_mv * (int64_t)SL_U_ALPHA_TO_V_Q20;
    const int64_t den_b = (int64_t)vbus_mv * (int64_t)SL_U_BETA_TO_V_Q20;
    int32_t cmd_alpha = 0;
    int32_t cmd_beta = 0;
    if ((den_a != 0) && (den_b != 0)) {
      cmd_alpha = (int32_t)(((int64_t)alpha_mv * 1048576LL) / den_a);
      cmd_beta = (int32_t)((-(int64_t)beta_mv * 1048576LL) / den_b);
    } else {
      candidate_valid = false;
    }

    if (candidate_valid) {
      /* Inverse of FOC_calculation() arm_inv_park(..., -sin, cos). */
      preload_ud = (int32_t)((((int64_t)cmd_alpha * cosinevalue) -
                              ((int64_t)cmd_beta * sinevalue)) >> 31);
      preload_uq = (int32_t)((((int64_t)cmd_alpha * sinevalue) +
                              ((int64_t)cmd_beta * cosinevalue)) >> 31);

      const int32_t recon_alpha = (int32_t)((((int64_t)preload_ud * cosinevalue) +
                                              ((int64_t)preload_uq * sinevalue)) >> 31);
      const int32_t recon_beta = (int32_t)(((-(int64_t)preload_ud * sinevalue) +
                                             ((int64_t)preload_uq * cosinevalue)) >> 31);

      const int32_t pred_alpha_mv = (int32_t)(
          ((int64_t)recon_alpha * (int64_t)vbus_mv *
           (int64_t)SL_U_ALPHA_TO_V_Q20) / 1048576LL);
      const int32_t pred_beta_mv = (int32_t)(
          (-(int64_t)recon_beta * (int64_t)vbus_mv *
           (int64_t)SL_U_BETA_TO_V_Q20) / 1048576LL);

      const int32_t err_alpha = pred_alpha_mv - alpha_mv;
      const int32_t err_beta = pred_beta_mv - beta_mv;
      match_error_mv = pv_vec_mag_approx(err_alpha, err_beta);
      match_error_permille = (mag_mv > 0U) ?
          (uint32_t)(((uint64_t)match_error_mv * 1000ULL) / mag_mv) : 0U;

      u_abs = pv_vec_mag_approx(preload_ud, preload_uq);
      util_permille = (uint32_t)(((uint64_t)u_abs * 1000ULL) / (uint32_t)SENSORLESS_TEST1_U_MAX);
      if (u_abs > PV_HO_MAX_U_ABS) {
        reject |= PV_HO_REJ_VOLTAGE_CMD;
      }

      int32_t da = 0, db = 0, dc = 0;
      pv_ho_shadow_svpwm(recon_alpha, recon_beta, &da, &db, &dc);
      int32_t dmin = da;
      int32_t dmax = da;
      if (db < dmin) dmin = db;
      if (dc < dmin) dmin = dc;
      if (db > dmax) dmax = db;
      if (dc > dmax) dmax = dc;
      duty_span_permille = (dmax > dmin) ?
          (uint32_t)(((uint64_t)(uint32_t)(dmax - dmin) * 1000ULL) / (uint32_t)_T) : 0U;

      const int32_t duty_hi_limit = (int32_t)_T - (int32_t)PV_HO_DUTY_MARGIN_COUNTS;
      if ((da < (int32_t)PV_HO_DUTY_MARGIN_COUNTS) || (da > duty_hi_limit) ||
          (db < (int32_t)PV_HO_DUTY_MARGIN_COUNTS) || (db > duty_hi_limit) ||
          (dc < (int32_t)PV_HO_DUTY_MARGIN_COUNTS) || (dc > duty_hi_limit)) {
        reject |= PV_HO_REJ_DUTY_MARGIN;
      }

      pv_ho_valid = 1U;
      pv_ho_vbus_mv = vbus_mv;
      pv_ho_bemf_mag_mv = mag_mv;
      pv_ho_erpm = pv_pll_erpm;
      pv_ho_flux_angle_q31 = flux_angle;
      pv_ho_cmd_alpha = cmd_alpha;
      pv_ho_cmd_beta = cmd_beta;
      pv_ho_preload_ud = preload_ud;
      pv_ho_preload_uq = preload_uq;
      pv_ho_pi_id_integral_candidate =
          (int32_t)(-(int64_t)preload_ud * (1LL << PV_HO_PI_SHIFT));
      pv_ho_pi_iq_integral_candidate =
          (int32_t)((int64_t)preload_uq * (1LL << PV_HO_PI_SHIFT));
      pv_ho_recon_cmd_alpha = recon_alpha;
      pv_ho_recon_cmd_beta = recon_beta;
      pv_ho_pred_alpha_mv = pred_alpha_mv;
      pv_ho_pred_beta_mv = pred_beta_mv;
      pv_ho_match_error_mv = match_error_mv;
      pv_ho_match_error_permille = match_error_permille;
      pv_ho_u_abs = u_abs;
      pv_ho_voltage_util_permille = util_permille;
      pv_ho_uq_vs_dir = (preload_uq > 0) ? pv_pll_dir :
                        ((preload_uq < 0) ? -pv_pll_dir : 0);
      pv_ho_duty_a_counts = da;
      pv_ho_duty_b_counts = db;
      pv_ho_duty_c_counts = dc;
      pv_ho_duty_a_permille = pv_ho_duty_permille(da);
      pv_ho_duty_b_permille = pv_ho_duty_permille(db);
      pv_ho_duty_c_permille = pv_ho_duty_permille(dc);
      pv_ho_duty_span_permille = duty_span_permille;
    }
  }

  if (!candidate_valid) {
    reject |= PV_HO_REJ_SIGNAL_MAP;
    pv_ho_publish_zero_candidate(reject, vbus_mv, mag_mv);
  } else {
    pv_ho_reject_mask = reject;
    pv_ho_ready = (reject == 0U) ? 1U : 0U;
  }

  st_samples++;
  st_reject_or |= reject;
  if (candidate_valid) {
    st_valid++;
    if (reject == 0U) st_ready++;
    st_ud_sum += preload_ud;
    st_uq_sum += preload_uq;
    st_u_abs_sum += u_abs;
    if (u_abs > st_u_abs_max) st_u_abs_max = u_abs;
    st_util_sum += util_permille;
    st_duty_span_sum += duty_span_permille;
    if (duty_span_permille > st_duty_span_max) st_duty_span_max = duty_span_permille;
    st_match_mv_sum += match_error_mv;
    if (match_error_mv > st_match_mv_max) st_match_mv_max = match_error_mv;
    st_match_permille_sum += match_error_permille;
    if (match_error_permille > st_match_permille_max) {
      st_match_permille_max = match_error_permille;
    }
  }

  const uint32_t ho_window =
      (PV_DIAG_WINDOW_SAMPLES + PV_MAP_DIAG_DECIMATION - 1U) /
      PV_MAP_DIAG_DECIMATION;
  if (st_samples >= ho_window) {
    pv_ho_stat_window_id++;
    pv_ho_stat_samples = st_samples;
    pv_ho_stat_valid_permille = (st_valid * 1000U) / st_samples;
    pv_ho_stat_ready_permille = (st_ready * 1000U) / st_samples;
    pv_ho_stat_reject_or_mask = st_reject_or;

    if (st_valid > 0U) {
      pv_ho_stat_preload_ud_avg = (int32_t)(st_ud_sum / (int64_t)st_valid);
      pv_ho_stat_preload_uq_avg = (int32_t)(st_uq_sum / (int64_t)st_valid);
      pv_ho_stat_u_abs_avg = (uint32_t)(st_u_abs_sum / st_valid);
      pv_ho_stat_u_abs_max = st_u_abs_max;
      pv_ho_stat_voltage_util_avg_permille = (uint32_t)(st_util_sum / st_valid);
      pv_ho_stat_duty_span_avg_permille = (uint32_t)(st_duty_span_sum / st_valid);
      pv_ho_stat_duty_span_max_permille = st_duty_span_max;
      pv_ho_stat_match_err_avg_mv = (uint32_t)(st_match_mv_sum / st_valid);
      pv_ho_stat_match_err_max_mv = st_match_mv_max;
      pv_ho_stat_match_err_avg_permille =
          (uint32_t)(st_match_permille_sum / st_valid);
      pv_ho_stat_match_err_max_permille = st_match_permille_max;
    } else {
      pv_ho_stat_preload_ud_avg = 0;
      pv_ho_stat_preload_uq_avg = 0;
      pv_ho_stat_u_abs_avg = 0U;
      pv_ho_stat_u_abs_max = 0U;
      pv_ho_stat_voltage_util_avg_permille = 0U;
      pv_ho_stat_duty_span_avg_permille = 0U;
      pv_ho_stat_duty_span_max_permille = 0U;
      pv_ho_stat_match_err_avg_mv = 0U;
      pv_ho_stat_match_err_max_mv = 0U;
      pv_ho_stat_match_err_avg_permille = 0U;
      pv_ho_stat_match_err_max_permille = 0U;
    }

    st_samples = 0U;
    st_valid = 0U;
    st_ready = 0U;
    st_reject_or = 0U;
    st_ud_sum = 0;
    st_uq_sum = 0;
    st_u_abs_sum = 0ULL;
    st_u_abs_max = 0U;
    st_util_sum = 0ULL;
    st_duty_span_sum = 0ULL;
    st_duty_span_max = 0U;
    st_match_mv_sum = 0ULL;
    st_match_mv_max = 0U;
    st_match_permille_sum = 0ULL;
    st_match_permille_max = 0U;
  }
}
#endif /* PV_FOC_HANDOFF_PREP_TEST1 */

static void pv_foc_angle_mapping_step(bool raw_valid,
                                      int32_t alpha_mv,
                                      int32_t beta_mv,
                                      uint32_t mag_mv)
{
  static uint32_t diag_decim = 0U;
  static uint32_t st_samples = 0U;
  static uint32_t st_valid = 0U;
  static uint32_t st_eq_sign_ok = 0U;
  static uint64_t st_quad_err_abs_sum = 0ULL;
  static uint32_t st_quad_err_abs_max = 0U;
  static uint64_t st_ed_abs_sum = 0ULL;
  static uint32_t st_ed_abs_max = 0U;
  static uint64_t st_eq_abs_sum = 0ULL;
  static uint64_t st_ed_permille_sum = 0ULL;
  static uint32_t st_ed_permille_max = 0U;

  if (++diag_decim < PV_MAP_DIAG_DECIMATION) return;
  diag_decim = 0U;
  st_samples++;

  if ((pv_pll_locked == 0U) || (pv_pll_dir == 0) || !raw_valid) {
    pv_map_clear_live();
#if PV_FOC_HANDOFF_PREP_TEST1
    pv_handoff_prep_step(false, alpha_mv, beta_mv, mag_mv, 0, 0, 0, 0U, 0U);
#endif
  } else {
    const int32_t dir = pv_pll_dir;
    const int32_t flux_angle = pv_q31_add_wrap(
        pv_pll_angle_q31, (dir > 0) ? -PV_MAP_DEG90_Q31 : PV_MAP_DEG90_Q31);
    const int32_t expected_quad = (dir > 0) ? 9000 : -9000;
    const int32_t bemf_minus_flux_q31 =
        (int32_t)pv_wrap_q31_delta(pv_dbg_bemf_angle_q31, flux_angle);
    const int32_t bemf_minus_flux_deg = pv_q31_to_deg_x100(bemf_minus_flux_q31);
    const int32_t expected_q31 = (dir > 0) ? PV_MAP_DEG90_Q31 : -PV_MAP_DEG90_Q31;
    const int32_t quad_err_q31 =
        (int32_t)pv_wrap_q31_delta(bemf_minus_flux_q31, expected_q31);
    const int32_t quad_err_deg = pv_q31_to_deg_x100(quad_err_q31);
    const uint32_t quad_err_abs = pv_abs_i32(quad_err_deg);

    q31_t sinevalue = 0, cosinevalue = 0;
    arm_sin_cos_q31((q31_t)flux_angle, &sinevalue, &cosinevalue);
    if (sinevalue == INT32_MIN) sinevalue = -2147483647;

    /* Same Park convention as FOC_calculation(), but values remain in mV. */
    int64_t d64 = (int64_t)alpha_mv * (int64_t)cosinevalue +
                  (int64_t)beta_mv * (int64_t)sinevalue;
    int64_t q64 = -(int64_t)alpha_mv * (int64_t)sinevalue +
                   (int64_t)beta_mv * (int64_t)cosinevalue;
    const int32_t bemf_d = (int32_t)(d64 >> 31);
    const int32_t bemf_q = (int32_t)(q64 >> 31);
    const uint32_t ed_abs = pv_abs_i32(bemf_d);
    const uint32_t eq_abs = pv_abs_i32(bemf_q);
    const uint32_t ed_permille = (mag_mv > 0U) ?
        (uint32_t)(((uint64_t)ed_abs * 1000ULL) / mag_mv) : 0U;
    const uint32_t eq_permille = (mag_mv > 0U) ?
        (uint32_t)(((uint64_t)eq_abs * 1000ULL) / mag_mv) : 0U;
    const uint32_t eq_sign_ok = (((bemf_q > 0) && (dir > 0)) ||
                                 ((bemf_q < 0) && (dir < 0))) ? 1U : 0U;

    pv_map_valid = 1U;
    pv_map_flux_angle_q31 = flux_angle;
    pv_map_flux_angle_deg_x100 = pv_q31_to_deg_x100(flux_angle);
    pv_map_bemf_minus_flux_deg_x100 = bemf_minus_flux_deg;
    pv_map_expected_bemf_minus_flux_deg_x100 = expected_quad;
    pv_map_quadrature_error_deg_x100 = quad_err_deg;
    pv_map_quadrature_error_abs_deg_x100 = quad_err_abs;
    pv_map_bemf_d_mv = bemf_d;
    pv_map_bemf_q_mv = bemf_q;
    pv_map_ed_abs_permille = ed_permille;
    pv_map_eq_abs_permille = eq_permille;
    pv_map_eq_sign_ok = eq_sign_ok;

#if PV_FOC_HANDOFF_PREP_TEST1
    pv_handoff_prep_step(true, alpha_mv, beta_mv, mag_mv, flux_angle,
                         sinevalue, cosinevalue, eq_sign_ok, quad_err_abs);
#endif

    st_valid++;
    st_eq_sign_ok += eq_sign_ok;
    st_quad_err_abs_sum += quad_err_abs;
    if (quad_err_abs > st_quad_err_abs_max) st_quad_err_abs_max = quad_err_abs;
    st_ed_abs_sum += ed_abs;
    if (ed_abs > st_ed_abs_max) st_ed_abs_max = ed_abs;
    st_eq_abs_sum += eq_abs;
    st_ed_permille_sum += ed_permille;
    if (ed_permille > st_ed_permille_max) st_ed_permille_max = ed_permille;
  }

  const uint32_t map_window =
      (PV_DIAG_WINDOW_SAMPLES + PV_MAP_DIAG_DECIMATION - 1U) /
      PV_MAP_DIAG_DECIMATION;
  if (st_samples >= map_window) {
    pv_map_stat_window_id++;
    pv_map_stat_samples = st_samples;
    pv_map_stat_valid_permille = (st_valid * 1000U) / st_samples;
    pv_map_stat_eq_sign_ok_permille = (st_valid > 0U) ?
        (st_eq_sign_ok * 1000U) / st_valid : 0U;
    pv_map_stat_quadrature_err_abs_avg_deg_x100 = (st_valid > 0U) ?
        (uint32_t)(st_quad_err_abs_sum / st_valid) : 0U;
    pv_map_stat_quadrature_err_abs_max_deg_x100 = st_quad_err_abs_max;
    pv_map_stat_ed_abs_avg_mv = (st_valid > 0U) ?
        (uint32_t)(st_ed_abs_sum / st_valid) : 0U;
    pv_map_stat_ed_abs_max_mv = st_ed_abs_max;
    pv_map_stat_eq_abs_avg_mv = (st_valid > 0U) ?
        (uint32_t)(st_eq_abs_sum / st_valid) : 0U;
    pv_map_stat_ed_abs_permille_avg = (st_valid > 0U) ?
        (uint32_t)(st_ed_permille_sum / st_valid) : 0U;
    pv_map_stat_ed_abs_permille_max = st_ed_permille_max;

    st_samples = 0U;
    st_valid = 0U;
    st_eq_sign_ok = 0U;
    st_quad_err_abs_sum = 0ULL;
    st_quad_err_abs_max = 0U;
    st_ed_abs_sum = 0ULL;
    st_ed_abs_max = 0U;
    st_eq_abs_sum = 0ULL;
    st_ed_permille_sum = 0ULL;
    st_ed_permille_max = 0U;
  }
}
#endif /* PV_FOC_ANGLE_MAPPING_TEST1 */

#endif /* PV_PASSIVE_PLL_TEST1 */

static void phase_voltage_test_process(void)
{
  static uint32_t decim = 0;
  static q31_t prev_angle = 0;
  static bool have_prev_angle = false;
  static int64_t speed_delta_accum = 0;
  static uint32_t speed_delta_count = 0;
  static int32_t erpm_filt = 0;
  static uint32_t invalid_run = 0;

  /* One-second accumulation state. */
  static uint32_t stat_adc_samples_acc = 0;
  static uint32_t stat_processed_acc = 0;
  static uint32_t stat_valid_acc = 0;
  static uint32_t stat_invalid_acc = 0;
  static uint32_t stat_low_a_acc = 0, stat_low_b_acc = 0, stat_low_c_acc = 0;
  static uint32_t stat_high_a_acc = 0, stat_high_b_acc = 0, stat_high_c_acc = 0;
  static uint64_t stat_bemf_sum = 0;
  static uint32_t stat_bemf_min = 0xFFFFFFFFU, stat_bemf_max = 0;
  static uint64_t stat_span_sum = 0;
  static uint32_t stat_span_min = 0xFFFFFFFFU, stat_span_max = 0;
  static uint64_t stat_current_sum = 0;
  static uint32_t stat_current_min = 0xFFFFFFFFU, stat_current_max = 0;
  static uint64_t stat_step_abs_sum = 0;
  static uint32_t stat_step_abs_min = 0xFFFFFFFFU, stat_step_abs_max = 0;
  static uint32_t stat_step_samples_acc = 0;
  static uint32_t stat_angle_jump_acc = 0;
  static int64_t stat_erpm_sum = 0;
  static int32_t stat_erpm_min = INT32_MAX, stat_erpm_max = INT32_MIN;
  static uint32_t stat_speed_samples_acc = 0;
  static int32_t stat_last_speed_dir = 0;
  static uint32_t stat_dir_flip_acc = 0;

  const uint32_t ra = p_MotorStatePublic->adcData[PV_ADC_IDX_PHASE_A];
  const uint32_t rb = p_MotorStatePublic->adcData[PV_ADC_IDX_PHASE_B];
  const uint32_t rc = p_MotorStatePublic->adcData[PV_ADC_IDX_PHASE_C];
  const uint32_t current_a_raw = p_MotorStatePublic->adcData[PV_ADC_IDX_CURRENT_A];

  pv_dbg_adc_a = ra;
  pv_dbg_adc_b = rb;
  pv_dbg_adc_c = rc;
  pv_dbg_current_a_raw = current_a_raw;
  pv_dbg_battery_adc = p_MotorStatePublic->adcData[PV_ADC_IDX_BATTERY];
  pv_dbg_battery_mv = pv_dbg_battery_adc * CAL_BAT_V;
  pv_dbg_sample_counter++;

  uint32_t low_mask = 0U, high_mask = 0U;
  if (ra <= PV_ADC_CLIP_LOW_COUNTS) low_mask |= 1U;
  if (rb <= PV_ADC_CLIP_LOW_COUNTS) low_mask |= 2U;
  if (rc <= PV_ADC_CLIP_LOW_COUNTS) low_mask |= 4U;
  if (ra >= PV_ADC_CLIP_HIGH_COUNTS) high_mask |= 1U;
  if (rb >= PV_ADC_CLIP_HIGH_COUNTS) high_mask |= 2U;
  if (rc >= PV_ADC_CLIP_HIGH_COUNTS) high_mask |= 4U;
  pv_dbg_clip_low_mask = low_mask;
  pv_dbg_clip_high_mask = high_mask;

  /* Raw-ADC clipping statistics use every DMA sample, not just decimated data. */
  stat_adc_samples_acc++;
  if (low_mask & 1U) stat_low_a_acc++;
  if (low_mask & 2U) stat_low_b_acc++;
  if (low_mask & 4U) stat_low_c_acc++;
  if (high_mask & 1U) stat_high_a_acc++;
  if (high_mask & 2U) stat_high_b_acc++;
  if (high_mask & 4U) stat_high_c_acc++;

  /* Angle/vector math is decimated; ADC scan itself remains ~8.19 kHz. */
  if (++decim < PV_PROCESS_DECIMATION) return;
  decim = 0;
  pv_dbg_process_counter++;
  stat_processed_acc++;

  const int32_t va = (int32_t)pv_adc_to_phase_mv(ra);
  const int32_t vb = (int32_t)pv_adc_to_phase_mv(rb);
  const int32_t vc = (int32_t)pv_adc_to_phase_mv(rc);
  pv_dbg_va_mv = (uint32_t)va;
  pv_dbg_vb_mv = (uint32_t)vb;
  pv_dbg_vc_mv = (uint32_t)vc;

  int32_t vmax = va;
  int32_t vmin = va;
  if (vb > vmax) vmax = vb;
  if (vc > vmax) vmax = vc;
  if (vb < vmin) vmin = vb;
  if (vc < vmin) vmin = vc;
  const uint32_t phase_span = (uint32_t)(vmax - vmin);
  pv_dbg_phase_span_mv = phase_span;

  const int32_t common = (va + vb + vc) / 3;
  const int32_t ca = va - common;
  const int32_t cb = vb - common;
  const int32_t cc = vc - common;

  pv_dbg_common_mv = common;
  pv_dbg_a_center_mv = ca;
  pv_dbg_b_center_mv = cb;
  pv_dbg_c_center_mv = cc;

  /* Clarke: alpha=A, beta=(A+2B)/sqrt(3). */
  const int32_t alpha = ca;
  const int32_t beta =
      (int32_t)(((int64_t)(ca + 2 * cb) * 57735LL) / 100000LL);
  pv_dbg_alpha_mv = alpha;
  pv_dbg_beta_mv = beta;

  const uint32_t mag = pv_vec_mag_approx(alpha, beta);
  pv_dbg_bemf_mag_mv = mag;

  /* Statistics that are meaningful for every processed vector. */
  stat_bemf_sum += mag;
  if (mag < stat_bemf_min) stat_bemf_min = mag;
  if (mag > stat_bemf_max) stat_bemf_max = mag;
  stat_span_sum += phase_span;
  if (phase_span < stat_span_min) stat_span_min = phase_span;
  if (phase_span > stat_span_max) stat_span_max = phase_span;
  stat_current_sum += current_a_raw;
  if (current_a_raw < stat_current_min) stat_current_min = current_a_raw;
  if (current_a_raw > stat_current_max) stat_current_max = current_a_raw;

  int32_t step_deg_x100 = 0;
  bool step_accepted = false;

  if (mag >= PV_BEMF_VALID_MIN_MV) {
    pv_dbg_vector_valid = 1U;
    stat_valid_acc++;
    invalid_run = 0U;

    const q31_t angle = pv_atan2_q31(beta, alpha, pv_dbg_bemf_angle_q31);
    pv_dbg_bemf_angle_q31 = angle;

    if (have_prev_angle) {
      const int64_t delta = pv_wrap_q31_delta(angle, prev_angle);
      pv_dbg_angle_step_q31 = (int32_t)delta;
      step_deg_x100 = (int32_t)((delta * 36000LL) / 4294967296LL);
      pv_dbg_angle_step_deg_x100 = step_deg_x100;

      if (pv_abs_i64_to_u32(delta) <= (uint32_t)PV_ANGLE_STEP_MAX_Q31) {
        step_accepted = true;
        speed_delta_accum += delta;
        speed_delta_count++;

        const uint32_t step_abs = pv_abs_i32(step_deg_x100);
        stat_step_abs_sum += step_abs;
        if (step_abs < stat_step_abs_min) stat_step_abs_min = step_abs;
        if (step_abs > stat_step_abs_max) stat_step_abs_max = step_abs;
        stat_step_samples_acc++;

        if (speed_delta_count >= PV_SPEED_ACCUM_SAMPLES) {
          int64_t erpm64 =
              (speed_delta_accum * (int64_t)PV_PROCESS_HZ * 60LL) /
              (4294967296LL * (int64_t)speed_delta_count);
          if (erpm64 > INT32_MAX) erpm64 = INT32_MAX;
          if (erpm64 < INT32_MIN) erpm64 = INT32_MIN;
          const int32_t erpm_inst = (int32_t)erpm64;

          pv_dbg_erpm_instant = erpm_inst;
          erpm_filt += (erpm_inst - erpm_filt) / 4;
          pv_dbg_erpm_signed = erpm_filt;
          pv_dbg_erpm_abs = pv_abs_i32(erpm_filt);
          pv_dbg_mrpm = (MOTOR_POLE_PAIRS > 0U) ?
                        (pv_dbg_erpm_abs / MOTOR_POLE_PAIRS) : 0U;
          pv_dbg_dir = (erpm_filt > 0) ? 1 : ((erpm_filt < 0) ? -1 : 0);
          pv_dbg_speed_update_counter++;

          stat_erpm_sum += erpm_inst;
          if (erpm_inst < stat_erpm_min) stat_erpm_min = erpm_inst;
          if (erpm_inst > stat_erpm_max) stat_erpm_max = erpm_inst;
          stat_speed_samples_acc++;

          const int32_t speed_dir = (erpm_inst > 0) ? 1 : ((erpm_inst < 0) ? -1 : 0);
          if (speed_dir != 0) {
            if (stat_last_speed_dir != 0 && speed_dir != stat_last_speed_dir) {
              stat_dir_flip_acc++;
            }
            stat_last_speed_dir = speed_dir;
          }

          speed_delta_accum = 0;
          speed_delta_count = 0;
        }
      } else {
        /* Vector was valid, but the angle made an implausible single-sample jump. */
        pv_dbg_angle_jump_count_total++;
        stat_angle_jump_acc++;
        speed_delta_accum = 0;
        speed_delta_count = 0;
      }
    } else {
      pv_dbg_angle_step_q31 = 0;
      pv_dbg_angle_step_deg_x100 = 0;
    }

    prev_angle = angle;
    have_prev_angle = true;
  } else {
    pv_dbg_vector_valid = 0U;
    pv_dbg_invalid_counter_total++;
    stat_invalid_acc++;
    have_prev_angle = false;
    speed_delta_accum = 0;
    speed_delta_count = 0;
    pv_dbg_angle_step_q31 = 0;
    pv_dbg_angle_step_deg_x100 = 0;
    pv_dbg_erpm_instant = 0;

    if (invalid_run < 0xFFFFFFFFU) invalid_run++;
    if (invalid_run >= PV_SPEED_INVALID_ZERO_SAMPLES) {
      erpm_filt = 0;
      pv_dbg_erpm_signed = 0;
      pv_dbg_erpm_abs = 0;
      pv_dbg_mrpm = 0;
      pv_dbg_dir = 0;
    }
  }

#if PV_PASSIVE_PLL_TEST1
  /* PASSIVE PLL only observes the raw BEMF angle. It has no motor-output path. */
  pv_passive_pll_step((pv_dbg_vector_valid != 0U),
                      pv_dbg_bemf_angle_q31, mag);
#if PV_FOC_ANGLE_MAPPING_TEST1
  pv_foc_angle_mapping_step((pv_dbg_vector_valid != 0U), alpha, beta, mag);
#endif
#endif
#if PV_ACTIVE_HANDOFF_TEST1
  /* Validate the injected current path while the bridge is still off, then
   * evaluate a manual one-shot arm only from this coherent passive sample. */
  pv_act_idle_current_diag_step();
  pv_act_try_arm_from_passive();
  if (pv_act_state == 1U) return; /* free CPU immediately for injected-current FOC */
#endif

  /* Expected phase BEMF peak from flux linkage. */
  pv_dbg_expected_mag_mv =
      (uint32_t)(((uint64_t)pv_dbg_erpm_abs *
                  (uint64_t)MOTOR_FLUX_LINKAGE_UWB * 6283ULL) /
                 60000000ULL);
  if (pv_dbg_expected_mag_mv > 0U) {
    uint32_t pct = (mag * 100U) / pv_dbg_expected_mag_mv;
    if (pct > 999U) pct = 999U;
    pv_dbg_mag_percent = pct;
  } else {
    pv_dbg_mag_percent = 0U;
  }

  /* Coherent one-shot snapshot: only written when explicitly requested. */
  if (pv_snap_request != 0U) {
    pv_snap_tick_ms = HAL_GetTick();
    pv_snap_sample_counter = pv_dbg_sample_counter;
    pv_snap_adc_a = ra;
    pv_snap_adc_b = rb;
    pv_snap_adc_c = rc;
    pv_snap_current_a_raw = current_a_raw;
    pv_snap_va_mv = (uint32_t)va;
    pv_snap_vb_mv = (uint32_t)vb;
    pv_snap_vc_mv = (uint32_t)vc;
    pv_snap_common_mv = common;
    pv_snap_a_center_mv = ca;
    pv_snap_b_center_mv = cb;
    pv_snap_c_center_mv = cc;
    pv_snap_alpha_mv = alpha;
    pv_snap_beta_mv = beta;
    pv_snap_bemf_mag_mv = mag;
    pv_snap_bemf_angle_q31 = pv_dbg_bemf_angle_q31;
    pv_snap_angle_step_deg_x100 = step_deg_x100;
    pv_snap_erpm_signed = pv_dbg_erpm_signed;
    pv_snap_mrpm = pv_dbg_mrpm;
    pv_snap_dir = pv_dbg_dir;
    pv_snap_vector_valid = pv_dbg_vector_valid;
    pv_snap_clip_low_mask = low_mask;
    pv_snap_clip_high_mask = high_mask;
    pv_snap_phase_span_mv = phase_span;
    pv_snap_battery_mv = pv_dbg_battery_mv;
#if PV_PASSIVE_PLL_TEST1
    pv_snap_pll_state = pv_pll_state;
    pv_snap_pll_confidence = pv_pll_confidence;
    pv_snap_pll_angle_q31 = pv_pll_angle_q31;
    pv_snap_pll_phase_error_deg_x100 = pv_pll_phase_error_deg_x100;
    pv_snap_pll_erpm = pv_pll_erpm;
    pv_snap_pll_valid_age_samples = pv_pll_valid_age_samples;
#if PV_FOC_ANGLE_MAPPING_TEST1
    pv_snap_map_valid = pv_map_valid;
    pv_snap_map_flux_angle_q31 = pv_map_flux_angle_q31;
    pv_snap_map_bemf_minus_flux_deg_x100 = pv_map_bemf_minus_flux_deg_x100;
    pv_snap_map_quadrature_error_deg_x100 = pv_map_quadrature_error_deg_x100;
    pv_snap_map_bemf_d_mv = pv_map_bemf_d_mv;
    pv_snap_map_bemf_q_mv = pv_map_bemf_q_mv;
    pv_snap_map_ed_abs_permille = pv_map_ed_abs_permille;
    pv_snap_map_eq_sign_ok = pv_map_eq_sign_ok;
#if PV_FOC_HANDOFF_PREP_TEST1
    pv_snap_ho_valid = pv_ho_valid;
    pv_snap_ho_ready = pv_ho_ready;
    pv_snap_ho_reject_mask = pv_ho_reject_mask;
    pv_snap_ho_preload_ud = pv_ho_preload_ud;
    pv_snap_ho_preload_uq = pv_ho_preload_uq;
    pv_snap_ho_pred_alpha_mv = pv_ho_pred_alpha_mv;
    pv_snap_ho_pred_beta_mv = pv_ho_pred_beta_mv;
    pv_snap_ho_match_error_mv = pv_ho_match_error_mv;
    pv_snap_ho_match_error_permille = pv_ho_match_error_permille;
    pv_snap_ho_u_abs = pv_ho_u_abs;
    pv_snap_ho_duty_a_counts = pv_ho_duty_a_counts;
    pv_snap_ho_duty_b_counts = pv_ho_duty_b_counts;
    pv_snap_ho_duty_c_counts = pv_ho_duty_c_counts;
    pv_snap_ho_duty_span_permille = pv_ho_duty_span_permille;
#endif
#endif
#endif
    pv_snap_id++;
    pv_snap_request = 0U;
  }

  /* Publish and reset one-second statistics. */
  if (stat_processed_acc >= PV_DIAG_WINDOW_SAMPLES) {
    pv_stat_window_id++;
    pv_stat_adc_samples = stat_adc_samples_acc;
    pv_stat_processed_samples = stat_processed_acc;
    pv_stat_valid_samples = stat_valid_acc;
    pv_stat_invalid_samples = stat_invalid_acc;
    pv_stat_valid_permille = (stat_processed_acc > 0U) ?
        (stat_valid_acc * 1000U) / stat_processed_acc : 0U;

    pv_stat_low_a_count = stat_low_a_acc;
    pv_stat_low_b_count = stat_low_b_acc;
    pv_stat_low_c_count = stat_low_c_acc;
    pv_stat_high_a_count = stat_high_a_acc;
    pv_stat_high_b_count = stat_high_b_acc;
    pv_stat_high_c_count = stat_high_c_acc;
    if (stat_adc_samples_acc > 0U) {
      pv_stat_low_a_permille = (stat_low_a_acc * 1000U) / stat_adc_samples_acc;
      pv_stat_low_b_permille = (stat_low_b_acc * 1000U) / stat_adc_samples_acc;
      pv_stat_low_c_permille = (stat_low_c_acc * 1000U) / stat_adc_samples_acc;
      pv_stat_high_a_permille = (stat_high_a_acc * 1000U) / stat_adc_samples_acc;
      pv_stat_high_b_permille = (stat_high_b_acc * 1000U) / stat_adc_samples_acc;
      pv_stat_high_c_permille = (stat_high_c_acc * 1000U) / stat_adc_samples_acc;
    }

    pv_stat_bemf_min_mv = (stat_bemf_min == 0xFFFFFFFFU) ? 0U : stat_bemf_min;
    pv_stat_bemf_max_mv = stat_bemf_max;
    pv_stat_bemf_avg_mv = (stat_processed_acc > 0U) ?
        (uint32_t)(stat_bemf_sum / stat_processed_acc) : 0U;
    pv_stat_span_min_mv = (stat_span_min == 0xFFFFFFFFU) ? 0U : stat_span_min;
    pv_stat_span_max_mv = stat_span_max;
    pv_stat_span_avg_mv = (stat_processed_acc > 0U) ?
        (uint32_t)(stat_span_sum / stat_processed_acc) : 0U;
    pv_stat_current_a_raw_min = (stat_current_min == 0xFFFFFFFFU) ? 0U : stat_current_min;
    pv_stat_current_a_raw_max = stat_current_max;
    pv_stat_current_a_raw_avg = (stat_processed_acc > 0U) ?
        (uint32_t)(stat_current_sum / stat_processed_acc) : 0U;

    pv_stat_step_samples = stat_step_samples_acc;
    pv_stat_step_abs_min_deg_x100 =
        (stat_step_abs_min == 0xFFFFFFFFU) ? 0U : stat_step_abs_min;
    pv_stat_step_abs_max_deg_x100 = stat_step_abs_max;
    pv_stat_step_abs_avg_deg_x100 = (stat_step_samples_acc > 0U) ?
        (uint32_t)(stat_step_abs_sum / stat_step_samples_acc) : 0U;
    pv_stat_angle_jump_count = stat_angle_jump_acc;

    pv_stat_speed_samples = stat_speed_samples_acc;
    if (stat_speed_samples_acc > 0U) {
      pv_stat_erpm_min = stat_erpm_min;
      pv_stat_erpm_max = stat_erpm_max;
      pv_stat_erpm_avg = (int32_t)(stat_erpm_sum / (int64_t)stat_speed_samples_acc);
      pv_stat_mrpm_abs_avg = pv_abs_i32(pv_stat_erpm_avg) / MOTOR_POLE_PAIRS;
    } else {
      pv_stat_erpm_min = 0;
      pv_stat_erpm_max = 0;
      pv_stat_erpm_avg = 0;
      pv_stat_mrpm_abs_avg = 0;
    }
    pv_stat_dir_flip_count = stat_dir_flip_acc;

    pv_stat_isr_cycles_max = pv_isr_cycles_window_max_accum;
    pv_stat_isr_load_permille = (pv_dbg_isr_period_cycles > 0U) ?
        (uint32_t)(((uint64_t)pv_stat_isr_cycles_max * 1000ULL) /
                   pv_dbg_isr_period_cycles) : 0U;
    pv_isr_cycles_window_max_accum = 0U;

    stat_adc_samples_acc = 0;
    stat_processed_acc = 0;
    stat_valid_acc = 0;
    stat_invalid_acc = 0;
    stat_low_a_acc = stat_low_b_acc = stat_low_c_acc = 0;
    stat_high_a_acc = stat_high_b_acc = stat_high_c_acc = 0;
    stat_bemf_sum = 0;
    stat_bemf_min = 0xFFFFFFFFU;
    stat_bemf_max = 0;
    stat_span_sum = 0;
    stat_span_min = 0xFFFFFFFFU;
    stat_span_max = 0;
    stat_current_sum = 0;
    stat_current_min = 0xFFFFFFFFU;
    stat_current_max = 0;
    stat_step_abs_sum = 0;
    stat_step_abs_min = 0xFFFFFFFFU;
    stat_step_abs_max = 0;
    stat_step_samples_acc = 0;
    stat_angle_jump_acc = 0;
    stat_erpm_sum = 0;
    stat_erpm_min = INT32_MAX;
    stat_erpm_max = INT32_MIN;
    stat_speed_samples_acc = 0;
    stat_dir_flip_acc = 0;
  }

  (void)step_accepted; /* retained for easy debugger extension without warnings */
}
#endif /* PHASE_VOLTAGE_TEST0 */

// structs for PI_control
PI_control_t PI_iq;
PI_control_t PI_id;

q31_t iq_filtered;
q31_t id_filtered;
q31_t uq_filtered;
q31_t ud_filtered;

q31_t q31_i_q_fil = 0;
q31_t q31_i_d_fil = 0;


static void set_inj_channel(char state);
void dyn_adc_state(q31_t angle);
q31_t PI_control(PI_control_t* PI_c);
void _motor_error_handler(char *file, int line);
static inline void disable_pwm(void);
static inline void enable_pwm(void);
static inline bool pwm_is_enabled(void);
#if PV_ACTIVE_HANDOFF_TEST1
static void pv_act_try_arm_from_passive(void);
static void pv_act_finish(uint32_t abort_reason);
static void pv_act_update_angle_from_dwt(void);
static uint32_t pv_act_arm_conditions(void);
static void pv_act_current_hw_init(void);
static void pv_act_current_offset_calibrate(void);
static void pv_act_idle_current_diag_step(void);
static void pv_act_hold_preload_voltage(void);

static uint32_t pv_act_abs_i32(int32_t v)
{
  return (v < 0) ? (uint32_t)(-(int64_t)v) : (uint32_t)v;
}

static uint32_t pv_act_injected_average(ADC_HandleTypeDef *hadc, uint32_t channel)
{
  (void)HAL_ADC_Stop(hadc);

  ADC_InjectionConfTypeDef inj = {0};
  inj.InjectedChannel = channel;
  inj.InjectedRank = ADC_INJECTED_RANK_1;
  inj.InjectedNbrOfConversion = 1;
  inj.InjectedSamplingTime = ADC_SAMPLETIME_28CYCLES_5;
  inj.ExternalTrigInjecConv = ADC_INJECTED_SOFTWARE_START;
  inj.AutoInjectedConv = DISABLE;
  inj.InjectedDiscontinuousConvMode = DISABLE;
  inj.InjectedOffset = 0;
  if (HAL_ADCEx_InjectedConfigChannel(hadc, &inj) != HAL_OK) return 0U;

  uint32_t sum = 0U;
  const uint32_t n = 64U;
  for (uint32_t i = 0U; i < n; i++) {
    if (HAL_ADCEx_InjectedStart(hadc) != HAL_OK) return 0U;
    if (HAL_ADCEx_InjectedPollForConversion(hadc, 10U) != HAL_OK) {
      (void)HAL_ADCEx_InjectedStop(hadc);
      return 0U;
    }
    sum += HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_1);
  }
  (void)HAL_ADCEx_InjectedStop(hadc);
  return sum / n;
}

static void pv_act_current_offset_calibrate(void)
{
  uint32_t a1 = pv_act_injected_average(&hadc1, ADC_CHANNEL_3);
  uint32_t c1 = pv_act_injected_average(&hadc1, ADC_CHANNEL_5);
  uint32_t b2 = pv_act_injected_average(&hadc2, ADC_CHANNEL_4);
  uint32_t c2 = pv_act_injected_average(&hadc2, ADC_CHANNEL_5);

  pv_act_offset_a_adc1 = a1;
  pv_act_offset_b_adc2 = b2;
  pv_act_offset_c_adc1 = c1;
  pv_act_offset_c_adc2 = c2;

  ui16_ph1_offset = (uint16_t)a1;
  ui16_ph2_offset = (uint16_t)b2;
  ui16_ph3_offset = (uint16_t)c1;

  uint32_t vmin = a1, vmax = a1;
  const uint32_t vals[3] = { b2, c1, c2 };
  for (uint32_t i = 0U; i < 3U; i++) {
    if (vals[i] < vmin) vmin = vals[i];
    if (vals[i] > vmax) vmax = vals[i];
  }
  pv_act_offset_spread_counts = vmax - vmin;
  pv_act_offset_cal_ok = (a1 > 100U && b2 > 100U && c1 > 100U && c2 > 100U &&
                          a1 < 4000U && b2 < 4000U && c1 < 4000U && c2 < 4000U) ? 1U : 0U;
}

static void pv_act_current_hw_init(void)
{
  pv_act_init_stage = 301U;
  ADC_MultiModeTypeDef mm = {0};
  mm.Mode = ADC_DUALMODE_INJECSIMULT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &mm) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 302U;

  ADC_InjectionConfTypeDef inj = {0};
  inj.InjectedRank = ADC_INJECTED_RANK_1;
  inj.InjectedNbrOfConversion = 1;
  /* FIX8 controlled A/B settling test:
   *   ADC1 phase-A current uses 28.5-cycle acquisition.
   *   ADC2 phase-B current remains at the original 1.5-cycle acquisition.
   *
   * FIX7 showed ADC1/A has a strong positive tail (~+23..+26 counts) while
   * ADC2/B is clean (~-3..+5 counts) with the bridge off.  Keeping B at
   * 1.5 cycles gives us a simultaneous control channel.  If only A becomes
   * clean with the longer acquisition, we have isolated an ADC settling /
   * source-impedance issue rather than real motor current.  No current limit,
   * arm condition, PWM state or MOE behavior is changed by this test. */
  inj.InjectedSamplingTime = ADC_SAMPLETIME_28CYCLES_5;
  /* FIX6: use TIM1 TRGO (already sourced from OC4REF in TIM1_Init) rather
   * than the F1 TIM1_CC4 ADC trigger. On STM32F1 the CC4 trigger is tied
   * to the channel-output path and can be suppressed while TIM1 MOE=0.
   * TRGO comes from the internal OC4REF path, so injected current sampling
   * continues while CH1..3 power outputs remain safely disabled. */
  inj.ExternalTrigInjecConv = ADC_EXTERNALTRIGINJECCONV_T1_TRGO;
  inj.AutoInjectedConv = DISABLE;
  inj.InjectedDiscontinuousConvMode = DISABLE;
  inj.InjectedOffset = 0;

  inj.InjectedChannel = ADC_CHANNEL_3;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc1, &inj) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 303U;

  /* B stays at 1.5 cycles as the control leg for this one diagnostic build. */
  inj.InjectedSamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  inj.InjectedChannel = ADC_CHANNEL_4;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &inj) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 304U;
}

static void pv_act_idle_current_diag_step(void)
{
  static uint32_t win_samples = 0U;
  static uint64_t win_abs_sum = 0ULL;
  static uint32_t win_peak = 0U;

  /* FIX7 per-channel accumulators. */
  static uint64_t a_abs_sum = 0ULL;
  static uint64_t b_abs_sum = 0ULL;
  static uint32_t a_peak = 0U;
  static uint32_t b_peak = 0U;
  static int32_t a_min_counts = 0;
  static int32_t a_max_counts = 0;
  static int32_t b_min_counts = 0;
  static int32_t b_max_counts = 0;
  static uint32_t a_over300 = 0U, b_over300 = 0U;
  static uint32_t a_over600 = 0U, b_over600 = 0U;
  static uint32_t a_over900 = 0U, b_over900 = 0U;
  static uint32_t a_over1200 = 0U, b_over1200 = 0U;

  if (pv_act_state == 1U) return;
  if ((ADC1->SR & ADC_SR_JEOC) == 0U) return;

  /* set_inj_channel(1) is held while passive: ADC1=A and ADC2=B. JOFR1
   * subtracts the calibrated zero-current offset in hardware, so JDR1 is a
   * signed current-count result just like the original M365 FOC path. */
  int16_t ia_counts = (int16_t)ADC1->JDR1;
  int16_t ib_counts = (int16_t)ADC2->JDR1;
  __HAL_ADC_CLEAR_FLAG(&hadc1, ADC_FLAG_JEOC);
  __HAL_ADC_CLEAR_FLAG(&hadc2, ADC_FLAG_JEOC);

  int32_t ia_ma = (int32_t)ia_counts * CAL_I;
  int32_t ib_ma = (int32_t)ib_counts * CAL_I;
  pv_act_idle_i_a_ma = ia_ma;
  pv_act_idle_i_b_ma = ib_ma;
  pv_act_idle_current_samples_total++;

  uint32_t aa = pv_act_abs_i32(ia_ma);
  uint32_t ab = pv_act_abs_i32(ib_ma);
  uint32_t p = (aa > ab) ? aa : ab;
  if (p > win_peak) win_peak = p;
  win_abs_sum += (uint64_t)aa + (uint64_t)ab;

  if (win_samples == 0U) {
    a_min_counts = a_max_counts = (int32_t)ia_counts;
    b_min_counts = b_max_counts = (int32_t)ib_counts;
  } else {
    if ((int32_t)ia_counts < a_min_counts) a_min_counts = (int32_t)ia_counts;
    if ((int32_t)ia_counts > a_max_counts) a_max_counts = (int32_t)ia_counts;
    if ((int32_t)ib_counts < b_min_counts) b_min_counts = (int32_t)ib_counts;
    if ((int32_t)ib_counts > b_max_counts) b_max_counts = (int32_t)ib_counts;
  }

  if (aa > a_peak) a_peak = aa;
  if (ab > b_peak) b_peak = ab;
  a_abs_sum += aa;
  b_abs_sum += ab;

  if (aa > 300U)  a_over300++;
  if (ab > 300U)  b_over300++;
  if (aa > 600U)  a_over600++;
  if (ab > 600U)  b_over600++;
  if (aa > 900U)  a_over900++;
  if (ab > 900U)  b_over900++;
  if (aa > 1200U) a_over1200++;
  if (ab > 1200U) b_over1200++;

  win_samples++;

  if (win_samples >= PV_ACT_IDLE_DIAG_WINDOW_SAMPLES) {
    pv_act_idle_current_window_id++;
    pv_act_idle_current_window_samples = win_samples;
    pv_act_idle_peak_ma_last = win_peak;
    pv_act_idle_avg_abs_ma_last = (uint32_t)(win_abs_sum / (2ULL * win_samples));

    /* FIX9 qualifier: 450 mA is above the measured FIX8 bridge-off envelope
     * (~150..342 mA peak) but far below the 1.2 A active hard trip. Require
     * multiple consecutive clean windows so ARM cannot depend on a single
     * lucky debugger timing instant. */
    pv_act_idle_window_ok_last = (win_peak <= PV_ACT_MAX_IDLE_CURRENT_MA) ? 1U : 0U;
    if (win_peak > pv_act_idle_peak_max_since_boot) pv_act_idle_peak_max_since_boot = win_peak;
    if (pv_act_idle_window_ok_last != 0U) {
      pv_act_idle_pass_windows_total++;
      if (pv_act_idle_good_streak < 0xFFFFFFFFU) pv_act_idle_good_streak++;
      if (pv_act_idle_good_streak > pv_act_idle_good_streak_max)
        pv_act_idle_good_streak_max = pv_act_idle_good_streak;
      pv_act_idle_current_ok =
          (pv_act_idle_good_streak >= PV_ACT_IDLE_REQUIRED_GOOD_WINDOWS) ? 1U : 0U;
    } else {
      pv_act_idle_fail_windows_total++;
      pv_act_idle_good_streak = 0U;
      pv_act_idle_current_ok = 0U;
    }

    pv_act_noise_window_id++;
    pv_act_noise_samples_last = win_samples;
    pv_act_noise_a_peak_ma_last = a_peak;
    pv_act_noise_b_peak_ma_last = b_peak;
    pv_act_noise_a_avg_abs_ma_last = (uint32_t)(a_abs_sum / win_samples);
    pv_act_noise_b_avg_abs_ma_last = (uint32_t)(b_abs_sum / win_samples);
    pv_act_noise_a_min_counts_last = a_min_counts;
    pv_act_noise_a_max_counts_last = a_max_counts;
    pv_act_noise_b_min_counts_last = b_min_counts;
    pv_act_noise_b_max_counts_last = b_max_counts;
    pv_act_noise_a_over300_last = a_over300;
    pv_act_noise_b_over300_last = b_over300;
    pv_act_noise_a_over600_last = a_over600;
    pv_act_noise_b_over600_last = b_over600;
    pv_act_noise_a_over900_last = a_over900;
    pv_act_noise_b_over900_last = b_over900;
    pv_act_noise_a_over1200_last = a_over1200;
    pv_act_noise_b_over1200_last = b_over1200;

    win_samples = 0U;
    win_abs_sum = 0ULL;
    win_peak = 0U;
    a_abs_sum = 0ULL;
    b_abs_sum = 0ULL;
    a_peak = 0U;
    b_peak = 0U;
    a_min_counts = a_max_counts = 0;
    b_min_counts = b_max_counts = 0;
    a_over300 = b_over300 = 0U;
    a_over600 = b_over600 = 0U;
    a_over900 = b_over900 = 0U;
    a_over1200 = b_over1200 = 0U;
  }
}

static uint32_t pv_act_arm_conditions(void)
{
  uint32_t r = 0U;
  uint32_t erpm_abs = pv_act_abs_i32(pv_ho_erpm);
  if ((pv_ho_ready == 0U) || (pv_ho_reject_mask != 0U)) r |= PV_ACT_ARM_REJ_HO_NOT_READY;
  if ((erpm_abs < PV_ACT_MIN_ERPM) || (erpm_abs > PV_ACT_MAX_ERPM)) r |= PV_ACT_ARM_REJ_SPEED;
  if (pv_pll_dir != PV_ACT_REQUIRED_DIR) r |= PV_ACT_ARM_REJ_DIRECTION;
  if (pv_pll_confidence < PV_ACT_MIN_PLL_CONFIDENCE) r |= PV_ACT_ARM_REJ_CONFIDENCE;
  if ((pv_map_valid == 0U) ||
      (pv_map_stat_quadrature_err_abs_avg_deg_x100 > PV_ACT_MAX_QUAD_ERR_DEG_X100)) {
    r |= PV_ACT_ARM_REJ_MAPPING;
  }
  if (pv_ho_match_error_permille > PV_ACT_MAX_MATCH_ERR_PERMILLE) r |= PV_ACT_ARM_REJ_MATCH_ERROR;
  if (pv_dbg_adc_error_count != 0U) r |= PV_ACT_ARM_REJ_ADC_ERROR;
  if ((pv_ho_stat_ready_permille < PV_ACT_REQUIRED_READY_PERMILLE) ||
      (pv_ho_stat_reject_or_mask != 0U)) r |= PV_ACT_ARM_REJ_READY_HISTORY;
  if ((pv_act_hw_ready == 0U) || (pv_act_offset_cal_ok == 0U) ||
      (READ_BIT(TIM1->CR1, TIM_CR1_CEN) == 0U) ||
      (READ_BIT(TIM1->BDTR, TIM_BDTR_MOE) != 0U)) r |= PV_ACT_ARM_REJ_HW_NOT_READY;
  if ((pv_act_idle_current_window_id == 0U) || (pv_act_idle_current_ok == 0U))
    r |= PV_ACT_ARM_REJ_IDLE_CURRENT;

  /* Check the worst value that could actually be applied after the hard clamp. */
  uint32_t sc = pv_act_voltage_scale_permille;
  if (sc < PV_ACT_SCALE_MIN_PERMILLE) sc = PV_ACT_SCALE_MIN_PERMILLE;
  if (sc > PV_ACT_SCALE_MAX_PERMILLE) sc = PV_ACT_SCALE_MAX_PERMILLE;
  uint32_t scaled_u = (uint32_t)(((uint64_t)pv_ho_u_abs * (uint64_t)sc + 500ULL) / 1000ULL);
  if (scaled_u > PV_ACT_MAX_U_ABS) r |= PV_ACT_ARM_REJ_SCALE_VOLTAGE;
  return r;
}

static void pv_act_try_arm_from_passive(void)
{
  if (pv_act_state == 1U) return;

  if (pv_act_reset != 0U) {
    pv_act_reset = 0U;
    pv_act_arm = 0U;
    disable_pwm();
    pv_act_state = 0U;
    pv_act_abort_reason = 0U;
    pv_act_arm_reject_mask = 0U;
    pv_act_elapsed_us = 0U;
    pv_act_injected_callbacks = 0U;
    pv_act_peak_phase_ma = 0U;
    pv_act_peak_id_ma = 0U;
    pv_act_peak_iq_ma = 0U;
    pv_act_peak_u_abs = 0U;
  }

  if ((pv_act_state != 0U) || (pv_act_arm == 0U)) return;

  pv_act_arm_count++;
  pv_act_arm = 0U; /* every write is consumed exactly once */
  uint32_t reject = pv_act_arm_conditions();
  pv_act_arm_reject_mask = reject;
  if (reject != 0U) {
    pv_act_arm_reject_count++;
    return;
  }

  /* Freeze the passive phase-voltage path before energising the bridge: once
   * PWM is on, terminal-voltage ADC samples are no longer pure BEMF. */
  (void)HAL_TIM_Base_Stop(&htim3);
  disable_pwm();

  pv_act_start_erpm = pv_ho_erpm;
  pv_act_start_flux_angle_q31 = pv_ho_flux_angle_q31;

  uint32_t act_scale = pv_act_voltage_scale_permille;
  if (act_scale < PV_ACT_SCALE_MIN_PERMILLE) {
    act_scale = PV_ACT_SCALE_MIN_PERMILLE;
    pv_act_scale_clamp_count++;
  } else if (act_scale > PV_ACT_SCALE_MAX_PERMILLE) {
    act_scale = PV_ACT_SCALE_MAX_PERMILLE;
    pv_act_scale_clamp_count++;
  }
  pv_act_scale_applied_permille = act_scale;
  int32_t base_scaled_ud = (int32_t)(((int64_t)pv_ho_preload_ud * (int64_t)act_scale) / 1000LL);
  int32_t base_scaled_uq = (int32_t)(((int64_t)pv_ho_preload_uq * (int64_t)act_scale) / 1000LL);

  /* FIX13: config.h clamps this offset to exactly 0 deg so this experiment
   * changes voltage amplitude only. Keep the rotation code intact to preserve
   * the already-tested path and make the applied value explicit in diagnostics. */
  int32_t act_angle_deg_x100 = pv_act_angle_offset_deg_x100;
  if (act_angle_deg_x100 < PV_ACT_ANGLE_MIN_DEG_X100) {
    act_angle_deg_x100 = PV_ACT_ANGLE_MIN_DEG_X100;
    pv_act_angle_clamp_count++;
  } else if (act_angle_deg_x100 > PV_ACT_ANGLE_MAX_DEG_X100) {
    act_angle_deg_x100 = PV_ACT_ANGLE_MAX_DEG_X100;
    pv_act_angle_clamp_count++;
  }
  pv_act_angle_applied_deg_x100 = act_angle_deg_x100;
  pv_act_angle_applied_q31 = (int32_t)(((int64_t)act_angle_deg_x100 * 2147483648LL) / 18000LL);

  q31_t off_sin = 0, off_cos = 0;
  arm_sin_cos_q31((q31_t)pv_act_angle_applied_q31, &off_sin, &off_cos);
  if (off_sin == (q31_t)0x80000000) off_sin = -2147483647;
  pv_act_scaled_ud = (int32_t)((((int64_t)base_scaled_ud * off_cos) +
                                ((int64_t)base_scaled_uq * off_sin)) >> 31);
  pv_act_scaled_uq = (int32_t)(((-(int64_t)base_scaled_ud * off_sin) +
                                ((int64_t)base_scaled_uq * off_cos)) >> 31);
  pv_act_scaled_u_abs = pv_vec_mag_approx(pv_act_scaled_ud, pv_act_scaled_uq);
  pv_act_start_ud = pv_act_scaled_ud;
  pv_act_start_uq = pv_act_scaled_uq;

  /* Recompute the initial duty from the scaled + angle-shifted d/q voltage at
   * the captured flux angle. Do not reuse the passive shadow duties. */
  q31_t act_sin = 0, act_cos = 0, act_alpha = 0, act_beta = 0;
  arm_sin_cos_q31(pv_ho_flux_angle_q31, &act_sin, &act_cos);
  if (act_sin == (q31_t)0x80000000) act_sin = -2147483647;
  arm_inv_park_q31(pv_act_scaled_ud, pv_act_scaled_uq,
                   &act_alpha, &act_beta, -act_sin, act_cos);
  int32_t act_da = 0, act_db = 0, act_dc = 0;
  pv_ho_shadow_svpwm((int32_t)act_alpha, (int32_t)act_beta,
                     &act_da, &act_db, &act_dc);
  pv_act_start_duty_a = act_da;
  pv_act_start_duty_b = act_db;
  pv_act_start_duty_c = act_dc;
  pv_act_start_bemf_mv = pv_ho_bemf_mag_mv;
  pv_act_start_match_error_permille = pv_ho_match_error_permille;
  pv_act_start_vbus_mv = pv_ho_vbus_mv;

  MS.i_q_setpoint = 0;
  MS.i_d_setpoint = 0;
  MS.i_q = 0;
  MS.i_d = 0;
  q31_i_q_fil = 0;
  q31_i_d_fil = 0;
  PI_iq.limit_output = PV_ACT_MAX_U_ABS;
  PI_iq.limit_i = PV_ACT_MAX_U_ABS;
  PI_id.limit_output = PV_ACT_MAX_U_ABS;
  PI_id.limit_i = PV_ACT_MAX_U_ABS;
  PI_iq.setpoint = 0;
  PI_id.setpoint = 0;
  PI_iq.recent_value = 0;
  PI_id.recent_value = 0;
  /* TEST1 intentionally does not close the current PI loop.  We first prove
   * that the measured BEMF-matched voltage itself can be applied without a
   * current transient.  PI signs/integrator preload will be enabled only in a
   * later test after this physical handoff is validated. */
  PI_iq.integral_part = 0;
  PI_iq.out = 0;
  PI_id.integral_part = 0;
  PI_id.out = 0;
  MS.u_d = pv_act_scaled_ud;
  MS.u_q = pv_act_scaled_uq;
  q31_u_d_temp = MS.u_d;
  q31_u_q_temp = MS.u_q;

  switchtime[0] = pv_act_start_duty_a;
  switchtime[1] = pv_act_start_duty_b;
  switchtime[2] = pv_act_start_duty_c;
  TIM1->CCR1 = (uint16_t)switchtime[0];
  TIM1->CCR2 = (uint16_t)switchtime[1];
  TIM1->CCR3 = (uint16_t)switchtime[2];
  dyn_adc_state(pv_ho_flux_angle_q31);
  set_inj_channel(MS.char_dyn_adc_state);
  char_dyn_adc_state_old = MS.char_dyn_adc_state;

  pv_act_angle_q31 = pv_ho_flux_angle_q31;
  pv_act_i_a_ma = pv_act_i_b_ma = pv_act_i_c_ma = 0;
  pv_act_id_ma = pv_act_iq_ma = 0;
  pv_act_peak_phase_ma = 0U;
  pv_act_peak_id_ma = 0U;
  pv_act_peak_iq_ma = 0U;
  pv_act_peak_u_abs = pv_act_scaled_u_abs;
  pv_act_last_u_abs = pv_act_scaled_u_abs;
  pv_act_last_ud = pv_act_scaled_ud;
  pv_act_last_uq = pv_act_scaled_uq;
  pv_act_last_duty_a = pv_act_start_duty_a;
  pv_act_last_duty_b = pv_act_start_duty_b;
  pv_act_last_duty_c = pv_act_start_duty_c;
  pv_act_injected_callbacks = 0U;
  pv_act_abort_reason = 0U;
  pv_act_elapsed_us = 0U;
  pv_act_diag_samples = 0U;
  pv_act_diag_first_id_inst_ma = 0;
  pv_act_diag_first_iq_inst_ma = 0;
  pv_act_diag_last_id_inst_ma = 0;
  pv_act_diag_last_iq_inst_ma = 0;
  pv_act_diag_avg_id_inst_ma = 0;
  pv_act_diag_avg_iq_inst_ma = 0;
  pv_act_diag_peak_abs_id_inst_ma = 0U;
  pv_act_diag_peak_abs_iq_inst_ma = 0U;
  pv_act_diag_iq_delta_ma = 0;
  pv_act_diag_sum_id_ma = 0;
  pv_act_diag_sum_iq_ma = 0;

  /* Clear only active-run diagnostics; bridge-off statistics remain available
   * so we can compare the preflight noise envelope with the active transient. */
  pv_act_trip_valid = 0U;
  pv_act_trip_callback_index = 0U;
  pv_act_trip_elapsed_us = 0U;
  pv_act_trip_dyn_state = 0U;
  pv_act_trip_adc1_channel = 0U;
  pv_act_trip_adc2_channel = 0U;
  pv_act_trip_raw1_counts = pv_act_trip_raw2_counts = 0;
  pv_act_trip_ia_ma = pv_act_trip_ib_ma = pv_act_trip_ic_ma = 0;
  pv_act_trip_id_inst_ma = pv_act_trip_iq_inst_ma = 0;
  pv_act_trip_prev_id_ma = pv_act_trip_prev_iq_ma = 0;
  pv_act_trip_pmax_ma = pv_act_trip_prev_pmax_ma = 0U;
  pv_act_trip_angle_q31 = 0;
  pv_act_trip_tim1_cnt = 0U;
  pv_act_trip_ccr1 = pv_act_trip_ccr2 = pv_act_trip_ccr3 = pv_act_trip_ccr4 = 0U;
  pv_act_trip_adc1_smpr2 = pv_act_trip_adc2_smpr2 = 0U;
  pv_act_active_over300_count = 0U;
  pv_act_active_over600_count = 0U;
  pv_act_active_over900_count = 0U;
  pv_act_active_over1200_count = 0U;
  pv_act_active_streak_over600 = 0U;
  pv_act_active_streak_over900 = 0U;
  pv_act_active_max_streak_over600 = 0U;
  pv_act_active_max_streak_over900 = 0U;
  pv_act_active_first_over600_cb = 0U;
  pv_act_active_first_over900_cb = 0U;
  pv_act_trace_write_index = 0U;
  pv_act_trace_count = 0U;
  pv_act_prev_pmax_ma = 0U;
  for (uint32_t i = 0U; i < PV_ACT_TRIP_TRACE_SAMPLES; i++) {
    pv_act_trace_callback[i] = 0U;
    pv_act_trace_elapsed_us[i] = 0U;
    pv_act_trace_dyn_state[i] = 0U;
    pv_act_trace_raw1_counts[i] = 0;
    pv_act_trace_raw2_counts[i] = 0;
    pv_act_trace_ia_ma[i] = 0;
    pv_act_trace_ib_ma[i] = 0;
    pv_act_trace_ic_ma[i] = 0;
    pv_act_trace_pmax_ma[i] = 0U;
    pv_act_trace_tim1_cnt[i] = 0U;
  }

  /* Force all PWM preloads into active timer registers while both CEN and MOE
   * are clear. Passive injected conversions run without JEOC interrupts; arm
   * the interrupt only after the final stale flag is cleared. */
  CLEAR_BIT(TIM1->CR1, TIM_CR1_CEN);
  disable_pwm();
  TIM1->CNT = 0U;
  TIM1->EGR = TIM_EGR_UG;
  __HAL_ADC_DISABLE_IT(&hadc1, ADC_IT_JEOC);
  __HAL_ADC_CLEAR_FLAG(&hadc1, ADC_FLAG_JEOC);
  __HAL_ADC_CLEAR_FLAG(&hadc2, ADC_FLAG_JEOC);

  pv_act_start_cycles = DWT->CYCCNT;
  pv_act_last_angle_cycles = pv_act_start_cycles;
  pv_act_state = 1U;
  pv_act_run_count++;
  __HAL_ADC_ENABLE_IT(&hadc1, ADC_IT_JEOC);

  /* This is the ONLY intentional MOE set in ACTIVE_HANDOFF_TEST1. CEN is set
   * afterwards, so the first energised PWM cycle starts from CNT=0 with all
   * preloads already coherent. */
  enable_pwm();
  SET_BIT(TIM1->CR1, TIM_CR1_CEN);
  pv_act_pwm_was_enabled = 1U;
}

static void pv_act_update_angle_from_dwt(void)
{
  uint32_t now = DWT->CYCCNT;
  uint32_t dc = now - pv_act_last_angle_cycles;
  pv_act_last_angle_cycles = now;
  int64_t den = 60LL * (int64_t)SystemCoreClock;
  int64_t inc = 0;
  if (den > 0) {
    inc = ((int64_t)pv_act_start_erpm * (int64_t)dc * 4294967296LL) / den;
  }
  pv_act_angle_q31 = (int32_t)((uint32_t)pv_act_angle_q31 + (uint32_t)(int32_t)inc);
  pv_act_elapsed_us = (uint32_t)(((uint64_t)(now - pv_act_start_cycles) * 1000000ULL) /
                                 (uint64_t)SystemCoreClock);
}

static void pv_act_finish(uint32_t abort_reason)
{
  uint32_t now = DWT->CYCCNT;
  if (pv_act_start_cycles != 0U && SystemCoreClock != 0U) {
    pv_act_elapsed_us = (uint32_t)(((uint64_t)(now - pv_act_start_cycles) * 1000000ULL) /
                                   (uint64_t)SystemCoreClock);
  }

  disable_pwm();
  __HAL_ADC_DISABLE_IT(&hadc1, ADC_IT_JEOC);
  /* Any energized run invalidates the previous bridge-off current qualifier.
   * Passive sampling resumes below and must earn a fresh good-window streak
   * before another manual ARM can be accepted. */
  pv_act_idle_current_ok = 0U;
  pv_act_idle_good_streak = 0U;
  pv_act_tim1_moe = READ_BIT(TIM1->BDTR, TIM_BDTR_MOE) ? 1U : 0U;
  pv_act_tim1_cen = READ_BIT(TIM1->CR1, TIM_CR1_CEN) ? 1U : 0U;
  pv_act_tim1_ccer = TIM1->CCER;

  MS.i_q_setpoint = 0;
  MS.i_d_setpoint = 0;
  MS.u_q = 0;
  MS.u_d = 0;
  PI_iq.integral_part = 0;
  PI_iq.out = 0;
  PI_id.integral_part = 0;
  PI_id.out = 0;

  /* Resume passive BEMF sampling only after the bridge is safely disabled. */
  if (HAL_TIM_Base_Start(&htim3) != HAL_OK) {
    abort_reason |= PV_ACT_ABORT_INTERNAL;
  }

  pv_act_abort_reason = abort_reason;
  if (abort_reason == 0U) {
    pv_act_state = 2U;
    pv_act_success_count++;
  } else {
    pv_act_state = 3U;
    pv_act_abort_count++;
  }
}

static void pv_act_hold_preload_voltage(void)
{
  /* Fixed rotating-frame voltage matched to the passive BEMF snapshot.  No
   * current feedback is applied in the first active experiment; raw phase
   * current still has a hard asynchronous-in-the-loop abort on every JEOC. */
  q31_u_d_temp = pv_act_start_ud;
  q31_u_q_temp = pv_act_start_uq;
  MS.u_d = q31_u_d_temp;
  MS.u_q = q31_u_q_temp;
  MS.u_abs = (q31_t)pv_vec_mag_approx(q31_u_d_temp, q31_u_q_temp);
}

#endif /* PV_ACTIVE_HANDOFF_TEST1 */

void _motor_error_handler(char *file, int line) {
  (void)file;
#if PV_ACTIVE_HANDOFF_TEST1
  pv_act_init_error_count++;
  pv_act_init_error_line = (uint32_t)line;
  pv_act_init_adc1_state = hadc1.State;
  pv_act_init_adc2_state = hadc2.State;
  pv_act_init_adc1_error = hadc1.ErrorCode;
  pv_act_init_adc2_error = hadc2.ErrorCode;
  pv_act_init_adc1_cr1 = ADC1->CR1;
  pv_act_init_adc1_cr2 = ADC1->CR2;
  pv_act_init_adc2_cr1 = ADC2->CR1;
  pv_act_init_adc2_cr2 = ADC2->CR2;
  pv_act_init_tim1_cr1 = TIM1->CR1;
  pv_act_init_tim1_bdtr = TIM1->BDTR;
#endif

  /*
   * Motor init failed.  Do not depend on main(), SysTick or dashboard UART for
   * shutdown.  This loop keeps MOE off and lets a physical long press on the
   * dashboard key drop PC15/PS_HOLD directly.
   */
  power_emergency_blocking_loop();
}

int32_t motor_map(int32_t x, int32_t in_min, int32_t in_max, int32_t out_min,
		int32_t out_max) {
	// if input is smaller/bigger than expected return the min/max out ranges value
	if (x < in_min)
		return out_min;
	else if (x > in_max)
		return out_max;

	// map the input to the output range.
	// round up if mapping bigger ranges to smaller ranges
	else if ((in_max - in_min) > (out_max - out_min))
		return (x - in_min) * (out_max - out_min + 1) / (in_max - in_min + 1)
				+ out_min;
	// round down if mapping smaller ranges to bigger ranges
	else
		return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

// regular ADC callback
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
  ui8_adc_regular_flag = 1;
#if PHASE_VOLTAGE_TEST0
  if (hadc == &hadc1) {
#if PV_ACTIVE_HANDOFF_TEST1
    if (pv_act_state == 1U) return;
#endif
    const uint32_t cycle_start = DWT->CYCCNT;
    phase_voltage_test_process();
    const uint32_t cycles = DWT->CYCCNT - cycle_start;
    pv_dbg_isr_cycles_last = cycles;
    if (cycles > pv_dbg_isr_cycles_max_boot) {
      pv_dbg_isr_cycles_max_boot = cycles;
      if (pv_dbg_isr_period_cycles > 0U) {
        pv_dbg_isr_load_permille_max_boot =
            (uint32_t)(((uint64_t)cycles * 1000ULL) / pv_dbg_isr_period_cycles);
      }
    }
    if (cycles > pv_isr_cycles_window_max_accum) {
      pv_isr_cycles_window_max_accum = cycles;
    }
  }
#endif
}

#if PHASE_VOLTAGE_TEST0
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc) {
  if (hadc == &hadc1) {
    pv_dbg_adc_error_count++;
    pv_dbg_adc_error_code = HAL_ADC_GetError(hadc);
  }
}
#endif

void motor_disable_pwm(void) {
  CLEAR_BIT(TIM1->BDTR, TIM_BDTR_MOE);
}

static inline void disable_pwm(void) {
  CLEAR_BIT(TIM1->BDTR, TIM_BDTR_MOE);
}

static inline void enable_pwm(void) {
  SET_BIT(TIM1->BDTR, TIM_BDTR_MOE);
}

static inline bool pwm_is_enabled(void) {
  return READ_BIT(TIM1->BDTR, TIM_BDTR_MOE);
}

q31_t speed_PLL(q31_t actual, q31_t target) {
  static q31_t q31_d_i = 0;

  q31_t q31_PLL_error = target - actual;

  q31_t q31_p = (q31_PLL_error >> P_FACTOR_PLL);
  q31_d_i += (q31_PLL_error >> I_FACTOR_PLL);

  q31_t limit = ((deg_30 >> 18) * 500 / ui16_halls_tim2tics) << 16;
  if (q31_d_i > limit) {
    q31_d_i = limit;
  }
  
  limit = -((deg_30 >> 18) * 500 / ui16_halls_tim2tics) << 16;
  if (q31_d_i < limit) {
    q31_d_i = -((deg_30 >> 18) * 500 / ui16_halls_tim2tics) << 16;
  }

  q31_t q31_d_dc = q31_p + q31_d_i;

  if (actual == 0 && target == 0) {
    q31_d_i = 0;
  }

  return q31_d_dc;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	// Hall sensor event processing
	if (GPIO_Pin == HALL_1_Pin || GPIO_Pin == HALL_2_Pin || GPIO_Pin == HALL_3_Pin) // check for right interrupt source
	{
		ui8_hall_state = ((GPIOB->IDR & 1) << 2) | ((GPIOB->IDR >> 4) & 0b11); // mask input register with Hall 1 - 3 bits

		if (ui8_hall_state == ui8_hall_state_old)
			return;

    // old state + current state: having both states makes possible to validade correct sequence (on following steps)
		ui8_hall_case = ui8_hall_state_old * 10 + ui8_hall_state;

    // only process, if autodetect process is finished
		if (MS.hall_angle_detect_flag == false) {
			ui8_hall_state_old = ui8_hall_state;
		}

		uint16_t ui16_tim2_ticks = __HAL_TIM_GET_COUNTER(&htim2); // read in timer2tics since last hall event

		if (ui16_tim2_ticks > 100) { // debounce

			ui16_halls_tim2tics = ui16_tim2_ticks; // save timertics since last hall event

      // low pass filter ui16_halls_tim2tics
			static q31_t ui16_halls_tim2tics_acc = 128000; // start with near 0 angle
      ui16_halls_tim2tics_acc -= ui16_halls_tim2tics_acc >> 3;
			ui16_halls_tim2tics_acc += ui16_halls_tim2tics;
      ui16_halls_tim2tics_filtered = ui16_halls_tim2tics_acc >> 3;

			__HAL_TIM_SET_COUNTER(&htim2, 0); // reset tim2 counter

			ui8_overflow_flag = false;
		}

		switch (ui8_hall_case) // 12 cases for each transition from one stage to the next. 6x forward, 6x reverse
		{
      // 6 cases for forward direction
      case 64:
        q31_rotorposition_hall = Hall_64;
        i8_recent_rotor_direction = -i16_hall_order;
        uint16_full_rotation_counter = 0;
        break;

      case 45:
        q31_rotorposition_hall = Hall_45;
        i8_recent_rotor_direction = -i16_hall_order;
        break;

      case 51:
        q31_rotorposition_hall = Hall_51;
        i8_recent_rotor_direction = -i16_hall_order;
        break;

      case 13:
        q31_rotorposition_hall = Hall_13;
        i8_recent_rotor_direction = -i16_hall_order;
        uint16_half_rotation_counter = 0;
        break;

      case 32:
        q31_rotorposition_hall = Hall_32;
        i8_recent_rotor_direction = -i16_hall_order;
        break;

      case 26:
        q31_rotorposition_hall = Hall_26;
        i8_recent_rotor_direction = -i16_hall_order;
        break;

      // 6 cases for reverse direction
      case 46:
        q31_rotorposition_hall = Hall_64;
        i8_recent_rotor_direction = i16_hall_order;
        break;

      case 62:
        q31_rotorposition_hall = Hall_26;
        i8_recent_rotor_direction = i16_hall_order;
        break;

      case 23:
        q31_rotorposition_hall = Hall_32;
        i8_recent_rotor_direction = i16_hall_order;
        uint16_half_rotation_counter = 0;
        break;

      case 31:
        q31_rotorposition_hall = Hall_13;
        i8_recent_rotor_direction = i16_hall_order;
        break;

      case 15:
        q31_rotorposition_hall = Hall_51;
        i8_recent_rotor_direction = i16_hall_order;
        break;

      case 54:
        q31_rotorposition_hall = Hall_45;
        i8_recent_rotor_direction = i16_hall_order;
        uint16_full_rotation_counter = 0;
        break;
		}

    if (MS.angle_estimation == SPEED_PLL) {
      q31_PLL_error = q31_rotorposition_PLL - q31_rotorposition_hall;
		  q31_angle_per_tic = speed_PLL(q31_rotorposition_PLL, q31_rotorposition_hall);
    }
	}
}

void get_standstill_position() {
	// HAL_Delay(100); // will BLOCK because it is called inside systick interrupt
	HAL_GPIO_EXTI_Callback(GPIO_PIN_4); // read in initial rotor position

	switch (ui8_hall_state) {
    // 6 cases for forward direction
    case 2:
      q31_rotorposition_hall = Hall_32;
      break;

    case 6:
      q31_rotorposition_hall = Hall_26;
      break;

    case 4:
      q31_rotorposition_hall = Hall_64;
      break;

    case 5:
      q31_rotorposition_hall = Hall_45;
      break;

    case 1:
      q31_rotorposition_hall = Hall_51;
      break;

    case 3:
      q31_rotorposition_hall = Hall_13;
      break;
    }

	q31_rotorposition_absolute = q31_rotorposition_hall;
}

int32_t speed_to_tics(uint8_t speed) {
	return WHEEL_CIRCUMFERENCE * 5 * 3600 / (6 * GEAR_RATIO * speed * 10);
}

int8_t tics_to_speed(uint32_t tics) {
	return WHEEL_CIRCUMFERENCE * 5 * 3600 / (6 * GEAR_RATIO * tics * 10);;
}

void motor_autodetect() {
	enable_pwm();
	MS.hall_angle_detect_flag = true;
	q31_rotorposition_absolute = 1 << 31;
  i16_hall_order = 1; // reset hall order
  MS.i_d_setpoint = 200; // set MS.id to appr. 2000mA
	MS.i_q_setpoint = 1;

	HAL_Delay(5);
	for (uint32_t i = 0; i < 1080; i++) { // 1080 = 360 * 3, 3 turns, just to make sure at least a full turn happens

		q31_rotorposition_absolute += 11930465; //drive motor in open loop with steps of 1 degree
    HAL_Delay(5);

		if (ui8_hall_state_old != ui8_hall_state) {

	    switch (ui8_hall_case) // 12 cases for each transition from one stage to the next. 6x forward, 6x reverse
			{
        // 6 cases for forward direction
        case 64:
          Hall_64 = q31_rotorposition_absolute;
          break;

        case 45:
          Hall_45 = q31_rotorposition_absolute;
          break;

        case 51:
          Hall_51 = q31_rotorposition_absolute;
          break;

        case 13:
          Hall_13 = q31_rotorposition_absolute;
          break;

        case 32:
          Hall_32 = q31_rotorposition_absolute;
          break;

        case 26:
          Hall_26 = q31_rotorposition_absolute;
          break;

        // 6 cases for reverse direction
        case 46:
          Hall_64 = q31_rotorposition_absolute;
          break;

        case 62:
          Hall_26 = q31_rotorposition_absolute;
          break;

        case 23:
          Hall_32 = q31_rotorposition_absolute;
          break;

        case 31:
          Hall_13 = q31_rotorposition_absolute;
          break;

        case 15:
          Hall_51 = q31_rotorposition_absolute;
          break;

        case 54:
          Hall_45 = q31_rotorposition_absolute;
          break;
			} // end case

			ui8_hall_state_old = ui8_hall_state;
		}
	}

  disable_pwm();
  TIM1->CCR1 = 1023; // set initial PWM values
  TIM1->CCR2 = 1023;
  TIM1->CCR3 = 1023;
  MS.hall_angle_detect_flag = false;
  MS.i_d = 0;
  MS.i_q = 0;
  MS.u_d = 0;
  MS.u_q = 0;
  q31_tics_filtered = 1000000;

  // store variables on flash memory
	HAL_FLASH_Unlock();

	if (i8_recent_rotor_direction == 1) {
		EE_WriteVariable(EEPROM_POS_HALL_ORDER, 1);
		i16_hall_order = 1;
	} else {
		EE_WriteVariable(EEPROM_POS_HALL_ORDER, -1);
		i16_hall_order = -1;
	}
	EE_WriteVariable(EEPROM_POS_HALL_45, Hall_45 >> 16);
	EE_WriteVariable(EEPROM_POS_HALL_51, Hall_51 >> 16);
	EE_WriteVariable(EEPROM_POS_HALL_13, Hall_13 >> 16);
	EE_WriteVariable(EEPROM_POS_HALL_32, Hall_32 >> 16);
	EE_WriteVariable(EEPROM_POS_HALL_26, Hall_26 >> 16);
	EE_WriteVariable(EEPROM_POS_HALL_64, Hall_64 >> 16);

	HAL_FLASH_Lock();

	MS.hall_angle_detect_flag = false;

	ui16_KV_detect_counter = HAL_GetTick();
	MS.KV_detect_flag = 20;
}

int16_t internal_tics_to_speedx100 (uint32_t tics) {
	return WHEEL_CIRCUMFERENCE * 50 * 3600 / (6 * GEAR_RATIO * tics);
}

void calculate_tic_limits(int8_t speed_limit) {
  // tics = wheelcirc * timerfrequency / (no. of hallevents per rev * gear-ratio * speedlimit) * 3600 / 1000000
	tics_lower_limit = WHEEL_CIRCUMFERENCE * 5 * 3600 / (6 * GEAR_RATIO * speed_limit * 10);
	tics_higher_limit = WHEEL_CIRCUMFERENCE * 5 * 3600 / (6 * GEAR_RATIO * (speed_limit + 2) * 10);
}

q31_t get_battery_current(q31_t iq, q31_t id, q31_t uq, q31_t ud) {
	q31_t ibatq;
	q31_t ibatd;
	ibatq = (iq * uq * CAL_I) >> 11;
	ibatd = (id * ud * CAL_I) >> 11;

	return abs(ibatd) + abs(ibatq);
}


#if SENSORLESS_EXPERIMENTAL
/*
 * Sensorless start-kick state machine.
 *
 * TEST_STAGE 0: PWM never arms.
 * TEST_STAGE 1: throttle only starts observer acquisition with BOTH current
 *               targets at zero. No motor torque command is allowed.
 * TEST_STAGE 2: after a qualified observer lock, a very small q-current may
 *               ramp toward the dashboard throttle request.
 */
static void motor_sensorless_slow_loop(MotorStatePublic_t* MSP) {
  static bool throttle_was_released = false;
  static bool rearm_required = false;
  static uint32_t acquire_started_ms = 0;
  static int32_t iq_ramped = 0;

  MS.brake_active = MSP->brake_active;

  /* Update filtered values used by the existing current controller. */
  static q31_t iq_cum_sl = 0;
  static q31_t id_cum_sl = 0;
  static q31_t uq_cum_sl = 0;
  static q31_t ud_cum_sl = 0;
  iq_cum_sl -= iq_cum_sl >> 8; iq_cum_sl += MS.i_q; iq_filtered = iq_cum_sl >> 8;
  id_cum_sl -= id_cum_sl >> 8; id_cum_sl += MS.i_d; id_filtered = id_cum_sl >> 8;
  uq_cum_sl -= uq_cum_sl >> 8; uq_cum_sl += MS.u_q; uq_filtered = uq_cum_sl >> 8;
  ud_cum_sl -= ud_cum_sl >> 8; ud_cum_sl += MS.u_d; ud_filtered = ud_cum_sl >> 8;
  MS.Battery_Current = get_battery_current(iq_filtered, id_filtered, uq_filtered, ud_filtered);

  /* Existing debug array, useful if a separate UART logger is connected. */
  MSP->debug[0] = sensorless_get_state();
  MSP->debug[1] = sensorless_get_electrical_rpm();
  MSP->debug[2] = sensorless_get_good_samples();
  MSP->debug[3] = (uint32_t)sensorless_get_e_alpha();
  MSP->debug[4] = (uint32_t)sensorless_get_e_beta();
  MSP->debug[5] = (uint32_t)(abs(MS.i_q) * CAL_I);
  MSP->debug[6] = (uint32_t)MS.Battery_Current;
  MSP->speed = 0; /* wheel circumference not configured for this bench test */

#if (SENSORLESS_TEST_STAGE == 0) || !SENSORLESS_PARAMS_READY
  MS.i_q_setpoint = 0;
  MS.i_d_setpoint = 0;
  iq_ramped = 0;
  disable_pwm();
  return;
#else
  const bool battery_ok = (MSP->battery_voltage >= MSP->battery_voltage_min) &&
                          (MSP->battery_voltage <= BATTERYVOLTAGE_MAX);

  if (!battery_ok || MSP->brake_active) {
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    iq_ramped = 0;
    disable_pwm();
    sensorless_reset();
    rearm_required = true;
    throttle_was_released = false;
    return;
  }

  int32_t requested = MSP->i_q_setpoint_target;
  if (requested < 0) requested = 0; /* regen disabled */
  if (requested > MSP->phase_current_limit) requested = MSP->phase_current_limit;

  /* Throttle release disarms the inverter and arms the next acquisition. */
  if (requested == 0) {
    throttle_was_released = true;
    rearm_required = false;
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    iq_ramped = 0;
    if (pwm_is_enabled()) disable_pwm();
    sensorless_reset();
    return;
  }

#if SENSORLESS_REQUIRE_THROTTLE_RELEASE
  if (!throttle_was_released || rearm_required) {
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    disable_pwm();
    return;
  }
#endif

  /*
   * First throttle request while the wheel is ALREADY moving:
   * start at neutral duty and zero current target. The current controller then
   * tries to cancel BEMF-induced current while the flux observer acquires.
   */
  if (!pwm_is_enabled()) {
    TIM1->CCR1 = 1023;
    TIM1->CCR2 = 1023;
    TIM1->CCR3 = 1023;
    switchtime[0] = 1023;
    switchtime[1] = 1023;
    switchtime[2] = 1023;

    /* Reset both current regulators before reconnecting the inverter. */
    PI_iq.integral_part = 0;
    PI_iq.out = 0;
    PI_id.integral_part = 0;
    PI_id.out = 0;
    MS.u_q = 0;
    MS.u_d = 0;
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    iq_ramped = 0;

    /* Force a known two-shunt sampling pair while all duties are equal. */
    MS.char_dyn_adc_state = 1;
    set_inj_channel(1);
    char_dyn_adc_state_old = 1;

    sensorless_start_acquire();
    acquire_started_ms = HAL_GetTick();
    enable_pwm();
    return;
  }

  if (sensorless_has_fault() ||
      (!sensorless_is_locked() &&
       (HAL_GetTick() - acquire_started_ms) > SL_ACQUIRE_TIMEOUT_MS)) {
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    iq_ramped = 0;
    disable_pwm();
    sensorless_force_fault();
    rearm_required = true;
    throttle_was_released = false;
    return;
  }

  if (!sensorless_is_locked()) {
    /* Acquisition is ALWAYS zero torque. */
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    iq_ramped = 0;
    return;
  }

#if SENSORLESS_TEST_STAGE == 1
  /*
   * TEST1 ends here: observer may be LOCKED, but q-current remains exactly 0.
   * This lets us validate flux magnitude and eRPM before attempting torque.
   */
  MS.i_q_setpoint = 0;
  MS.i_d_setpoint = 0;
  iq_ramped = 0;
  return;
#else
  /* TEST2 only: very slow low-current torque ramp after a qualified lock. */
  const int32_t ramp_step = 1; /* one ADC current count per 20 ms slow loop */
  if (iq_ramped < requested) {
    iq_ramped += ramp_step;
    if (iq_ramped > requested) iq_ramped = requested;
  } else if (iq_ramped > requested) {
    iq_ramped -= ramp_step;
    if (iq_ramped < requested) iq_ramped = requested;
  }

  MS.i_q_setpoint = i8_direction * iq_ramped;
  MS.i_d_setpoint = 0;
#endif /* SENSORLESS_TEST_STAGE */
#endif /* stage0 / params */
}
#endif /* SENSORLESS_EXPERIMENTAL */

// call every 10ms
void motor_slow_loop(MotorStatePublic_t* p_MotorStatePublic) {
#if PV_ACTIVE_HANDOFF_TEST1
  /* If motor_init() faulted, never execute normal motor logic from SysTick. */
  if (pv_act_init_error_count != 0U) {
    disable_pwm();
    return;
  }
#endif

#if PHASE_VOLTAGE_TEST0
  MS.i_q_setpoint = 0;
  MS.i_d_setpoint = 0;

  pv_dbg_tim1_moe = READ_BIT(TIM1->BDTR, TIM_BDTR_MOE) ? 1U : 0U;
  pv_dbg_tim1_cen = READ_BIT(TIM1->CR1, TIM_CR1_CEN) ? 1U : 0U;
  pv_dbg_tim1_ccer = TIM1->CCER;
#if PV_ACTIVE_HANDOFF_TEST1
  /* MOE is allowed only during the explicitly armed millisecond-scale pulse. */
  if (pv_act_state != 1U) {
    if (pv_dbg_tim1_moe != 0U) pv_dbg_pwm_violation_count++;
    disable_pwm();
  }
#else
  if (pv_dbg_tim1_moe != 0U) pv_dbg_pwm_violation_count++;
  disable_pwm();
#endif
  pv_dbg_pwm_enabled = pwm_is_enabled() ? 1U : 0U;

  p_MotorStatePublic->speed = pv_dbg_mrpm;
  p_MotorStatePublic->debug[0] = pv_dbg_erpm_abs;
  p_MotorStatePublic->debug[1] = pv_dbg_bemf_mag_mv;
  p_MotorStatePublic->debug[2] = pv_dbg_vector_valid;
  p_MotorStatePublic->debug[3] = pv_dbg_adc_a;
  p_MotorStatePublic->debug[4] = pv_dbg_adc_b;
  p_MotorStatePublic->debug[5] = pv_dbg_adc_c;
  p_MotorStatePublic->debug[6] = (uint32_t)pv_dbg_dir;
  return;
#endif

#if SENSORLESS_EXPERIMENTAL
  motor_sensorless_slow_loop(p_MotorStatePublic);
  return;
#endif

  MotorStatePublic_t* MSP = p_MotorStatePublic;

  MS.brake_active = MSP->brake_active;

  // set power to zero at low voltage
  if (p_MotorStatePublic->battery_voltage < p_MotorStatePublic->battery_voltage_min) {
    
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    MS.error_state = lowbattery;

  } else {

    if (MS.error_state == lowbattery) {
      MS.error_state = none;
    }

    // i_q current limits
    if (MSP->i_q_setpoint_target > MSP->phase_current_limit) {
      MS.i_q_setpoint_temp = MSP->phase_current_limit;
    }

    if (MSP->i_q_setpoint_target < -MSP->phase_current_limit) {
      MS.i_q_setpoint_temp = -MSP->phase_current_limit;
    }

    calculate_tic_limits(MSP->speed_limit);

    // ramp down current at speed limit
    MS.i_q_setpoint_temp = motor_map(ui16_halls_tim2tics_filtered, tics_higher_limit, tics_lower_limit, 0, MSP->i_q_setpoint_target);

    if (MSP->field_weakening_enable) {
      
      MS.i_d_setpoint_temp =
        -motor_map(MSP->speed,
            (ui32_KV * MSP->battery_voltage / 100000) - 8,
            (ui32_KV * MSP->battery_voltage / 100000) + 30,
            0,
            MSP->field_weakening_current_max);

    } else {
      MS.i_d_setpoint_temp = 0;
    }

    // check and limit absolute value of current vector
    arm_sqrt_q31((MS.i_q_setpoint_temp * MS.i_q_setpoint_temp + MS.i_d_setpoint_temp * MS.i_d_setpoint_temp) << 1, &MS.i_setpoint_abs);
    MS.i_setpoint_abs = (MS.i_setpoint_abs >> 16) + 1;

    if (MS.hall_angle_detect_flag == false) {
      if (MS.i_setpoint_abs > MSP->phase_current_limit) {
        MS.i_q_setpoint = i8_direction * (MS.i_q_setpoint_temp * MSP->phase_current_limit) / MS.i_setpoint_abs; // division!
        MS.i_d_setpoint = (MS.i_d_setpoint_temp * MSP->phase_current_limit) / MS.i_setpoint_abs; // division!
        MS.i_setpoint_abs = MSP->phase_current_limit;
      } else {
        MS.i_q_setpoint = i8_direction * MS.i_q_setpoint_temp;
        MS.i_d_setpoint = MS.i_d_setpoint_temp;
      }
    }

    // run KV detection
    if (MS.KV_detect_flag > 0) {
      static int8_t dir = 1;
      static uint16_t KVtemp;
      MS.i_q_setpoint = 1;
      MS.angle_estimation = EXTRAPOLATION; // switch to angle extrapolation
      
      if ((MSP->battery_voltage * MS.u_q) >> (21 - SPEEDFILTER)) {
        ui32_KV -= ui32_KV >> 4;
        ui32_KV += (uint32_SPEEDx100_cumulated) / ((MSP->battery_voltage * MS.u_q) >> (21 - SPEEDFILTER)); // unit: kph*100/V
      }

      if (ui16_KV_detect_counter > 200) {
        MS.KV_detect_flag += 10 * dir;
        ui16_KV_detect_counter = 0;
      }

      if (MS.u_q > 1900) {
        KVtemp = ui32_KV >> 4;
        dir = -1;
      }

      // KV detection finished
      if (MS.KV_detect_flag < 20) {
        dir = 1;
        MS.i_q_setpoint = 0;
        ui32_KV = KVtemp;
        disable_pwm();
        MS.angle_estimation = SPEED_PLL; // switch back to config setting
        MS.KV_detect_flag = 0;
        i8_direction = REVERSE;
        HAL_FLASH_Unlock();
        EE_WriteVariable(EEPROM_POS_KV, (int16_t) (KVtemp));
        HAL_FLASH_Lock();
      }

      // abort if over current
      if (abs(MS.i_q > 300)) {
        MS.i_q_setpoint = 0;
        disable_pwm();
        MS.KV_detect_flag = 0;
        MS.angle_estimation = SPEED_PLL; // switch back to config setting
      }
    }
  }

  uint32_SPEEDx100_cumulated -= uint32_SPEEDx100_cumulated >> SPEEDFILTER;
  uint32_SPEEDx100_cumulated += internal_tics_to_speedx100(ui16_halls_tim2tics_filtered);

  // low pass filter next signals
  static q31_t iq_cum = 0;
  iq_cum -= iq_cum >> 8;
  iq_cum += MS.i_q;
  iq_filtered = iq_cum >> 8;

  static q31_t id_cum = 0;
  id_cum -= id_cum >> 8;
  id_cum += MS.i_d;
  id_filtered = id_cum >> 8;

  static q31_t uq_cum = 0;
  uq_cum -= uq_cum >> 8;
  uq_cum += MS.u_q;
  uq_filtered = uq_cum >> 8;

  static q31_t ud_cum = 0;
  ud_cum -= ud_cum >> 8;
  ud_cum += MS.u_d;
  ud_filtered = ud_cum >> 8;

  MS.Battery_Current = get_battery_current(iq_filtered, id_filtered, uq_filtered, ud_filtered) * sign(iq_filtered) * i8_direction * i8_reverse_flag;

  // enable PWM if power is wanted and speed is lower than idle speed
  if (MS.i_q_setpoint && pwm_is_enabled() == 0 && (uint32_SPEEDx100_cumulated >> SPEEDFILTER) * 1000 < (ui32_KV * MSP->battery_voltage)) {
    
    // set initial PWM values
    TIM1->CCR1 = 1023; 
    TIM1->CCR2 = 1023;
    TIM1->CCR3 = 1023;
    
    uint16_half_rotation_counter = 0;
    uint16_full_rotation_counter = 0;
    __HAL_TIM_SET_COUNTER(&htim2, 0); //reset tim2 counter
    ui16_halls_tim2tics = 40000; //set interval between two hallevents to a large value
    i8_recent_rotor_direction = i8_direction * i8_reverse_flag;
    enable_pwm();

    if (MS.system_state == Stop) {
      speed_PLL(0, 0); //reset integral part
    } else {
      PI_iq.integral_part = (((uint32_SPEEDx100_cumulated >> SPEEDFILTER) << 11) * 1000 / (ui32_KV * MSP->battery_voltage)) << PI_iq.shift;
      PI_iq.out = PI_iq.integral_part;
    }

    get_standstill_position();
    
  } else {
#ifdef KILL_ON_ZERO
                if(uint16_mapped_throttle==0&&READ_BIT(TIM1->BDTR, TIM_BDTR_MOE)){
      CLEAR_BIT(TIM1->BDTR, TIM_BDTR_MOE); //Disable PWM if motor is not turning
      get_standstill_position();
                        printf_("shutdown %d\n", q31_rotorposition_absolute);
                }
#endif

    // calculate wheel speed
    MSP->speed = tics_to_speed(ui16_halls_tim2tics_filtered);

    // see if PWM should be disable
    if (MS.i_q_setpoint == 0 && (uint16_full_rotation_counter > 7999 || uint16_half_rotation_counter > 7999)) {

      if (pwm_is_enabled()) {
        disable_pwm();
        get_standstill_position();
      }

      MSP->speed = 0;
      MS.system_state = Stop;
    }
  }
}

/**
 * Enable DMA controller clock
 */
static void DMA_Init(void) {

	/* DMA controller clock enable */
	__HAL_RCC_DMA1_CLK_ENABLE();

	// DMA channel 1: used for ADC
  /* DMA1_Channel1_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
}

/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */
static void ADC1_Init(void) {
  /**Common config */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T3_TRGO;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 6;
  hadc1.Init.NbrOfDiscConversion = 0;

  if (HAL_ADC_Init(&hadc1) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

#if PHASE_VOLTAGE_TEST0
  /*
   * Passive V1.4 phase-voltage scan.
   * 28.5-cycle acquisition time is deliberate: the 22k/6k divider has
   * ~4.7 kOhm Thevenin resistance, so 1.5 cycles is unnecessarily aggressive.
   *
   * DMA index:
   *   0 ADC2  = battery voltage (main.c compatibility)
   *   1 ADC6  = phase A voltage, PA6
   *   2 ADC0  = temperature (main.c compatibility)
   *   3 ADC7  = phase B voltage, PA7
   *   4 ADC9  = phase C voltage, PB1
   *   5 ADC3  = phase-current-A raw diagnostic only
   */
  ADC_ChannelConfTypeDef sConfig;

  sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES_5;

  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_6;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  return;
#else
  /**Configure the ADC multi-mode */
  ADC_MultiModeTypeDef multimode;
  multimode.Mode = ADC_DUALMODE_REGSIMULT_INJECSIMULT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  /**Configure Injected Channel */
  ADC_InjectionConfTypeDef sConfigInjected;
  sConfigInjected.InjectedChannel = ADC_CHANNEL_3;
  sConfigInjected.InjectedRank = ADC_INJECTED_RANK_1;
  sConfigInjected.InjectedNbrOfConversion = 1;
  sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfigInjected.ExternalTrigInjecConv = ADC_EXTERNALTRIGINJECCONV_T1_CC4;
  sConfigInjected.AutoInjectedConv = DISABLE;
  sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
  sConfigInjected.InjectedOffset = 0;
  HAL_ADC_Stop(&hadc1);
  if (HAL_ADCEx_InjectedConfigChannel(&hadc1, &sConfigInjected) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  ADC_ChannelConfTypeDef sConfig;
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = JSQR_PHASE_A >> 15;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = JSQR_PHASE_B >> 15;
  sConfig.Rank = ADC_REGULAR_RANK_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  sConfig.Channel = JSQR_PHASE_C >> 15;
  sConfig.Rank = ADC_REGULAR_RANK_6;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
#endif
}

/**
 * @brief ADC2 Initialization Function
 * @param None
 * @retval None
 */
static void ADC2_Init(void) {

	ADC_InjectionConfTypeDef sConfigInjected;

	/**Common config
	 */
	hadc2.Instance = ADC2;
	hadc2.Init.ScanConvMode = ADC_SCAN_ENABLE; //hier auch Scan enable?!
	hadc2.Init.ContinuousConvMode = DISABLE;
	hadc2.Init.DiscontinuousConvMode = DISABLE;
	hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc2.Init.NbrOfConversion = 1;
	if (HAL_ADC_Init(&hadc2) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	/**Configure Injected Channel
	 */
	sConfigInjected.InjectedChannel = ADC_CHANNEL_4;
	sConfigInjected.InjectedRank = ADC_INJECTED_RANK_1;
	sConfigInjected.InjectedNbrOfConversion = 1;
	sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_1CYCLE_5;
	sConfigInjected.ExternalTrigInjecConv = ADC_INJECTED_SOFTWARE_START;
	sConfigInjected.AutoInjectedConv = DISABLE;
	sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
	sConfigInjected.InjectedOffset = 0;
	if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &sConfigInjected) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}
}

/**
 * @brief TIM1 Initialization Function
 * @param None
 * @retval None
 */
static void TIM1_Init(void) {

	TIM_ClockConfigTypeDef sClockSourceConfig;
	TIM_MasterConfigTypeDef sMasterConfig;
	TIM_OC_InitTypeDef sConfigOC;
	TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig;

	htim1.Instance = TIM1;
	htim1.Init.Prescaler = 0;
	htim1.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED1;
	htim1.Init.Period = _T;
	htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim1.Init.RepetitionCounter = 0;
	htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim1) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	if (HAL_TIM_PWM_Init(&htim1) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	if (HAL_TIM_OC_Init(&htim1) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_OC4REF;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 1;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH; //TODO: depends on gate driver!
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	sConfigOC.OCIdleState = TIM_OCIDLESTATE_SET;
	sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sConfigOC.OCMode = TIM_OCMODE_PWM2;
	sConfigOC.Pulse = _T - 1;
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
	sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
	sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
	sBreakDeadTimeConfig.DeadTime = 32;
	sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
	sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
	sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
	if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	HAL_TIM_MspPostInit(&htim1);
}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */
static void TIM2_Init(void) {

	TIM_ClockConfigTypeDef sClockSourceConfig;
	TIM_MasterConfigTypeDef sMasterConfig;

  // CPU clock is 64MHz, so Timer2 ticks are 1/128 = 128ms
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 128;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 64000;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}
}

static void GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOB_CLK_ENABLE();

#if !SENSORLESS_EXPERIMENTAL
	/* Configure GPIO pins for motor hall sensors */
	GPIO_InitStruct.Pin = HALL_1_Pin | HALL_2_Pin | HALL_3_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* EXTI interrupt init*/
	HAL_NVIC_SetPriority(EXTI4_IRQn, 1, 0);
	HAL_NVIC_EnableIRQ(EXTI4_IRQn);
	HAL_NVIC_SetPriority(EXTI9_5_IRQn, 1, 0);
	HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
	HAL_NVIC_SetPriority(EXTI0_IRQn, 1, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
#endif

	/* Peripheral I/O remapping used by the original board. */
	__HAL_AFIO_REMAP_PD01_ENABLE();
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	
  if (htim == &htim3) {

    if (MS.angle_estimation == SPEED_PLL) {
      //keep q31_rotorposition_PLL updated when PWM is off
      if (pwm_is_enabled() == false) {
        q31_rotorposition_PLL += (q31_angle_per_tic << 1);
      }
    }
		
    if (MS.KV_detect_flag > 0) {
      ui16_KV_detect_counter++;
    }

    if (uint16_full_rotation_counter < 8000) {
			uint16_full_rotation_counter++;	//full rotation counter for motor standstill detection
    }

    if (uint16_half_rotation_counter < 8000) {
			uint16_half_rotation_counter++;	//half rotation counter for motor standstill detectio
    }
  }
}

//assuming, a proper AD conversion takes 350 timer tics, to be confirmed. DT+TR+TS deadtime + noise subsiding + sample time
void dyn_adc_state(q31_t angle) {
	if (switchtime[2] > switchtime[0] && switchtime[2] > switchtime[1]) {
		MS.char_dyn_adc_state = 1; // -90° .. +30°: Phase C at high dutycycles
		if (switchtime[2] > 1500)
			TIM1->CCR4 = switchtime[2] - TRIGGER_OFFSET_ADC;
		else
			TIM1->CCR4 = TRIGGER_DEFAULT;
	}

	if (switchtime[0] > switchtime[1] && switchtime[0] > switchtime[2]) {
		MS.char_dyn_adc_state = 2; // +30° .. 150° Phase A at high dutycycles
		if (switchtime[0] > 1500)
			TIM1->CCR4 = switchtime[0] - TRIGGER_OFFSET_ADC;
		else
			TIM1->CCR4 = TRIGGER_DEFAULT;
	}

	if (switchtime[1] > switchtime[0] && switchtime[1] > switchtime[2]) {
		MS.char_dyn_adc_state = 3; // +150 .. -90° Phase B at high dutycycles
		if (switchtime[1] > 1500)
			TIM1->CCR4 = switchtime[1] - TRIGGER_OFFSET_ADC;
		else
			TIM1->CCR4 = TRIGGER_DEFAULT;
	}
}

static void set_inj_channel(char state) {
	switch (state) {
	case 1: //Phase C at high dutycycles, read current from phase A + B
		ADC1->JSQR = JSQR_PHASE_A; //ADC1 injected reads phase A JL = 0b00, JSQ4 = 0b00100 (decimal 4 = channel 4)
		ADC1->JOFR1 = ui16_ph1_offset;
		ADC2->JSQR = JSQR_PHASE_B; //ADC2 injected reads phase B, JSQ4 = 0b00101, decimal 5
		ADC2->JOFR1 = ui16_ph2_offset;
		break;

	case 2: //Phase A at high dutycycles, read current from phase C + B
		ADC1->JSQR = JSQR_PHASE_C; //ADC1 injected reads phase C, JSQ4 = 0b00110, decimal 6
#if PV_ACTIVE_HANDOFF_TEST1
		ADC1->JOFR1 = (uint16_t)pv_act_offset_c_adc1;
#else
		ADC1->JOFR1 = ui16_ph3_offset;
#endif
		ADC2->JSQR = JSQR_PHASE_B; //ADC2 injected reads phase B, JSQ4 = 0b00101, decimal 5
		ADC2->JOFR1 = ui16_ph2_offset;
		break;

	case 3: //Phase B at high dutycycles, read current from phase A + C
		ADC1->JSQR = JSQR_PHASE_A; //ADC1 injected reads phase A JL = 0b00, JSQ4 = 0b00100 (decimal 4 = channel 4)
		ADC1->JOFR1 = ui16_ph1_offset;
		ADC2->JSQR = JSQR_PHASE_C; //ADC2 injected reads phase C, JSQ4 = 0b00110, decimal 6
#if PV_ACTIVE_HANDOFF_TEST1
		ADC2->JOFR1 = (uint16_t)pv_act_offset_c_adc2;
#else
		ADC2->JOFR1 = ui16_ph3_offset;
#endif
		break;
	}
}

// PI Control
q31_t PI_control(PI_control_t* PI_c)
{
  q31_t q31_p; //proportional part
  q31_p = ((PI_c->setpoint - PI_c->recent_value)*PI_c->gain_p);
  PI_c->integral_part += ((PI_c->setpoint - PI_c->recent_value)*PI_c->gain_i);

  if (PI_c->integral_part > PI_c->limit_i << PI_c->shift) PI_c->integral_part = PI_c->limit_i << PI_c->shift;
  if (PI_c->integral_part < -(PI_c->limit_i << PI_c->shift)) PI_c->integral_part = -(PI_c->limit_i << PI_c->shift);
  if (pwm_is_enabled() == false) PI_c->integral_part = 0 ; // reset integral part if PWM is disabled

  //avoid too big steps in one loop run
  if (q31_p+PI_c->integral_part > PI_c->out+PI_c->max_step) PI_c->out+=PI_c->max_step;
  else if  (q31_p+PI_c->integral_part < PI_c->out-PI_c->max_step)PI_c->out-=PI_c->max_step;
  else PI_c->out=(q31_p+PI_c->integral_part);

  if (PI_c->out>PI_c->limit_output << PI_c->shift) PI_c->out = PI_c->limit_output<< PI_c->shift;
  if (PI_c->out<-(PI_c->limit_output << PI_c->shift)) PI_c->out = -(PI_c->limit_output<< PI_c->shift); // allow no negative voltage.
  if (pwm_is_enabled() == false) PI_c->out = 0 ; //reset output if PWM is disabled

  return (PI_c->out>>PI_c->shift);
}

void runPIcontrol() {
	// PI-control processing

  //Check battery current limit
  if (MS.Battery_Current > BATTERYCURRENT_MAX)
    ui8_BC_limit_flag = true;
  if (MS.Battery_Current < -REGEN_CURRENT_MAX)
    ui8_BC_limit_flag = true;

  //reset battery current flag with small hysteresis
  q31_t battery_current = get_battery_current(MS.i_q_setpoint,MS.i_d_setpoint, uq_filtered, ud_filtered);

  // DEBUG
  p_MotorStatePublic->debug[0] = battery_current;

  if (MS.i_q * i8_direction * i8_reverse_flag > 100) { // motor mode
    if (battery_current < ((BATTERYCURRENT_MAX * 7) >> 3)) {
      ui8_BC_limit_flag = false;
    }
  } else { //generator mode
    if (battery_current > ((-REGEN_CURRENT_MAX * 7) >> 3)) { // Battery current not negative yet!!!!
      ui8_BC_limit_flag = false;
    }
  }

  if (ui8_BC_limit_flag == false) {
    PI_iq.recent_value = MS.i_q;
    PI_iq.setpoint = MS.i_q_setpoint;
  } else {
    if (MS.brake_active == false) {
      PI_iq.recent_value = (MS.Battery_Current >> 6) * i8_direction * i8_reverse_flag;
      PI_iq.setpoint = (BATTERYCURRENT_MAX >> 6) * i8_direction * i8_reverse_flag;
    } else {
      PI_iq.recent_value = (MS.Battery_Current >> 6) * i8_direction * i8_reverse_flag;
      PI_iq.setpoint = (-REGEN_CURRENT_MAX >> 6) * i8_direction * i8_reverse_flag;
    }
  }
  q31_u_q_temp = PI_control(&PI_iq);

  // control id
  PI_id.recent_value = MS.i_d;
  PI_id.setpoint = MS.i_d_setpoint;
  q31_u_d_temp = -PI_control(&PI_id); // control direct current to zero

  // DEBUG
  p_MotorStatePublic->debug[1] = MS.i_d;

  arm_sqrt_q31((q31_u_d_temp*q31_u_d_temp+q31_u_q_temp*q31_u_q_temp)<<1,&MS.u_abs);
  MS.u_abs = (MS.u_abs>>16)+1;

  if (MS.u_abs > _U_MAX) {
    MS.u_q = (q31_u_q_temp * _U_MAX) / MS.u_abs; // division!
    MS.u_d = (q31_u_d_temp * _U_MAX) / MS.u_abs; // division!
    MS.u_abs = _U_MAX;
  } else {
    MS.u_q = q31_u_q_temp;
    MS.u_d = q31_u_d_temp;
  }
}

/* TIM3 init function 8kHz interrupt frequency for regular adc triggering */
static void TIM3_Init(void) {

	TIM_ClockConfigTypeDef sClockSourceConfig;
	TIM_MasterConfigTypeDef sMasterConfig;

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 0;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 7813;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim3) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	#if PHASE_VOLTAGE_TEST0
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
#else
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_OC1;
#endif
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig)
			!= HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	HAL_TIM_MspPostInit(&htim3);
}

void motor_init(MotorStatePublic_t* motorStatePublic) {
  p_MotorStatePublic = motorStatePublic; // local pointer of MotorStatePublic

#if !SENSORLESS_EXPERIMENTAL
	// Virtual EEPROM init (Hall calibration/KV storage in the original firmware)
	HAL_FLASH_Unlock();
	EE_Init();
	HAL_FLASH_Lock();
#else
  sensorless_init();
#endif

  // init IO pins
	GPIO_Init();

  // init DMA for ADC
  DMA_Init();

	// initialize MS struct.
	MS.hall_angle_detect_flag = false;
  MS.KV_detect_flag = 0;
	MS.i_q_setpoint = 0;
	MS.i_d_setpoint = 0;
  MS.angle_estimation = SPEED_PLL;

	MS.phase_current_limit = PH_CURRENT_MAX_NORMAL;

  // init PI structs
#if SENSORLESS_EXPERIMENTAL
  PI_id.gain_i = SL_PI_I_ID;
  PI_id.gain_p = SL_PI_P_ID;
#else
  PI_id.gain_i = I_FACTOR_I_D;
  PI_id.gain_p = P_FACTOR_I_D;
#endif
  PI_id.setpoint = 0;
#if SENSORLESS_EXPERIMENTAL && (SENSORLESS_TEST_STAGE == 1)
  PI_id.limit_output = SENSORLESS_TEST1_U_MAX;
#else
  PI_id.limit_output = _U_MAX;
#endif
  PI_id.max_step = 5000;
  PI_id.shift = 10;
#if SENSORLESS_EXPERIMENTAL && (SENSORLESS_TEST_STAGE == 1)
  PI_id.limit_i = SENSORLESS_TEST1_U_MAX;
#else
  PI_id.limit_i = 1800;
#endif

#if SENSORLESS_EXPERIMENTAL
  PI_iq.gain_i = SL_PI_I_IQ;
  PI_iq.gain_p = SL_PI_P_IQ;
#else
  PI_iq.gain_i = I_FACTOR_I_Q;
  PI_iq.gain_p = P_FACTOR_I_Q;
#endif
  PI_iq.setpoint = 0;
#if SENSORLESS_EXPERIMENTAL && (SENSORLESS_TEST_STAGE == 1)
  PI_iq.limit_output = SENSORLESS_TEST1_U_MAX;
#else
  PI_iq.limit_output = _U_MAX;
#endif
  PI_iq.max_step = 5000;
  PI_iq.shift = 10;
#if SENSORLESS_EXPERIMENTAL && (SENSORLESS_TEST_STAGE == 1)
  PI_iq.limit_i = SENSORLESS_TEST1_U_MAX;
#else
  PI_iq.limit_i = _U_MAX;
#endif

#if PHASE_VOLTAGE_TEST0
  /*
   * Passive acquisition remains the default state.  In ACTIVE_HANDOFF_TEST1
   * TIM1 is configured and allowed to run with MOE=0 so one explicitly armed
   * millisecond-scale pulse can later be generated without reinitialising
   * hardware at the handoff instant.  MOE is the bridge-enable invariant.
   */
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0U;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
  pv_dbg_isr_period_cycles = (PV_ADC_TRIGGER_HZ > 0U) ?
      (SystemCoreClock / PV_ADC_TRIGGER_HZ) : 0U;

  pv_act_init_stage = 100U;
  ADC1_Init();
#if PV_ACTIVE_HANDOFF_TEST1
  pv_act_init_stage = 110U;
  ADC2_Init();
#endif

  pv_act_init_stage = 120U;
  if (HAL_ADCEx_Calibration_Start(&hadc1) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
#if PV_ACTIVE_HANDOFF_TEST1
  pv_act_init_stage = 130U;
  if (HAL_ADCEx_Calibration_Start(&hadc2) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

  /* Zero-current offsets are measured while ADC1/ADC2 are still independent.
   * The helper leaves both ADCs disabled so multimode can be selected safely. */
  pv_act_init_stage = 200U;
  pv_act_current_offset_calibrate();
  pv_act_init_stage = 210U;
  pv_act_current_hw_init();
  pv_act_init_stage = 310U;
#endif

  pv_act_init_stage = 400U;
  TIM3_Init();
  pv_act_init_stage = 410U;

  pv_act_init_stage = 420U;
#if PV_ACTIVE_HANDOFF_TEST1
  /* ADC1+ADC2 are already configured in injected-simultaneous dual mode.
   * STM32F1 HAL_ADC_Start_DMA() deliberately rejects any enabled multimode
   * and returns HAL_ERROR.  Use the HAL multimode DMA start API instead.
   * In ADC_DUALMODE_INJECSIMULT the regular group remains ADC1's regular
   * scan; ADC2 is enabled as the injected slave and its regular trigger is
   * software-start as required by the HAL. */
  if (HAL_ADCEx_MultiModeStart_DMA(&hadc1,
                                   (uint32_t*)p_MotorStatePublic->adcData,
                                   6) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
#else
  if (HAL_ADC_Start_DMA(&hadc1,
                        (uint32_t*)p_MotorStatePublic->adcData,
                        6) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
#endif

  /* TIM3 update -> ADC1 regular trigger at ~8.19 kHz. */
  pv_act_init_stage = 430U;
  if (HAL_TIM_Base_Start(&htim3) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }

#if PV_ACTIVE_HANDOFF_TEST1
  pv_act_init_stage = 500U;
  TIM1_Init();
  pv_act_init_stage = 510U;
  disable_pwm();

  /* Safe 50% common-mode starting point; no line-line voltage with equal CCRs. */
  TIM1->CCR1 = 1023U;
  TIM1->CCR2 = 1023U;
  TIM1->CCR3 = 1023U;
  TIM1->CCR4 = TRIGGER_DEFAULT;
  TIM1->EGR = TIM_EGR_UG;

  /* Enable timer channel state machines directly, deliberately avoiding
   * HAL_TIM_PWM_Start()/HAL_TIMEx_PWMN_Start(), which set MOE on TIM1. */
  SET_BIT(TIM1->CCER,
          TIM_CCER_CC1E | TIM_CCER_CC1NE |
          TIM_CCER_CC2E | TIM_CCER_CC2NE |
          TIM_CCER_CC3E | TIM_CCER_CC3NE |
          TIM_CCER_CC4E);
  disable_pwm();
  pv_act_init_stage = 520U;
  if (HAL_TIM_Base_Start(&htim1) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 530U;
  disable_pwm();

  /* Keep injected conversions running from TIM1_CC4 while passive, but with
   * JEOC interrupt disabled. This validates offset-corrected current noise
   * before arming without adding a 15.6-kHz idle ISR load. */
  MS.char_dyn_adc_state = 1;
  set_inj_channel(1);
  char_dyn_adc_state_old = 1;
  __HAL_ADC_DISABLE_IT(&hadc1, ADC_IT_JEOC);
  pv_act_init_stage = 600U;
  if (HAL_ADCEx_InjectedStart(&hadc2) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 610U;
  if (HAL_ADCEx_InjectedStart(&hadc1) != HAL_OK) {
    _motor_error_handler(__FILE__, __LINE__);
  }
  pv_act_init_stage = 620U;
  pv_act_hw_ready = (pv_act_offset_cal_ok != 0U) ? 1U : 0U;
  pv_act_init_stage = 700U;
#else
  __HAL_RCC_TIM1_CLK_ENABLE();
  disable_pwm();
#endif

  i16_hall_order = 1;
  ui32_KV = 0;
  sensorless_reset();
  pv_dbg_pwm_enabled = 0U;
  return;
#endif

	// ADC init and run calibration
	ADC1_Init();
	if (HAL_ADCEx_Calibration_Start(&hadc1) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}
	ADC2_Init();
	if (HAL_ADCEx_Calibration_Start(&hadc2) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

  // enable external trigger
	SET_BIT(ADC1->CR2, ADC_CR2_JEXTTRIG);
	__HAL_ADC_ENABLE_IT(&hadc1, ADC_IT_JEOC);
	SET_BIT(ADC2->CR2, ADC_CR2_JEXTTRIG);
	__HAL_ADC_ENABLE_IT(&hadc2, ADC_IT_JEOC);

	HAL_ADCEx_MultiModeStart_DMA(&hadc1, (uint32_t*) p_MotorStatePublic->adcData, 6);
  HAL_ADC_Start_IT(&hadc2);

  // Timers
	TIM1_Init(); // Swapped the order here!
	TIM2_Init(); // init Timer2 as a counter, where every tick is 128ms
  TIM3_Init();

	// Start Timer 1
	if (HAL_TIM_Base_Start_IT(&htim1) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1); // turn on complementary channel
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);

	HAL_TIM_PWM_Start_IT(&htim1, TIM_CHANNEL_4);

	TIM1->CCR4 = TRIGGER_DEFAULT; //ADC sampling just before timer overflow (just before middle of PWM-Cycle)

	// Start Timer 2
	if (HAL_TIM_Base_Start_IT(&htim2) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

  // Start Timer 3
	if (HAL_TIM_Base_Start_IT(&htim3) != HAL_OK) {
		_motor_error_handler(__FILE__, __LINE__);
	}

	disable_pwm();
	TIM1->CCR1 = 1023; //set initial PWM values
	TIM1->CCR2 = 1023;
	TIM1->CCR3 = 1023;

	HAL_Delay(1000);

  // average measured ADC phase currents, to store as the offset of each one
	for (uint32_t i = 0; i < 16; i++) {		
	  HAL_Delay(5);
		ui16_ph1_offset += p_MotorStatePublic->adcData[ADC_CHANA];
		ui16_ph2_offset += p_MotorStatePublic->adcData[ADC_CHANB];
		ui16_ph3_offset += p_MotorStatePublic->adcData[ADC_CHANC];
	}
	ui16_ph1_offset = ui16_ph1_offset >> 4;
	ui16_ph2_offset = ui16_ph2_offset >> 4;
	ui16_ph3_offset = ui16_ph3_offset >> 4;

  ADC1->JSQR = JSQR_PHASE_A; //ADC1 injected reads phase A JL = 0b00, JSQ4 = 0b00100 (decimal 4 = channel 4)
  ADC1->JOFR1 = ui16_ph1_offset;

#if SENSORLESS_EXPERIMENTAL
  /* No Hall autodetect and no standstill energisation in the sensorless build. */
  i16_hall_order = 1;
  ui32_KV = 0;
  sensorless_reset();
  HAL_Delay(5);
  disable_pwm();
#else
  EE_ReadVariable(EEPROM_POS_HALL_ORDER, &i16_hall_order);
  // set variables to value from emulated EEPROM only if valid
  if (i16_hall_order != 0xFFFF) {
    int16_t temp;
    EE_ReadVariable(EEPROM_POS_HALL_45, &temp);
    Hall_45 = temp << 16;
    EE_ReadVariable(EEPROM_POS_HALL_51, &temp);
    Hall_51 = temp << 16;
    EE_ReadVariable(EEPROM_POS_HALL_13, &temp);
    Hall_13 = temp << 16;
    EE_ReadVariable(EEPROM_POS_HALL_32, &temp);
    Hall_32 = temp << 16;
    EE_ReadVariable(EEPROM_POS_HALL_26, &temp);
    Hall_26 = temp << 16;
    EE_ReadVariable(EEPROM_POS_HALL_64, &temp);
    Hall_64 = temp << 16;
    EE_ReadVariable(EEPROM_POS_KV, &ui32_KV);
    if (ui32_KV == 0) {
      ui32_KV = 111;
    }
  } else {
    motor_autodetect();
  }

  HAL_Delay(5);
  disable_pwm();
  get_standstill_position();
#endif
}

void svpwm(q31_t q31_u_alpha, q31_t q31_u_beta) {

//SVPWM according to chapter 4.9 of UM1052

	q31_t q31_U_alpha = (_SQRT3 * _T * q31_u_alpha) >> 4;
	q31_t q31_U_beta = -_T * q31_u_beta;
	q31_t X = q31_U_beta;
	q31_t Y = (q31_U_alpha + q31_U_beta) >> 1;
	q31_t Z = (q31_U_beta - q31_U_alpha) >> 1;

	//Sector 1 & 4
	if ((Y >= 0 && Z < 0 && X > 0) || (Y < 0 && Z >= 0 && X <= 0)) {
		switchtime[0] = ((_T + X - Z) >> 12) + (_T >> 1); // right shift 11 for dividing by peroid (=2^11), right shift 1 for dividing by 2
		switchtime[1] = switchtime[0] + (Z >> 11);
		switchtime[2] = switchtime[1] - (X >> 11);
	}

	//Sector 2 & 5
	if ((Y >= 0 && Z >= 0) || (Y < 0 && Z < 0)) {
		switchtime[0] = ((_T + Y - Z) >> 12) + (_T >> 1);
		switchtime[1] = switchtime[0] + (Z >> 11);
		switchtime[2] = switchtime[0] - (Y >> 11);
	}

	//Sector 3 & 6
	if ((Y < 0 && Z >= 0 && X > 0) || (Y >= 0 && Z < 0 && X <= 0)) {
		switchtime[0] = ((_T + Y - X) >> 12) + (_T >> 1);
		switchtime[2] = switchtime[0] - (Y >> 11);
		switchtime[1] = switchtime[2] + (X >> 11);
	}
}

void FOC_calculation(int16_t int16_i_as, int16_t int16_i_bs, q31_t q31_teta, MotorState_t *MS) {

  q31_t q31_i_alpha = 0;
	q31_t q31_i_beta = 0;
	q31_t q31_u_alpha = 0;
	q31_t q31_u_beta = 0;
	q31_t q31_i_d = 0;
	q31_t q31_i_q = 0;

	q31_t sinevalue = 0, cosinevalue = 0;

		// Clark transformation
	arm_clarke_q31((q31_t) int16_i_as, (q31_t) int16_i_bs, &q31_i_alpha, &q31_i_beta);

	arm_sin_cos_q31(q31_teta, &sinevalue, &cosinevalue);
  // limit output valyes of arm_sin_cos_q31() as some seem wrong
	if (sinevalue == -2147483648) sinevalue = -2147483647;
	if (cosinevalue == 2147483648) cosinevalue = 2147483647;

	// Park transformation
	arm_park_q31(q31_i_alpha, q31_i_beta, &q31_i_d, &q31_i_q, sinevalue, cosinevalue);

	q31_i_q_fil -= q31_i_q_fil >> 4;
	q31_i_q_fil += q31_i_q;
	MS->i_q = q31_i_q_fil >> 4;

	q31_i_d_fil -= q31_i_d_fil >> 4;
	q31_i_d_fil += q31_i_d;
	MS->i_d = q31_i_d_fil >> 4;

	// Control iq
  
  //set static volatage for hall angle detection
	if (MS->KV_detect_flag) {  
    MS->u_q = MS->KV_detect_flag;
    MS->u_d = 0;
  } else {
#if PV_ACTIVE_HANDOFF_TEST1
    if (pv_act_state == 1U) pv_act_hold_preload_voltage();
    else runPIcontrol();
#else
    runPIcontrol();
#endif
  }

	// inverse Park transformation
	arm_inv_park_q31(MS->u_d, MS->u_q, &q31_u_alpha, &q31_u_beta, -sinevalue, cosinevalue);

#if SENSORLESS_EXPERIMENTAL
#if PV_ACTIVE_HANDOFF_TEST1
  /* The one-shot test deliberately free-runs from the captured passive PLL;
   * do not spend ISR time on, or accidentally depend on, the old observer. */
  if (pv_act_state != 1U) {
    sensorless_observer_step(q31_u_alpha, q31_u_beta, q31_i_alpha, q31_i_beta,
                             p_MotorStatePublic->battery_voltage);
  }
#else
  sensorless_observer_step(q31_u_alpha, q31_u_beta, q31_i_alpha, q31_i_beta,
                           p_MotorStatePublic->battery_voltage);
#endif
#endif

	// call SVPWM calculation
	svpwm(q31_u_alpha, q31_u_beta);
}

// injected ADC
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc) {

#if PHASE_VOLTAGE_TEST0
#if PV_ACTIVE_HANDOFF_TEST1
  /* Only ADC1 JEOC owns the active FOC step. ADC2 is the simultaneous slave. */
  if (hadc != &hadc1) return;
  pv_act_injected_callbacks_total++;

  if (pv_act_state != 1U) {
    /* JEOC IT is normally disabled outside ACTIVE. If a stale IRQ arrives,
     * fail-safe to MOE=0 and leave without touching passive state. */
    if (pwm_is_enabled()) {
      pv_dbg_pwm_violation_count++;
      disable_pwm();
    }
    __HAL_ADC_DISABLE_IT(&hadc1, ADC_IT_JEOC);
    return;
  }

  if (!pwm_is_enabled() || (READ_BIT(TIM1->CR1, TIM_CR1_CEN) == 0U)) {
    pv_act_finish(PV_ACT_ABORT_HW_STATE);
    return;
  }

  pv_act_injected_callbacks++;

  /* Read the two simultaneously sampled shunts and reconstruct phases A/B. */
  switch (MS.char_dyn_adc_state) {
    case 1: /* phase C high: read A+B */
      raw_inj1 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      raw_inj2 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      i16_ph1_current = (int16_t)raw_inj1;
      i16_ph2_current = (int16_t)raw_inj2;
      break;
    case 2: /* phase A high: read B+C, reconstruct A */
      raw_inj2 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      raw_inj1 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      i16_ph2_current = (int16_t)raw_inj2;
      i16_ph1_current = (int16_t)(-i16_ph2_current - (int16_t)raw_inj1);
      break;
    case 3: /* phase B high: read A+C, reconstruct B */
      raw_inj1 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      raw_inj2 = (q31_t)HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      i16_ph1_current = (int16_t)raw_inj1;
      i16_ph2_current = (int16_t)(-i16_ph1_current - (int16_t)raw_inj2);
      break;
    default:
      pv_act_finish(PV_ACT_ABORT_INTERNAL);
      return;
  }

  const int32_t ia = (int32_t)i16_ph1_current;
  const int32_t ib = (int32_t)i16_ph2_current;
  const int32_t ic = -ia - ib;
  pv_act_i_a_ma = ia * CAL_I;
  pv_act_i_b_ma = ib * CAL_I;
  pv_act_i_c_ma = ic * CAL_I;

  uint32_t pma = pv_act_abs_i32(pv_act_i_a_ma);
  uint32_t pmb = pv_act_abs_i32(pv_act_i_b_ma);
  uint32_t pmc = pv_act_abs_i32(pv_act_i_c_ma);
  uint32_t pmax = pma;
  if (pmb > pmax) pmax = pmb;
  if (pmc > pmax) pmax = pmc;
  if (pmax > pv_act_peak_phase_ma) pv_act_peak_phase_ma = pmax;

  /* FIX10: signed instantaneous d/q tendency. This is intentionally separate
   * from the filtered FOC current variables and never feeds back into control. */
  q31_t diag_a = 0, diag_b = 0, diag_d = 0, diag_q = 0;
  q31_t diag_s = 0, diag_c = 0;
  arm_clarke_q31((q31_t)i16_ph1_current, (q31_t)i16_ph2_current, &diag_a, &diag_b);
  arm_sin_cos_q31(pv_act_angle_q31, &diag_s, &diag_c);
  if (diag_s == (q31_t)0x80000000) diag_s = -2147483647;
  arm_park_q31(diag_a, diag_b, &diag_d, &diag_q, diag_s, diag_c);
  int32_t diag_id_ma = (int32_t)diag_d * CAL_I;
  int32_t diag_iq_ma = (int32_t)diag_q * CAL_I;
  if (pv_act_diag_samples == 0U) {
    pv_act_diag_first_id_inst_ma = diag_id_ma;
    pv_act_diag_first_iq_inst_ma = diag_iq_ma;
  }
  pv_act_diag_samples++;
  pv_act_diag_last_id_inst_ma = diag_id_ma;
  pv_act_diag_last_iq_inst_ma = diag_iq_ma;
  pv_act_diag_sum_id_ma += (int64_t)diag_id_ma;
  pv_act_diag_sum_iq_ma += (int64_t)diag_iq_ma;
  pv_act_diag_avg_id_inst_ma = (int32_t)(pv_act_diag_sum_id_ma / (int64_t)pv_act_diag_samples);
  pv_act_diag_avg_iq_inst_ma = (int32_t)(pv_act_diag_sum_iq_ma / (int64_t)pv_act_diag_samples);
  pv_act_diag_iq_delta_ma = pv_act_diag_last_iq_inst_ma - pv_act_diag_first_iq_inst_ma;
  uint32_t diag_id_abs = pv_act_abs_i32(diag_id_ma);
  uint32_t diag_iq_abs = pv_act_abs_i32(diag_iq_ma);
  if (diag_id_abs > pv_act_diag_peak_abs_id_inst_ma) pv_act_diag_peak_abs_id_inst_ma = diag_id_abs;
  if (diag_iq_abs > pv_act_diag_peak_abs_iq_inst_ma) pv_act_diag_peak_abs_iq_inst_ma = diag_iq_abs;

  /* FIX9: characterize the active transient without weakening the 1.2 A trip. */
  if (pmax > 300U) pv_act_active_over300_count++;
  if (pmax > 600U) {
    pv_act_active_over600_count++;
    if (pv_act_active_first_over600_cb == 0U)
      pv_act_active_first_over600_cb = pv_act_injected_callbacks;
    pv_act_active_streak_over600++;
    if (pv_act_active_streak_over600 > pv_act_active_max_streak_over600)
      pv_act_active_max_streak_over600 = pv_act_active_streak_over600;
  } else {
    pv_act_active_streak_over600 = 0U;
  }
  if (pmax > 900U) {
    pv_act_active_over900_count++;
    if (pv_act_active_first_over900_cb == 0U)
      pv_act_active_first_over900_cb = pv_act_injected_callbacks;
    pv_act_active_streak_over900++;
    if (pv_act_active_streak_over900 > pv_act_active_max_streak_over900)
      pv_act_active_max_streak_over900 = pv_act_active_streak_over900;
  } else {
    pv_act_active_streak_over900 = 0U;
  }
  if (pmax > 1200U) pv_act_active_over1200_count++;

  uint32_t sample_now = DWT->CYCCNT;
  uint32_t sample_elapsed_us = 0U;
  if ((pv_act_start_cycles != 0U) && (SystemCoreClock != 0U)) {
    sample_elapsed_us = (uint32_t)(((uint64_t)(sample_now - pv_act_start_cycles) * 1000000ULL) /
                                   (uint64_t)SystemCoreClock);
  }
  uint32_t ti = pv_act_trace_write_index;
  pv_act_trace_callback[ti] = pv_act_injected_callbacks;
  pv_act_trace_elapsed_us[ti] = sample_elapsed_us;
  pv_act_trace_dyn_state[ti] = (uint32_t)MS.char_dyn_adc_state;
  pv_act_trace_raw1_counts[ti] = (int32_t)(int16_t)raw_inj1;
  pv_act_trace_raw2_counts[ti] = (int32_t)(int16_t)raw_inj2;
  pv_act_trace_ia_ma[ti] = pv_act_i_a_ma;
  pv_act_trace_ib_ma[ti] = pv_act_i_b_ma;
  pv_act_trace_ic_ma[ti] = pv_act_i_c_ma;
  pv_act_trace_pmax_ma[ti] = pmax;
  pv_act_trace_tim1_cnt[ti] = TIM1->CNT;
  pv_act_trace_write_index = (ti + 1U) % PV_ACT_TRIP_TRACE_SAMPLES;
  if (pv_act_trace_count < PV_ACT_TRIP_TRACE_SAMPLES) pv_act_trace_count++;

  if (pmax > PV_ACT_MAX_PHASE_CURRENT_MA) {
    /* Latch the exact abort sample before MOE is cleared. */
    pv_act_trip_valid = 1U;
    pv_act_trip_callback_index = pv_act_injected_callbacks;
    pv_act_trip_elapsed_us = sample_elapsed_us;
    pv_act_trip_dyn_state = (uint32_t)MS.char_dyn_adc_state;
    if (MS.char_dyn_adc_state == 1) {
      pv_act_trip_adc1_channel = 3U; pv_act_trip_adc2_channel = 4U;
    } else if (MS.char_dyn_adc_state == 2) {
      pv_act_trip_adc1_channel = 5U; pv_act_trip_adc2_channel = 4U;
    } else if (MS.char_dyn_adc_state == 3) {
      pv_act_trip_adc1_channel = 3U; pv_act_trip_adc2_channel = 5U;
    }
    pv_act_trip_raw1_counts = (int32_t)(int16_t)raw_inj1;
    pv_act_trip_raw2_counts = (int32_t)(int16_t)raw_inj2;
    pv_act_trip_ia_ma = pv_act_i_a_ma;
    pv_act_trip_ib_ma = pv_act_i_b_ma;
    pv_act_trip_ic_ma = pv_act_i_c_ma;
    pv_act_trip_pmax_ma = pmax;
    pv_act_trip_prev_pmax_ma = pv_act_prev_pmax_ma;
    pv_act_trip_angle_q31 = pv_act_angle_q31;
    pv_act_trip_prev_id_ma = pv_act_id_ma;
    pv_act_trip_prev_iq_ma = pv_act_iq_ma;

    /* Instantaneous (unfiltered) d/q of the trip current. This is diagnostic
     * only and does not feed the controller. */
    q31_t ta = 0, tb = 0, td = 0, tq = 0, ts = 0, tc = 0;
    arm_clarke_q31((q31_t)i16_ph1_current, (q31_t)i16_ph2_current, &ta, &tb);
    arm_sin_cos_q31(pv_act_angle_q31, &ts, &tc);
    if (ts == (q31_t)0x80000000) ts = -2147483647;
    arm_park_q31(ta, tb, &td, &tq, ts, tc);
    pv_act_trip_id_inst_ma = (int32_t)td * CAL_I;
    pv_act_trip_iq_inst_ma = (int32_t)tq * CAL_I;

    pv_act_trip_tim1_cnt = TIM1->CNT;
    pv_act_trip_ccr1 = TIM1->CCR1;
    pv_act_trip_ccr2 = TIM1->CCR2;
    pv_act_trip_ccr3 = TIM1->CCR3;
    pv_act_trip_ccr4 = TIM1->CCR4;
    pv_act_trip_adc1_smpr2 = ADC1->SMPR2;
    pv_act_trip_adc2_smpr2 = ADC2->SMPR2;
    pv_act_finish(PV_ACT_ABORT_OVERCURRENT);
    return;
  }
  pv_act_prev_pmax_ma = pmax;

  pv_act_update_angle_from_dwt();
  if (pv_act_elapsed_us >= PV_ACT_DURATION_US) {
    pv_act_finish(0U);
    return;
  }
  q31_rotorposition_absolute = pv_act_angle_q31;

  /* Current-sampling slot for the next PWM cycle is based on the previous
   * cycle's SVPWM duties, exactly as in the original M365 FOC loop. */
  dyn_adc_state(q31_rotorposition_absolute);
  if (MS.char_dyn_adc_state != char_dyn_adc_state_old) {
    set_inj_channel(MS.char_dyn_adc_state);
    char_dyn_adc_state_old = MS.char_dyn_adc_state;
  }

  FOC_calculation(i16_ph1_current, i16_ph2_current,
                  q31_rotorposition_absolute, &MS);

  pv_act_id_ma = (int32_t)MS.i_d * CAL_I;
  pv_act_iq_ma = (int32_t)MS.i_q * CAL_I;
  uint32_t id_abs = pv_act_abs_i32(pv_act_id_ma);
  uint32_t iq_abs = pv_act_abs_i32(pv_act_iq_ma);
  if (id_abs > pv_act_peak_id_ma) pv_act_peak_id_ma = id_abs;
  if (iq_abs > pv_act_peak_iq_ma) pv_act_peak_iq_ma = iq_abs;

  pv_act_last_u_abs = (uint32_t)MS.u_abs;
  pv_act_last_ud = MS.u_d;
  pv_act_last_uq = MS.u_q;
  if (pv_act_last_u_abs > pv_act_peak_u_abs) pv_act_peak_u_abs = pv_act_last_u_abs;
  if (pv_act_last_u_abs > PV_ACT_MAX_U_ABS) {
    pv_act_finish(PV_ACT_ABORT_VOLTAGE_CMD);
    return;
  }
  if (pv_dbg_adc_error_count != 0U) {
    pv_act_finish(PV_ACT_ABORT_ADC_ERROR);
    return;
  }

  pv_act_last_duty_a = switchtime[0];
  pv_act_last_duty_b = switchtime[1];
  pv_act_last_duty_c = switchtime[2];
  TIM1->CCR1 = (uint16_t)switchtime[0];
  TIM1->CCR2 = (uint16_t)switchtime[1];
  TIM1->CCR3 = (uint16_t)switchtime[2];

  /* DWT-based timeout is independent of injected-ADC sample-rate assumptions. */
  pv_act_update_angle_from_dwt();
  if (pv_act_elapsed_us >= PV_ACT_DURATION_US) {
    pv_act_finish(0U);
  }
  return;
#else
  (void)hadc;
  disable_pwm();
  pv_dbg_pwm_enabled = 0U;
  return;
#endif
#endif

  // read phase currents
  switch (MS.char_dyn_adc_state) //read in according to state
  {
    case 1: //Phase C at high dutycycles, read from A+B directly
      raw_inj1 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      i16_ph1_current = raw_inj1;

      raw_inj2 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      i16_ph2_current = raw_inj2;
      break;

    case 2: //Phase A at high dutycycles, read from B+C (A = -B -C)
      raw_inj2 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      i16_ph2_current = raw_inj2;

      raw_inj1 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      i16_ph1_current = -i16_ph2_current - raw_inj1;
      break;

    case 3: //Phase B at high dutycycles, read from A+C (B=-A-C)
      raw_inj1 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);
      i16_ph1_current = raw_inj1;
      raw_inj2 = (q31_t) HAL_ADCEx_InjectedGetValue(&hadc2, ADC_INJECTED_RANK_1);
      i16_ph2_current = -i16_ph1_current - raw_inj2;
      break;

    case 0: //timeslot too small for ADC
      //do nothing
      break;
  } // end case

#if SENSORLESS_EXPERIMENTAL
  /*
   * Use the observer angle from the previous fast-loop sample. The observer is
   * updated inside FOC_calculation() using the current sample and voltage command.
   */
  q31_rotorposition_absolute = sensorless_get_angle();
#else
  __disable_irq(); // ENTER CRITICAL SECTION!!!!!!!!!!!!!

  if (MS.hall_angle_detect_flag == false) {
    // extrapolate recent rotor position
    uint16_t ui16_tim2_ticks = __HAL_TIM_GET_COUNTER(&htim2); // read in timertics since last event

    if (ui16_halls_tim2tics < SIXSTEPTHRESHOLD && ui16_tim2_ticks < 200) {
      ui8_6step_flag = false;
    }

    if (ui16_halls_tim2tics > (SIXSTEPTHRESHOLD * 6) >> 2) {
      ui8_6step_flag = true;
    }

    p_MotorStatePublic->debug[2] = ui8_6step_flag;

    if (MS.angle_estimation == SPEED_PLL) {
      q31_rotorposition_PLL += q31_angle_per_tic;
    }

    if (ui16_tim2_ticks < (ui16_halls_tim2tics + (ui16_halls_tim2tics >> 2))
        && ui8_overflow_flag == false
        && ui8_6step_flag == false) {
      if ((MS.angle_estimation == SPEED_PLL) && abs(q31_PLL_error) < deg_30) {
        q31_rotorposition_absolute = q31_rotorposition_PLL;
        MS.system_state = PLL;
      } else {
        q31_rotorposition_absolute = q31_rotorposition_hall +
          (q31_t) (i8_recent_rotor_direction * ((10923 * ui16_tim2_ticks) / ui16_halls_tim2tics)
          << 16);
        MS.system_state = Interpolation;
      }
    } else {
      ui8_overflow_flag = true;
      if (MS.KV_detect_flag) {
        q31_rotorposition_absolute = q31_rotorposition_hall;
      } else {
        q31_rotorposition_absolute = q31_rotorposition_hall + i8_direction * deg_30;
      }
      MS.system_state = SixStep;
    }
  }

  __enable_irq(); //EXIT CRITICAL SECTION!!!!!!!!!!!!!!
#endif

#if SENSORLESS_EXPERIMENTAL
  /* Immediate current trip independent of PI control. */
  int32_t sl_i_a = i16_ph1_current;
  int32_t sl_i_b = i16_ph2_current;
  int32_t sl_i_c = -sl_i_a - sl_i_b;
  int32_t sl_hard_counts = SENSORLESS_HARD_PHASE_CURRENT_MA / CAL_I;
  if (abs(sl_i_a) > sl_hard_counts || abs(sl_i_b) > sl_hard_counts || abs(sl_i_c) > sl_hard_counts) {
    disable_pwm();
    MS.i_q_setpoint = 0;
    MS.i_d_setpoint = 0;
    sensorless_force_fault();
    return;
  }
#endif

  //get the Phase with highest duty cycle for dynamic phase current reading
  dyn_adc_state(q31_rotorposition_absolute);

  //set the according injected channels to read current at Low-Side active time
  if (MS.char_dyn_adc_state != char_dyn_adc_state_old) {
    set_inj_channel(MS.char_dyn_adc_state);
    char_dyn_adc_state_old = MS.char_dyn_adc_state;
  }

  // call FOC procedure if PWM is enabled
  if (pwm_is_enabled()) {
    FOC_calculation(i16_ph1_current, i16_ph2_current, q31_rotorposition_absolute, &MS);
  }

  // apply PWM values that are calculated inside FOC_calculation()
  TIM1->CCR1 = (uint16_t) switchtime[0];
  TIM1->CCR2 = (uint16_t) switchtime[1];
  TIM1->CCR3 = (uint16_t) switchtime[2];
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
}
#endif /* USE_FULL_ASSERT */

