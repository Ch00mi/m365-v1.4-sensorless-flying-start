GreenMover ACTIVE_HANDOFF TEST1 - FIX13 FINE GAIN 1650/1700

Purpose:
- Continue the already-proven short physical-voltage gain calibration.
- FIX12 at 1600 permille still showed positive Iq ramp without overcurrent abort.
- Test 1650 permille first. Only test 1700 after reviewing the 1650 result.

Safety / behavior retained:
- angle correction hard-locked to 0.00 electrical degree
- one-shot manual ARM
- pulse duration ~350 us
- hard phase-current abort remains 1200 mA
- idle-current qualifier remains 450 mA + 8 consecutive clean windows
- PV_ACT_MAX_U_ABS remains 300
- request scale hard-clamped to 1300..1700 permille

Default:
  pv_act_voltage_scale_permille = 1650

Files to replace:
  Core/Inc/config.h
  Core/Src/motor.c

Test sequence:
1) Clean + Build. Do not flash until build is checked.
2) After flash, first test ONLY 1650 permille at ~54-56 mechanical rpm.
3) Confirm PLL locked, HO ready, reject_mask=0, idle_current_ok=1, MOE=0 before ARM.
4) One ARM pulse, then inspect Iq delta / avg Id / phase peak / abort reason.
5) 1700 is allowed only after the 1650 result is reviewed.
